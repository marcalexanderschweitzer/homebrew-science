
#include <stddef.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <stdio.h>
#include <math.h>

#include "solver.h"

void gauss_seidel_iteration(CsrMatrix A, Vector u, Vector b)
{
    assert(csr_get_rows(A) == csr_get_columns(A));
    assert(csr_get_columns(A) == vec_get_size(b));
    assert(csr_get_rows(A) == vec_get_size(u));

    const int rows = csr_get_rows(A);
    for(int r = 0; r < rows; ++r)
    {
        PmscScalar temp = 0;
        assert(csr_get_row_nz_index(A, r, 0) == r);
        const int row_nz_size = csr_get_row_nnz(A, r);
        for(int row_nz_i = 1; row_nz_i < row_nz_size; ++row_nz_i)
        {
            const int c = csr_get_row_nz_index(A, r, row_nz_i);
            temp += csr_get_row_nz_entry(A, r, row_nz_i)*vec_get_entry(u, c);
        }
        vec_set_entry(u, r, (vec_get_entry(b, r) - temp) / csr_get_row_nz_entry(A, r, 0));
    }
}

int gs_solve(CsrMatrix A, Vector u, Vector b, PmscScalar tolerance, int max_iterations)
{
    int final_iterations;
    return gs_solve_modified(A, u, b, tolerance, max_iterations, &final_iterations);
}

int gs_solve_modified(CsrMatrix A, Vector u, Vector b, PmscScalar tolerance, int max_iterations, int* final_iterations)
{
    assert(A->columns == u->size);
    assert(A->rows == b->size);
    assert(final_iterations != NULL);

    Vector r = NULL;
    if(vec_create(b->size, &r) != PMSC_SUCCESS) return -1;

    mat_vec_multiply(r, A, u);
    vec_subtract(r, r, b);

    PmscScalar initial_residual_norm = sqrt(vec_dot(r, r));
    PmscScalar residual_norm = initial_residual_norm;

    printf("iteration %d: residual %e\n", 0, residual_norm);
    if(residual_norm < tolerance)
    {
        vec_free(&r);
        *final_iterations = 0;
        return 0;
    }

    for(int iteration = 1; 1; ++iteration)
    {
        gauss_seidel_iteration(A, u, b);

        mat_vec_multiply(r, A, u);
        vec_subtract(r, r, b);

        residual_norm = sqrt(vec_dot(r, r));

        printf("iteration %d: residual %e\n", iteration, residual_norm);
        if((residual_norm/initial_residual_norm) < tolerance)
        {
            vec_free(&r);
            *final_iterations = iteration;
            return 0;
        }
        if(iteration >= max_iterations)
        {
            vec_free(&r);
            *final_iterations = iteration;
            return -1;
        }
    }
}

int richardson_gs_solve(CsrMatrix A, Vector u, Vector b, PmscScalar tolerance, int max_iterations)
{
    assert(A->columns == u->size);
    assert(A->rows == b->size);

    Vector r = NULL;
    if(vec_create(b->size, &r) != PMSC_SUCCESS) return -1;

    Vector t = NULL;
    if(vec_create(u->size, &t) != PMSC_SUCCESS) return -1;
    vec_assemble(t, u->values, u->size);

    mat_vec_multiply(r, A, u);
    vec_subtract(r, r, b);

    PmscScalar initial_residual_norm = sqrt(vec_dot(r, r));
    PmscScalar residual_norm = initial_residual_norm;

    printf("iteration %d: residual %e\n", 0, residual_norm);
    if(residual_norm < tolerance)
    {
        vec_free(&r);
        vec_free(&t);
        return 0;
    }

    for(int iteration = 1; 1; ++iteration)
    {
        vec_assign(t, 0);
        gauss_seidel_iteration(A, t, r);

        vec_subtract(u, u, t);

        mat_vec_multiply(r, A, u);
        vec_subtract(r, r, b);

        residual_norm = sqrt(vec_dot(r, r));

        printf("iteration %d: residual %e\n", iteration, residual_norm);
        if((residual_norm/initial_residual_norm) < tolerance)
        {
            vec_free(&r);
            vec_free(&t);
            return 0;
        }
        if(iteration >= max_iterations)
        {
            vec_free(&r);
            vec_free(&t);
            return -1;
        }
    }
}
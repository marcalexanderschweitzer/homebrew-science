
#ifndef PMSC_MATRIX_H
#define PMSC_MATRIX_H

#include "common.h"
#include "vector.h"

typedef struct _csr_matrix
{
    int rows;
    int columns;

    int* row_start_indices;
    int* column_indices;
    PmscScalar* values;
}* CsrMatrix;

int csr_create(int rows, int columns, int nnz, CsrMatrix* matrix);

void csr_free(CsrMatrix* matrix);

int csr_get_rows(CsrMatrix matrix);

int csr_get_columns(CsrMatrix matrix);

int csr_get_nnz(CsrMatrix matrix);

int csr_get_row_nnz(CsrMatrix matrix, int row_index);

int csr_get_row_nz_index(CsrMatrix matrix, int row_index, int non_zero_index);

PmscScalar csr_get_row_nz_entry(CsrMatrix matrix, int row_index, int non_zero_index);
void csr_set_row_nz_entry(CsrMatrix matrix, int row_index, int non_zero_index, PmscScalar value);

void csr_assemble(CsrMatrix matrix, const PmscScalar* values, const int* row_indices, const int* column_indices, int nnz);

void mat_vec_multiply(Vector result, CsrMatrix A, Vector v);

#endif /* PMSC_MATRIX_H */

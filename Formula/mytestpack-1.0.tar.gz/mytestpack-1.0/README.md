# Exercise 2

Please implement the required functions as described on `exercise_sheet_02.pdf`
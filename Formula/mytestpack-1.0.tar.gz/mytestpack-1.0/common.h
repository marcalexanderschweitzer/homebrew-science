
#ifndef PMSC_COMMON_H
#define PMSC_COMMON_H

#define PMSC_SUCCESS        0
#define PMSC_MEMORY_ERROR  -1
#define PMSC_FILE_ERROR    -2

typedef double PmscScalar;

#endif /* PMSC_COMMON_H */

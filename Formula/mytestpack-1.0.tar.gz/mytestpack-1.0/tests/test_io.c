
#include <stddef.h>

#include "../io.h"

#include "testing.h"

void test_vector_io(int* result)
{
    Vector v = NULL;
    const int create_result = vec_create(5, &v);
    if(expect_int_equal(create_result, 0, "test_vector_io: vec_create", result) != 0) return;

    const PmscScalar values[] = {1.0, 2.0, 5.0, -2.0, 0.333};
    vec_assemble(v, values, sizeof(values)/sizeof(*values));

    const int write_result = vec_write("test_vector_io.txt", v);
    if(expect_int_equal(write_result, 0, "test_vector_io: vec_write", result) != 0) { vec_free(&v); return; }

    Vector v_in = NULL;
    const int read_result = vec_read("test_vector_io.txt", &v_in);
    if(expect_int_equal(read_result, 0, "test_vector_io: vec_read", result) != 0) { vec_free(&v); return; }

    if(expect_ptr_not_equal(v_in, NULL, "test_vector_io: v_in", result) != 0) { vec_free(&v); vec_free(&v_in); return; }

    if(expect_int_equal(vec_get_size(v_in), 5, "test_vector_io: vec_get_size", result) != 0) { vec_free(&v); vec_free(&v_in); return; }

    expect_double_equal(vec_get_entry(v_in, 0), values[0], "test_vector_io: vec_get_entry(v_in, 0)", result);
    expect_double_equal(vec_get_entry(v_in, 1), values[1], "test_vector_io: vec_get_entry(v_in, 1)", result);
    expect_double_equal(vec_get_entry(v_in, 2), values[2], "test_vector_io: vec_get_entry(v_in, 2)", result);
    expect_double_equal(vec_get_entry(v_in, 3), values[3], "test_vector_io: vec_get_entry(v_in, 3)", result);
    expect_double_equal(vec_get_entry(v_in, 4), values[4], "test_vector_io: vec_get_entry(v_in, 4)", result);

    vec_free(&v);
    vec_free(&v_in);
}

void test_matrix_io(int* result)
{
    CsrMatrix m = NULL;
    const int create_result = csr_create(4, 3, 7, &m);
    if(expect_int_equal(create_result, 0, "test_matrix_io: vec_create", result) != 0) return;

    const PmscScalar values[]  = {1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0};
    const int row_indices[]    = {  0,   0,   1,   2,   2,   2,   3};
    const int column_indices[] = {  0,   2,   0,   0,   1,   2,   2};
    csr_assemble(m, values, row_indices, column_indices, sizeof(values)/sizeof(*values));

    const int write_result = csr_write("test_matrix_io.txt", m);
    if(expect_int_equal(write_result, 0, "test_matrix_io: csr_write", result) != 0)  { csr_free(&m); return; }

    CsrMatrix m_in = NULL;
    const int read_result = csr_read("test_matrix_io.txt", &m_in);
    if(expect_int_equal(read_result, 0, "test_matrix_io: csr_read", result) != 0)  { csr_free(&m); return; }

    if(expect_ptr_not_equal(m_in, NULL, "test_matrix_io: m", result) != 0)  { csr_free(&m); return; }

    if(expect_int_equal(csr_get_rows(m_in), 4, "test_matrix_io: csr_get_rows", result) != 0)  { csr_free(&m); csr_free(&m_in); return; }
    if(expect_int_equal(csr_get_columns(m_in), 3, "test_matrix_io: csr_get_columns", result) != 0)  { csr_free(&m); csr_free(&m_in); return; }
    if(expect_int_equal(csr_get_nnz(m_in), 7, "test_matrix_io: csr_get_nnz", result) != 0)  { csr_free(&m); csr_free(&m_in); return; }

    expect_int_equal(csr_get_row_nnz(m_in, 0), 2, "test_matrix_io: csr_get_row_nnz(m_in, 0)", result);
    expect_int_equal(csr_get_row_nnz(m_in, 1), 1, "test_matrix_io: csr_get_row_nnz(m_in, 1)", result);
    expect_int_equal(csr_get_row_nnz(m_in, 2), 3, "test_matrix_io: csr_get_row_nnz(m_in, 2)", result);
    expect_int_equal(csr_get_row_nnz(m_in, 3), 1, "test_matrix_io: csr_get_row_nnz(m_in, 3)", result);

    const PmscScalar dense_values[4][3] = {{1.0, 0.0, 2.0},
                                           {3.0, 0.0, 0.0},
                                           {4.0, 5.0, 6.0},
                                           {0.0, 0.0, 7.0}};

    expect_double_equal(csr_get_row_nz_entry(m_in, 0, 0), dense_values[0][csr_get_row_nz_index(m_in, 0, 0)], "test_matrix_io: csr_get_row_nz_entry(m_in, 0, 0)", result);
    expect_double_equal(csr_get_row_nz_entry(m_in, 0, 1), dense_values[0][csr_get_row_nz_index(m_in, 0, 1)], "test_matrix_io: csr_get_row_nz_entry(m_in, 0, 1)", result);
    expect_double_equal(csr_get_row_nz_entry(m_in, 1, 0), dense_values[1][csr_get_row_nz_index(m_in, 1, 0)], "test_matrix_io: csr_get_row_nz_entry(m_in, 1, 0)", result);
    expect_double_equal(csr_get_row_nz_entry(m_in, 2, 0), dense_values[2][csr_get_row_nz_index(m_in, 2, 0)], "test_matrix_io: csr_get_row_nz_entry(m_in, 2, 0)", result);
    expect_double_equal(csr_get_row_nz_entry(m_in, 2, 1), dense_values[2][csr_get_row_nz_index(m_in, 2, 1)], "test_matrix_io: csr_get_row_nz_entry(m_in, 2, 1)", result);
    expect_double_equal(csr_get_row_nz_entry(m_in, 2, 2), dense_values[2][csr_get_row_nz_index(m_in, 2, 2)], "test_matrix_io: csr_get_row_nz_entry(m_in, 2, 2)", result);
    expect_double_equal(csr_get_row_nz_entry(m_in, 3, 0), dense_values[3][csr_get_row_nz_index(m_in, 3, 0)], "test_matrix_io: csr_get_row_nz_entry(m_in, 3, 0)", result);

    csr_free(&m);
    csr_free(&m_in);
}

int main()
{
    int result = 0;

    test_vector_io(&result);
    test_matrix_io(&result);

    print_summary(result);

    return result;
}
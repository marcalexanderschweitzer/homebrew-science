
#include <stddef.h>

#include "../vector.h"

#include "testing.h"

void test_vector_create_and_destroy(int* result)
{
    Vector v = NULL;
    const int create_result = vec_create(3, &v);
    if(expect_int_equal(create_result, 0, "test_vector_create_and_destroy: vec_create", result) != 0) return;

    if(expect_ptr_not_equal(v, NULL, "test_vector_create_and_destroy: v", result) != 0) { vec_free(&v); return; }

    vec_free(&v);
    expect_ptr_equal(v, NULL, "test_vector_create_and_destroy: vec_free", result);
}

int main()
{
    int result = 0;

    test_vector_create_and_destroy(&result);

    print_summary(result);

    return result;
}
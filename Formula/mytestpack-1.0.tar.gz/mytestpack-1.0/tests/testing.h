
#ifndef PMSC_TESTING_H
#define PMSC_TESTING_H

#include <stdbool.h>

//! Test function for an expected condition that is not mandatory for the tests to continue.
//!
//! \param condition   The condition to be tested.
//! \param test_name   The name of the test to be printed to the screen.
//! \param test_status Variable holding the current status. The variable will
//!                    will be set to a non-zero value if the condition is false. It's value
//!                    will not be changed if the condition is true.
int expect_true(bool condition, const char* test_name, int* test_status);

int expect_int_equal(int value, int expected, const char* test_name, int* test_status);
int expect_int_not_equal(int value, int expected, const char* test_name, int* test_status);

int expect_double_equal(double value, double expected, const char* test_name, int* test_status);
int expect_double_not_equal(double value, double expected, const char* test_name, int* test_status);

int expect_double_equal_eps(double value, double expected, double epsilon, const char* test_name, int* test_status);
int expect_double_not_equal_eps(double value, double expected, double epsilon, const char* test_name, int* test_status);

int expect_ptr_equal(void* value, void* expected, const char* test_name, int* test_status);
int expect_ptr_not_equal(void* value, void* expected, const char* test_name, int* test_status);

void print_summary(int test_status);

#endif // PMSC_TESTING_H
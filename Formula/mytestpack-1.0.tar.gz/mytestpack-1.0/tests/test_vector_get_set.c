
#include <stddef.h>

#include "../vector.h"

#include "testing.h"

void test_vector_set_and_get(int* result)
{
    Vector v = NULL;
    const int create_result = vec_create(3, &v);
    if(expect_int_equal(create_result, 0, "test_vector_get_and_set: vec_create", result) != 0) return;

    if(expect_ptr_not_equal(v, NULL, "test_vector_get_and_set: v", result) != 0) { vec_free(&v); return; }

    expect_int_equal(vec_get_size(v), 3, "test_vector_get_and_set: vec_get_size", result);

    vec_set_entry(v, 0, 1.0);
    vec_set_entry(v, 1, 2.0);
    vec_set_entry(v, 2, 3.0);

    expect_double_equal(vec_get_entry(v, 0), 1.0, "test_vector_get_and_set: vec_get_entry(v, 0)", result);
    expect_double_equal(vec_get_entry(v, 1), 2.0, "test_vector_get_and_set: vec_get_entry(v, 1)", result);
    expect_double_equal(vec_get_entry(v, 2), 3.0, "test_vector_get_and_set: vec_get_entry(v, 2)", result);

    vec_free(&v);
    expect_ptr_equal(v, NULL, "test_vector_get_and_set: vec_free", result);
}

int main()
{
    int result = 0;

    test_vector_set_and_get(&result);

    print_summary(result);

    return result;
}
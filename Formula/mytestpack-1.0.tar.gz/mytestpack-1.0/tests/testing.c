

#include <stdio.h>
#include <math.h>

#include "testing.h"

#define PMSC_DOUBLE_COMPARE_EPS  1e-13

int expect_true(bool condition, const char* test_name, int* test_status)
{
    if(!condition)
    {
        fprintf(stderr, "[FAILED] %s\n", test_name);
        fprintf(stderr, "         expected true; got false\n");
        if(test_status != NULL)
        {
            *test_status = -1;
        }
        return -1;
    }
    else
    {
        fprintf(stdout, "[OK]     %s\n", test_name);
        return 0;
    }
}

int expect_int_equal(int value, int expected, const char* test_name, int* test_status)
{
    if(value != expected)
    {
        fprintf(stderr, "[FAILED] %s\n", test_name);
        fprintf(stderr, "         expected %d; got %d\n", expected, value);
        if(test_status != NULL)
        {
            *test_status = -1;
        }
        return -1;
    }
    else
    {
        fprintf(stdout, "[OK]     %s\n", test_name);
        return 0;
    }
}

int expect_int_not_equal(int value, int expected, const char* test_name, int* test_status)
{
    if(value == expected)
    {
        fprintf(stderr, "[FAILED] %s\n", test_name);
        fprintf(stderr, "         expected not %d; got %d\n", expected, value);
        if(test_status != NULL)
        {
            *test_status = -1;
        }
        return -1;
    }
    else
    {
        fprintf(stdout, "[OK]     %s\n", test_name);
        return 0;
    }
}

int expect_double_equal_eps(double value, double expected, double epsilon, const char* test_name, int* test_status)
{
    if(fabs(value - expected) > epsilon)
    {
        fprintf(stderr, "[FAILED] %s\n", test_name);
        fprintf(stderr, "         expected %e; got %e\n", expected, value);
        if(test_status != NULL)
        {
            *test_status = -1;
        }
        return -1;
    }
    else
    {
        fprintf(stdout, "[OK]     %s\n", test_name);
        return 0;
    }
}

int expect_double_equal(double value, double expected, const char* test_name, int* test_status)
{
    return expect_double_equal_eps(value, expected, PMSC_DOUBLE_COMPARE_EPS, test_name, test_status);
}

int expect_double_not_equal_eps(double value, double expected, double epsilon, const char* test_name, int* test_status)
{
    if(fabs(value - expected) <= epsilon)
    {
        fprintf(stderr, "[FAILED] %s\n", test_name);
        fprintf(stderr, "         expected not %e; got %e\n", expected, value);
        if(test_status != NULL)
        {
            *test_status = -1;
        }
        return -1;
    }
    else
    {
        fprintf(stdout, "[OK]     %s\n", test_name);
        return 0;
    }
}

int expect_double_not_equal(double value, double expected, const char* test_name, int* test_status)
{
    return expect_double_not_equal_eps(value, expected, PMSC_DOUBLE_COMPARE_EPS, test_name, test_status);
}

int expect_ptr_equal(void* value, void* expected, const char* test_name, int* test_status)
{
    if(value != expected)
    {
        fprintf(stderr, "[FAILED] %s\n", test_name);
        fprintf(stderr, "         expected not %p; got %p\n", expected, value);
        if(test_status != NULL)
        {
            *test_status = -1;
        }
        return -1;
    }
    else
    {
        fprintf(stdout, "[OK]     %s\n", test_name);
        return 0;
    }
}

int expect_ptr_not_equal(void* value, void* expected, const char* test_name, int* test_status)
{
    if(value == expected)
    {
        fprintf(stderr, "[FAILED] %s\n", test_name);
        fprintf(stderr, "         expected not %p; got %p\n", expected, value);
        if(test_status != NULL)
        {
            *test_status = -1;
        }
        return -1;
    }
    else
    {
        fprintf(stdout, "[OK]     %s\n", test_name);
        return 0;
    }
}

void print_summary(int test_status)
{
    if(test_status != 0)
    {
        fprintf(stdout, "\nTests failed!\n");
    }
    else
    {
        fprintf(stdout, "\nAll tests completed successful!\n");
    }
}
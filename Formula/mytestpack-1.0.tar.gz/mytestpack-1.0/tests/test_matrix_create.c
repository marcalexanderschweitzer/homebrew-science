
#include <stddef.h>

#include "../matrix.h"

#include "testing.h"

void test_matrix_create_and_destroy(int* result)
{
    CsrMatrix m = NULL;
    const int create_result = csr_create(4, 3, 7, &m);
    if(expect_int_equal(create_result, 0, "test_matrix_create_and_destroy: vec_create", result) != 0) return;

    if(expect_ptr_not_equal(m, NULL, "test_matrix_create_and_destroy: m", result) != 0)  { csr_free(&m); return; }

    csr_free(&m);
    expect_ptr_equal(m, NULL, "test_matrix_create_and_destroy: csr_free", result);
}

int main()
{
    int result = 0;

    test_matrix_create_and_destroy(&result);

    print_summary(result);

    return result;
}
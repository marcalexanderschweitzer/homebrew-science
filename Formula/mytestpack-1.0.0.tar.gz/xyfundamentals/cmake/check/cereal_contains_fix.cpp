#include <fstream>

#include <cereal/cereal.hpp>
#include <cereal/archives/binary.hpp>

struct MyVector
{
public:
    const int* data() const { return data_; }
private:
    int data_[3];
};

template<typename Archive>
void save(Archive& ar, const MyVector& v)
{
    auto local_data = v.data();
    ar(cereal::binary_data(local_data, 3)); // fails
    //ar(cereal::binary_data(v.data(), 3)); // works
}

int main(int argc, char* argv[])
{
    std::ofstream file("test.dat", std::fstream::binary);

    cereal::BinaryOutputArchive archive(file);

    MyVector v;
    archive(v);
}

import sys
import unittest

def collect_tests(item, granularity = -1):
    has_errors = False
    test_classes = set()
    if isinstance(item, unittest.loader._FailedTest):
        print(item._exception, file=sys.stderr)
        has_errors = True
    elif isinstance(item, unittest.TestCase):
        test_id_parts = item.id().split(".")
        test_classes.add(".".join(test_id_parts[:granularity]))
    else:
        for child in item:
            (other_classes, other_errors) = collect_tests(child, granularity)
            test_classes.update(other_classes)
            has_errors = has_errors or other_errors
    return (test_classes, has_errors)

root_test_suite = unittest.defaultTestLoader.discover(sys.argv[1])
(tests, errors) = collect_tests(root_test_suite, -1)

for item in sorted(list(tests)):
    print(item)

if errors:
    exit(-1)
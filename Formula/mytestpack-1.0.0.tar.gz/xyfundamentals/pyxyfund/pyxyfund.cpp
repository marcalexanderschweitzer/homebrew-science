//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <xyfund/python.hpp>

//===========================================================================================================
// NOLINTNEXTLINE(cppcoreguidelines-pro-bounds-pointer-arithmetic, cppcoreguidelines-pro-type-vararg, cppcoreguidelines-avoid-non-const-global-variables, readability-else-after-return, readability-isolate-declaration, misc-non-private-member-variables-in-classes)
PYBIND11_MODULE(xyfund, mod)
{
    xyfund::export_all_to_python(mod);
}

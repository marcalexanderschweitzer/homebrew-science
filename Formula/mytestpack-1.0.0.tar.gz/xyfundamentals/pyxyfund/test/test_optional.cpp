//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <xyfund/optional.hpp>
#include <xyfund/python.hpp>

#include "testing.hpp"

struct int_holder
{
    int value_ = 0; // NOLINT(misc-non-private-member-variables-in-classes)
};

struct int_holder_holder
{
    int_holder data_; // NOLINT(misc-non-private-member-variables-in-classes)

    xyfund::optional_ref<int_holder> get_if(bool get)
    {
        return get ? xyfund::make_optional_ref(data_) : xyfund::nullopt;
    }
    xyfund::optional_ref<const int_holder> get_const_if(bool get) const
    {
        return get ? xyfund::make_optional_cref(data_) : xyfund::nullopt;
    }
};

void pyxyfund::testing::export_optional_testing_to_python(pybind11::module& mod)
{
    namespace py = pybind11;

    py::class_<int_holder>(mod, "IntHolder")
        .def(py::init<>())
        .def_readwrite("value", &int_holder::value_);

    mod.def("double_or_zero", [](const xyfund::optional_ref<int_holder>& x) -> int {
        return (x ? x.value().value_ : 0) * 2;
    });
    mod.def("copy_double_or_zero", [](xyfund::optional_ref<int_holder> x) -> int { // NOLINT(performance-unnecessary-value-param)
        return (x ? x.value().value_ : 0) * 2;
    });

    mod.def("const_double_or_zero", [](const xyfund::optional_ref<const int_holder>& x) -> int {
        return (x ? x.value().value_ : 0) * 2;
    });
    mod.def("copy_const_double_or_zero", [](xyfund::optional_ref<const int_holder> x) -> int { // NOLINT(performance-unnecessary-value-param)
        return (x ? x.value().value_ : 0) * 2;
    });

    mod.def("set_if_non_zero", [](const xyfund::optional_ref<int_holder>& x, int y) {
        if(y == 0) return;
        x->value_ = y;
    });
    mod.def("copy_set_if_non_zero", [](xyfund::optional_ref<int_holder> x, int y) { // NOLINT(performance-unnecessary-value-param)
        if(y == 0) return;
        x->value_ = y;
    });

    py::class_<int_holder_holder>(mod, "IntHolderHolder")
        .def(py::init<>())
        .def_readwrite("data", &int_holder_holder::data_)
        .def("get_if", &int_holder_holder::get_if)
        .def("get_const_if", &int_holder_holder::get_const_if);
}

import unittest

import xyfund_testing

# import time
# time.sleep(5)

class TestOptionalRef(unittest.TestCase):

    def test_optional_ref(self):
        holder = xyfund_testing.IntHolder()
        holder.value = 4

        self.assertEqual(xyfund_testing.double_or_zero(holder), 8)
        self.assertEqual(xyfund_testing.double_or_zero(None), 0)

        self.assertEqual(xyfund_testing.copy_double_or_zero(holder), 8)
        self.assertEqual(xyfund_testing.copy_double_or_zero(None), 0)

        self.assertEqual(xyfund_testing.const_double_or_zero(holder), 8)
        self.assertEqual(xyfund_testing.const_double_or_zero(None), 0)

        self.assertEqual(xyfund_testing.copy_const_double_or_zero(holder), 8)
        self.assertEqual(xyfund_testing.copy_const_double_or_zero(None), 0)

        holder.value = 4
        xyfund_testing.set_if_non_zero(holder, 0)
        self.assertEqual(holder.value, 4)
        xyfund_testing.set_if_non_zero(holder, 8)
        self.assertEqual(holder.value, 8)

        holder.value = 4
        xyfund_testing.copy_set_if_non_zero(holder, 0)
        self.assertEqual(holder.value, 4)
        xyfund_testing.copy_set_if_non_zero(holder, 8)
        self.assertEqual(holder.value, 8)

        holder = xyfund_testing.IntHolderHolder()
        holder.data.value = 4

        self.assertIsNone(holder.get_if(False))
        self.assertIsNotNone(holder.get_if(True))
        self.assertEqual(holder.get_if(True).value, 4)
        holder.get_if(True).value = 8
        self.assertEqual(holder.data.value, 8)

        holder.data.value = 4
        self.assertIsNone(holder.get_const_if(False))
        self.assertIsNotNone(holder.get_const_if(True))
        self.assertEqual(holder.get_const_if(True).value, 4)
        # NOTE: the const qualifier is actually dropped at the C++ -> Python conversion!
        holder.get_const_if(True).value = 8
        self.assertEqual(holder.data.value, 8)


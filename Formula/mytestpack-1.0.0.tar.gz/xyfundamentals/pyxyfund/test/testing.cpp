//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include "testing.hpp"

//===========================================================================================================
// NOLINTNEXTLINE(cppcoreguidelines-pro-bounds-pointer-arithmetic, cppcoreguidelines-pro-type-vararg, cppcoreguidelines-avoid-non-const-global-variables, readability-else-after-return, readability-isolate-declaration, misc-non-private-member-variables-in-classes)
PYBIND11_MODULE(xyfund_testing, mod)
{
    mod.doc() = "XYFUND testing module";

    pyxyfund::testing::export_optional_testing_to_python(mod);
}

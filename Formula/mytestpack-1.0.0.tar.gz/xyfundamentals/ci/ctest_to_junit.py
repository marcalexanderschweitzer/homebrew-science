
import sys
import glob
import argparse
import xml.etree.ElementTree as et

parser = argparse.ArgumentParser(description='Convert a CTest XML to a JUnit XML.')
parser.add_argument('--input', metavar='DIR', type=str, required=True,
                    help='Path to the input directory containing the ctest XML output file.')
parser.add_argument('--output', metavar='DIR', type=str, required=True,
                    help='Path to the output JUnit report file to be written.')

args = parser.parse_args()

input_files = glob.glob(f"{args.input}/*/Test.xml")
if len(input_files) != 1:
    sys.exit('Found more than one CTest XMl file: {}'.format(files.join(", ")))

input_file = input_files[0]

with open(input_file, "r", encoding="utf-8") as file:
    input_tree = et.parse(file)

input_root = input_tree.getroot()

testsuite = et.Element("testsuite")

testsuite.set("name", input_root.attrib.get("BuildName", "ctest"))
testsuite.set("hostname", input_root.attrib.get("Hostname", "unknown"))

properties = et.SubElement(testsuite, "properties")
for (key, value) in input_root.attrib.items():
    prop = et.SubElement(properties, "property")
    prop.set("name", key)
    prop.set("value", value)

total_time      = 0.0

number_of_tests = 0
passed_tests    = 0
failed_tests    = 0
skipped_tests   = 0

for test in input_root.findall(".//Testing/Test"):
    number_of_tests += 1

    testcase = et.SubElement(testsuite,"testcase")

    testcase.set("classname", "ctest")
    testcase.set("name", test.find("Name").text)

    time = test.find("./Results/NamedMeasurement[@name='Execution Time']/Value")
    if time is not None:
        total_time += float(time.text)
        testcase.set("time", time.text)

    out = et.SubElement(testcase, "system-out")
    out.text = test.find("./Results/Measurement/Value").text

    status = test.get("Status")
    testcase.set("status", status)
    if status == "passed":
        passed_tests += 1
    elif status == "failed":
        failed_tests += 1
        failure = et.SubElement(testcase, "failure")
        failure.set("message", "program execution failed")
        failure.text = out.text
    elif status == "notrun":
        skipped_tests += 1

testsuite.set("time", str(total_time))

testsuite.set("tests", str(number_of_tests))
testsuite.set("failures", str(failed_tests))
testsuite.set("skipped", str(skipped_tests))
testsuite.set("disabled", "0")
testsuite.set("errors", "0")

with open(args.output, "w") as file:
    file.write(et.tostring(testsuite, encoding='unicode'))

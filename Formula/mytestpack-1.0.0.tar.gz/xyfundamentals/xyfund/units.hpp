//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include "xyfund/units/equals.hpp"
#include "xyfund/units/quantity.hpp"
#include "xyfund/units/si/prefix.hpp"
#include "xyfund/units/si/time.hpp"
#include "xyfund/units/si/length.hpp"
#include "xyfund/units/si/mass.hpp"
#include "xyfund/units/si/temperature.hpp"
#include "xyfund/units/si/current.hpp"
#include "xyfund/units/si/amount_of_substance.hpp"
#include "xyfund/units/si/luminous_intensity.hpp"
#include "xyfund/units/si/angle.hpp"
#include "xyfund/units/si/derived_units.hpp"
#include "xyfund/units/unit.hpp"

//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#ifdef _WIN32
#    include <Windows.h>
#    include <direct.h>
#    include <shlobj.h>
#else
#    include <dlfcn.h>
#    include <sys/stat.h>
#    include <unistd.h>
#endif

#include <array>
#include <string>

#include <xyfund/algorithm.hpp>
#include <xyfund/assert.hpp>
#include <xyfund/filesystem.hpp>
#include <xyfund/optional.hpp>

#ifdef _WIN32
EXTERN_C IMAGE_DOS_HEADER __ImageBase; //NOLINT(readability-identifier-naming)
#endif

namespace xyfund {

inline filesystem::path get_home_dir()
{
#ifdef _WIN32
    std::array<WCHAR, MAX_PATH> path{};
    SHGetFolderPathW(nullptr, CSIDL_PROFILE, nullptr, 0, path.data());

    return path.data();
#else  // UNIX
    const auto* const home_dir = std::getenv("HOME");
    xyfund_assert(home_dir != nullptr);
    // if(home_dir == nullptr)
    // {
    //     home_dir = getpwuid(getuid())->pw_dir;
    // }
    return home_dir;
#endif // _WIN32
}

inline filesystem::path get_module_dir()
{
#ifdef _WIN32
    std::array<WCHAR, MAX_PATH> path{};
    GetModuleFileNameW((HINSTANCE)&__ImageBase, path.data(), static_cast<DWORD>(path.size())); // NOLINT(cppcoreguidelines-pro-type-cstyle-cast)

    return filesystem::path(path.data()).parent_path();
#else  // UNIX
    Dl_info    info;
    const auto result = ::dladdr(reinterpret_cast<const void*>(reinterpret_cast<intptr_t>(&get_module_dir)), &info); // NOLINT(cppcoreguidelines-pro-type-reinterpret-cast)

    if(result == 0)
    {
        // TODO: error
        return "";
    }

    return filesystem::path(info.dli_fname).parent_path();
#endif // _WIN32
}

inline optional<std::string> get_environment_variable(const std::string& name)
{
#ifdef _WIN32
    const auto utf16_name  = utf8_to_utf16(name);
    const auto result_size = GetEnvironmentVariableW(utf16_name.c_str(), nullptr, 0);
    if(result_size == 0) return nullopt;

    std::wstring utf16_result(result_size, L'\0');

    auto result_size_2 = GetEnvironmentVariableW(utf16_name.c_str(), utf16_result.data(), result_size);
    xyfund_assert(result_size_2 + 1 == result_size);
    utf16_result.pop_back();
    return utf16_to_utf8(utf16_result);
#else
    const auto* const result = std::getenv(name.c_str());
    if(result == nullptr) return nullopt;

    return std::string(result);
#endif
}

} // namespace xyfund

//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#ifdef _WIN32
#    include <Windows.h>
#endif

#include <cctype>
#include <cstring>
#include <locale>
#include <sstream>
#include <string>

#include "xyfund/span.hpp"
#include "xyfund/types.hpp"

namespace xyfund {

namespace detail {

inline std::size_t length(const char* s)
{
    return std::strlen(s);
}

inline std::size_t length(const char16_t* s)
{
    return std::char_traits<char16_t>::length(s);
}

inline std::size_t length(const char32_t* s)
{
    return std::char_traits<char32_t>::length(s);
}

inline std::size_t length(const wchar_t* s)
{
    return std::wcslen(s);
}

inline bool is_char_ptr(char* /*unused*/)
{
    return true;
}

inline bool is_char_ptr(const char* /*unused*/)
{
    return true;
}

inline bool is_char_ptr(char16_t* /*unused*/)
{
    return true;
}

inline bool is_char_ptr(const char16_t* /*unused*/)
{
    return true;
}

inline bool is_char_ptr(char32_t* /*unused*/)
{
    return true;
}

inline bool is_char_ptr(const char32_t* /*unused*/)
{
    return true;
}

inline bool is_char_ptr(wchar_t* /*unused*/)
{
    return true;
}

inline bool is_char_ptr(const wchar_t* /*unused*/)
{
    return true;
}

template<typename T>
inline std::false_type is_char_ptr(const T& /*unused*/)
{
    return {};
}

template<typename T>
inline span<T> make_range(T* r, bool /*is_char_ptr*/)
{
    return span<T>(r, r + length(r)); // NOLINT(cppcoreguidelines-pro-bounds-pointer-arithmetic)
}

template<typename T>
inline auto make_range(T& r, std::false_type /*is_char_ptr*/)
{
    return span<std::remove_pointer_t<decltype(r.data())>>(r);
}

} // namespace detail

template<typename R>
inline auto as_literal(R& r)
{
    return detail::make_range(r, detail::is_char_ptr(r));
}

template<typename R>
inline auto as_literal(const R& r)
{
    return detail::make_range(r, detail::is_char_ptr(r));
}

template<typename C, std::size_t N>
inline auto as_literal(C (&arr)[N]) // NOLINT(cppcoreguidelines-avoid-c-arrays, modernize-avoid-c-arrays)
{
    return detail::make_range(static_cast<C*>(arr), detail::is_char_ptr(static_cast<C*>(arr)));
}

template<typename C, std::size_t N>
inline auto as_literal(const C (&arr)[N]) // NOLINT(cppcoreguidelines-avoid-c-arrays, modernize-avoid-c-arrays)
{
    return detail::make_range(static_cast<const C*>(arr), detail::is_char_ptr(static_cast<const C*>(arr)));
}

//===========================================================================================================
struct is_equal
{
    template<typename T1, typename T2>
    bool operator()(const T1& arg1, const T2& arg2) const
    {
        return arg1 == arg2;
    }
};

//===========================================================================================================
struct is_iequal
{
    is_iequal(const std::locale& loc = std::locale()) :
        loc_(loc)
    {}

    template<typename T1, typename T2>
    bool operator()(const T1& arg1, const T2& arg2) const
    {
        return std::toupper(arg1, loc_) == std::toupper(arg2, loc_);
    }

private:
    std::locale loc_;
};

//===========================================================================================================
template<typename R1, typename R2, typename Pred>
bool equals(const R1& input, const R2& test, Pred comp)
{
    auto&& input_literal = as_literal(input);
    auto&& test_literal  = as_literal(test);

    auto input_iter = std::cbegin(input_literal);
    auto test_iter  = std::cbegin(test_literal);

    const auto input_end = std::cend(input_literal);
    const auto test_end  = std::cend(test_literal);

    for(; input_iter != input_end && test_iter != test_end; ++input_iter, ++test_iter)
    {
        if(!comp(*input_iter, *test_iter))
        {
            return false;
        }
    }
    return (test_iter == test_end) && (input_iter == input_end);
}

//===========================================================================================================
template<typename R1, typename R2>
bool equals(const R1& input, const R2& test)
{
    return xyfund::equals(input, test, is_equal());
}

//===========================================================================================================
template<typename R1, typename R2>
bool iequals(const R1& input, const R2& test, const std::locale& loc = std::locale())
{
    return xyfund::equals(input, test, is_iequal(loc));
}

//===========================================================================================================
template<typename R1, typename R2, typename Pred>
bool starts_with(const R1& input, const R2& test, Pred comp)
{
    auto&& input_literal = as_literal(input);
    auto&& test_literal  = as_literal(test);

    auto input_iter = std::cbegin(input_literal);
    auto test_iter  = std::cbegin(test_literal);

    const auto input_end = std::cend(input_literal);
    const auto test_end  = std::cend(test_literal);

    for(; input_iter != input_end && test_iter != test_end; ++input_iter, ++test_iter)
    {
        if(!comp(*input_iter, *test_iter))
        {
            return false;
        }
    }
    return test_iter == test_end;
}

//===========================================================================================================
template<typename R1, typename R2>
bool starts_with(const R1& input, const R2& test)
{
    return xyfund::starts_with(input, test, is_equal());
}

//===========================================================================================================
template<typename R1, typename R2>
bool istarts_with(const R1& input, const R2& test, const std::locale& loc = std::locale())
{
    return xyfund::starts_with(input, test, is_iequal(loc));
}

//===========================================================================================================
template<typename R1, typename R2, typename Pred>
bool ends_with(const R1& input, const R2& test, Pred comp)
{
    auto&& input_literal = as_literal(input);
    auto&& test_literal  = as_literal(test);

    auto input_iter = std::crbegin(input_literal);
    auto test_iter  = std::crbegin(test_literal);

    const auto input_end = std::crend(input_literal);
    const auto test_end  = std::crend(test_literal);

    for(; input_iter != input_end && test_iter != test_end; ++input_iter, ++test_iter)
    {
        if(!comp(*input_iter, *test_iter))
        {
            return false;
        }
    }
    return test_iter == test_end;
}

//===========================================================================================================
template<typename R1, typename R2>
bool ends_with(const R1& input, const R2& test)
{
    return xyfund::ends_with(input, test, is_equal());
}

//===========================================================================================================
template<typename R1, typename R2>
bool iends_with(const R1& input, const R2& test, const std::locale& loc = std::locale())
{
    return xyfund::ends_with(input, test, is_iequal(loc));
}

//===========================================================================================================
template<typename Range, typename Value = typename Range::value_type>
Value join(const Range& elements, const char* delimiter)
{
    std::ostringstream os;
    auto               iter     = begin(elements);
    const auto         end_iter = end(elements);

    if(iter != end_iter)
    {
        std::copy(iter, prev(end_iter), std::ostream_iterator<Value>(os, delimiter));
        iter = prev(end_iter);
    }
    if(iter != end_iter)
    {
        os << *iter;
    }

    return os.str();
}

//===========================================================================================================
#ifdef _WIN32
inline std::wstring utf8_to_utf16(const std::string& str)
{
    std::wstring output;
    const auto   size = MultiByteToWideChar(CP_UTF8, 0, str.c_str(), -1, nullptr, 0);
    if(size == 0) return output;
    output.resize(size - 1);
    MultiByteToWideChar(CP_UTF8, 0, str.c_str(), -1, output.data(), static_cast<int>(size) - 1);
    return output;
}

inline std::string utf16_to_utf8(const std::wstring& str)
{
    std::string output;
    const auto  size = WideCharToMultiByte(CP_UTF8, 0, str.c_str(), -1, nullptr, 0, nullptr, nullptr);
    if(size == 0) return output;
    output.resize(size - 1);
    WideCharToMultiByte(CP_UTF8, 0, str.c_str(), -1, output.data(), static_cast<int>(size) - 1, nullptr, nullptr);
    return output;
}
#endif // _WIN32

} // namespace xyfund

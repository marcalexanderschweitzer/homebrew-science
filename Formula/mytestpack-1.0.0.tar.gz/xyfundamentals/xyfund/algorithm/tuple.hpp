//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <tuple>
#include <utility>

#include "xyfund/types.hpp"

namespace xyfund {

//===========================================================================================================
template<typename T>
constexpr auto make_tuple(T&& obj)
{
    return std::make_tuple(std::forward<T>(obj));
}

template<typename... T>
constexpr std::tuple<T...>&& make_tuple(std::tuple<T...>&& obj)
{
    return std::move(obj);
}

template<typename... T>
constexpr std::tuple<T...> make_tuple(std::tuple<T...>& obj)
{
    return obj;
}

template<typename... T>
constexpr std::tuple<T...> make_tuple(const std::tuple<T...>& obj)
{
    return obj;
}

//===========================================================================================================
template<std::size_t I = 0, typename F, typename T>
inline std::enable_if_t<I == std::tuple_size<T>::value> for_each(T& /*tuple*/, F&& /*func*/) {}

template<std::size_t I = 0, typename F, typename T>
inline std::enable_if_t<I < std::tuple_size<T>::value> for_each(T& tuple, F&& func)
{
    func(std::get<I>(tuple));
    for_each<I + 1>(tuple, std::forward<F>(func));
}

//===========================================================================================================
template<std::size_t I = 0, typename F, typename T>
inline std::enable_if_t<I == std::tuple_size<T>::value> for_each_with_index(T& /*tuple*/, F&& /*func*/) {}

template<std::size_t I = 0, typename F, typename T>
inline std::enable_if_t<I < std::tuple_size<T>::value> for_each_with_index(T& tuple, F&& func)
{
    func(std::integral_constant<index_t, I>(), std::get<I>(tuple));
    for_each_with_index<I + 1>(tuple, func);
}

//===========================================================================================================
template<typename T, std::size_t I, typename... Values>
struct unpack;

template<typename T, std::size_t I>
struct unpack<T, I>
{
    static constexpr void apply(T* /*data*/) {}
};

template<typename T, std::size_t I, typename U, typename... Values>
struct unpack<T, I, U, Values...>
{
    static constexpr void apply(T* data, U&& value, Values&&... values)
    {
        data[I] = std::forward<U>(value); // NOLINT(cppcoreguidelines-pro-bounds-pointer-arithmetic)
        unpack<T, I + 1, Values...>::apply(data, std::forward<Values>(values)...);
    }
};

//===========================================================================================================
template<typename T, std::size_t I, std::size_t S, std::size_t E, typename... Values>
struct unpack_n;

template<typename T, std::size_t I, std::size_t S, std::size_t E>
struct unpack_n<T, I, S, E>
{
    static constexpr void apply(T* /*data*/) {}
};

template<typename T, std::size_t S, std::size_t E, typename U, typename... Values>
struct unpack_n<T, E, S, E, U, Values...>
{
    static constexpr void apply(T* /*data*/, U&& /*value*/, Values&&... /*values*/) {}
};

template<typename T, std::size_t I, std::size_t S, std::size_t E, typename U, typename... Values>
struct unpack_n<T, I, S, E, U, Values...>
{
    static constexpr void apply(T* data, U&& value, Values&&... values)
    {
        if constexpr(I >= S)
        {
            data[I - S] = std::forward<U>(value); // NOLINT(cppcoreguidelines-pro-bounds-pointer-arithmetic)
        }
        else
        {
            (void)value;
        }
        unpack_n<T, I + 1, S, E, Values...>::apply(data, std::forward<Values>(values)...);
    }
};

} // namespace xyfund

//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <algorithm>

#include "xyfund/types.hpp"
#include "xyfund/utility.hpp"

namespace xyfund {

template<typename It>
It stable_unique(It begin, const It end)
{
    std::vector<It> v;
    v.reserve(static_cast<size_t>(std::distance(begin, end)));
    for(It i = begin; i != end; ++i)
    {
        v.push_back(i);
    }
    std::sort(v.begin(), v.end(), [](const auto& a, const auto& b) { return *a < *b; }); // NOLINT(clang-analyzer-cplusplus.Move)
    v.erase(std::unique(v.begin(), v.end(), [](const auto& a, const auto& b) { return *a == *b; }), v.end());
    std::sort(v.begin(), v.end());
    xyfund::index_t j = 0;
    for(It i = begin; i != end && j != xyfund::ssize(v); ++i)
    {
        if(i == v[j])
        {
            using std::iter_swap;
            iter_swap(i, begin);
            ++j;
            ++begin;
        }
    }
    return begin;
}

//===========================================================================================================
template<typename C>
inline void remove_duplicates(C& container)
{
    std::sort(container.begin(), container.end());
    container.erase(std::unique(container.begin(), container.end()), container.end());
}

//===========================================================================================================
template<typename C, typename LP, typename EP>
inline void remove_duplicates(C& container, LP&& less_predicate, EP&& equals_predicate)
{
    std::sort(container.begin(), container.end(), std::forward<LP>(less_predicate));
    container.erase(std::unique(container.begin(), container.end(), std::forward<EP>(equals_predicate)), container.end());
}

//===========================================================================================================
template<typename C>
inline void stable_remove_duplicates(C& container)
{
    container.erase(stable_unique(container.begin(), container.end()), container.end());
}

} // namespace xyfund

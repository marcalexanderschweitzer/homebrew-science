//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <random>

#include "xyfund/assert.hpp"

namespace xyfund {

//! Generates a uniformly distributed random number in the range [min, max).
//!
//! It is required that min < max.
//!
//! @tparam T Has to be an arithmetic type (integral or floating point).
//!           NOTE: (unsigned) char is not yet supported since it is not an IntType by the definition of the C++ standard
//!                 and therefor it is not supported by std::uniform_int_distribution (see http://open-std.org/JTC1/SC22/WG21/docs/lwg-active.html#2326).
//! @param min Lower bound of the interval.
//! @param max Upper bound of the interval.
//! @return A uniformly sampled value in the range [min, max).
template<typename T>
T make_random(T min, T max)
{
    xyfund_assert(min < max);

    thread_local static std::mt19937 engine(std::random_device{}());

    static_assert(std::is_arithmetic<T>::value, "Can not generate random number for non-arithmetic types");

    using distribution_type = std::conditional_t<
        std::is_floating_point<T>::value,
        std::uniform_real_distribution<T>,
        std::uniform_int_distribution<T>>;

    return distribution_type(min, std::is_integral<T>::value ? max - 1 : max)(engine);
}

//! Creates a uniform distributed random number in the interval [0, max).
//!
//! @tparam T Has to be an arithmetic type (integral or floating point).
//!           NOTE: (unsigned) char is not yet supported since it is not an IntType by the definition of the C++ standard
//!                 and therefor it is not supported by std::uniform_int_distribution (see http://open-std.org/JTC1/SC22/WG21/docs/lwg-active.html#2326).
//! @param max Upper bound of the interval.
//! @return A uniformly sampled value in the range [0, max).
template<typename T>
T make_random(T max = T(1))
{
    return make_random(T(0), max);
}

template<typename T>
bool is_even(T value)
{
    return (value % 2) == 0;
}

template<typename T>
bool is_odd(T value)
{
    return !is_even(value);
}

} // namespace xyfund

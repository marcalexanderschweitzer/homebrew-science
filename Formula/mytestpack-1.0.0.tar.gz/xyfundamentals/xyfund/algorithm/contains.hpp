//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <algorithm>

namespace xyfund {

template<typename C, typename T>
bool contains(const C& container, const T& element)
{
    return container.find(element) != container.end();
}

} // namespace xyfund

//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <array>
#include <sstream>
#include <string>

#ifdef XYFUND_HAVE_CEREAL
#    include <cereal/cereal.hpp>
#endif // XYFUND_HAVE_CEREAL

#include "xyfund/assert.hpp"
#include "xyfund/math.hpp"
#include "xyfund/types.hpp"
#include "xyfund/utility.hpp"

namespace xyfund {

//===========================================================================================================
template<std::size_t Size>
class semantic_version
{
public:
    constexpr semantic_version() = default;

    constexpr semantic_version(const semantic_version& other)     = default;
    constexpr semantic_version(semantic_version&& other) noexcept = default;

    constexpr semantic_version& operator=(const semantic_version& other) = default;
    constexpr semantic_version& operator=(semantic_version&& other) noexcept = default;

    ~semantic_version() = default;

    template<typename... Vs, std::enable_if_t<sizeof...(Vs) + 1 == Size>* = nullptr>
    constexpr semantic_version(int v0, Vs... vs);

    constexpr int operator[](std::size_t index) const;

    constexpr bool operator==(const semantic_version& other) const;
    constexpr bool operator!=(const semantic_version& other) const;
    constexpr bool operator<(const semantic_version& other) const;
    constexpr bool operator<=(const semantic_version& other) const;
    constexpr bool operator>(const semantic_version& other) const;
    constexpr bool operator>=(const semantic_version& other) const;

    std::string to_string() const;

    constexpr long long                     to_number(int digits) const;
    static constexpr semantic_version<Size> from_number(long long version, int digits);

private:
    std::array<int, Size> data_;

#ifdef XYFUND_HAVE_CEREAL
    template<class Archive>
    void serialize(Archive& archive);
#endif
};

//===========================================================================================================
template<std::size_t Size>
std::ostream& operator<<(std::ostream& stream, const semantic_version<Size>& v)
{
    if constexpr(Size > 0)
    {
        stream << v[0];
        for(std::size_t i = 1; i < Size; ++i)
        {
            stream << '.';
            stream << v[i];
        }
    }
    return stream;
}

//===========================================================================================================
template<std::size_t Size>
template<typename... Vs, std::enable_if_t<sizeof...(Vs) + 1 == Size>*>
constexpr semantic_version<Size>::semantic_version(int v0, Vs... vs) :
    data_{v0, vs...}
{}

//===========================================================================================================
template<std::size_t Size>
constexpr int semantic_version<Size>::operator[](std::size_t index) const
{
    return data_.at(index);
}

//===========================================================================================================
template<std::size_t Size>
constexpr bool semantic_version<Size>::operator==(const semantic_version& other) const
{
    for(xyfund::index_t i = 0; i < xyfund::ssize(data_); ++i)
    {
        if(data_.at(i) != other.data_.at(i)) return false;
    }
    return true;
}

//===========================================================================================================
template<std::size_t Size>
constexpr bool semantic_version<Size>::operator!=(const semantic_version& other) const
{
    return !(*this == other);
}

//===========================================================================================================
template<std::size_t Size>
constexpr bool semantic_version<Size>::operator<(const semantic_version& other) const
{
    for(xyfund::index_t i = 0; i < xyfund::ssize(data_); ++i)
    {
        if(data_.at(i) < other.data_.at(i)) return true;
        if(other.data_.at(i) < data_.at(i)) return false;
    }
    return false;
}

//===========================================================================================================
template<std::size_t Size>
constexpr bool semantic_version<Size>::operator<=(const semantic_version& other) const
{
    return !(other < *this);
}

//===========================================================================================================
template<std::size_t Size>
constexpr bool semantic_version<Size>::operator>(const semantic_version& other) const
{
    return other < *this;
}

//===========================================================================================================
template<std::size_t Size>
constexpr bool semantic_version<Size>::operator>=(const semantic_version& other) const
{
    return !(*this < other);
}

//===========================================================================================================
template<std::size_t Size>
std::string semantic_version<Size>::to_string() const
{
    std::stringstream str;
    str << (*this);
    return str.str();
}

//===========================================================================================================
template<std::size_t Size>
constexpr long long semantic_version<Size>::to_number(int digits) const
{
    long long result = 0;

    const auto digit_factor = xyfund::power_of_10<long long>(digits);
    for(xyfund::index_t i = 0; i < xyfund::ssize(data_); ++i)
    {
        result *= digit_factor;
        result += static_cast<long long>(data_.at(i));
        xyfund_assert(data_.at(i) < digit_factor);
    }
    return result;
}

//===========================================================================================================
template<std::size_t Size>
/*static*/ constexpr semantic_version<Size> semantic_version<Size>::from_number(long long version, int digits)
{
    semantic_version<Size> result{};

    const auto digit_factor = xyfund::power_of_10<long long>(digits);
    for(xyfund::index_t i = xyfund::ssize(result.data_) - 1; i >= 0; --i)
    {
        result.data_.at(i) = static_cast<int>(version % digit_factor);
        version /= digit_factor;
    }
    return result;
}

#ifdef XYFUND_HAVE_CEREAL
//===========================================================================================================
template<std::size_t Size>
template<class Archive>
void semantic_version<Size>::serialize(Archive& archive)
{
    archive(data_);
}
#endif // XYFUND_HAVE_CEREAL

} // namespace xyfund

//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <cstring>

namespace xyfund {

template<typename T, std::size_t N>
struct fixed_string
{
    using iterator       = T*;
    using const_iterator = const T*;

    constexpr fixed_string(T character) noexcept
    {
        data_[0] = character; //NOLINT(cppcoreguidelines-pro-bounds-constant-array-index)
    }

    constexpr fixed_string(const T (&data)[N + 1]) noexcept //NOLINT(cppcoreguidelines-avoid-c-arrays,,modernize-avoid-c-arrays)
    {
        for(std::size_t i = 0; i < N; ++i)
        {
            data_[i] = data[i]; //NOLINT(cppcoreguidelines-pro-bounds-constant-array-index)
        }
    }

    constexpr const T* c_str() const noexcept { return data_; }

    constexpr iterator       begin() noexcept { return std::begin(data_); }
    constexpr const_iterator begin() const noexcept { return std::begin(data_); }
    constexpr iterator       end() noexcept { return std::end(data_); }
    constexpr const_iterator end() const noexcept { return std::end(data_); }

    constexpr const T& operator[](std::size_t index) const noexcept { return data_[index]; }; //NOLINT(cppcoreguidelines-pro-bounds-constant-array-index)
    constexpr T        operator[](std::size_t index) noexcept { return data_[index]; };       //NOLINT(cppcoreguidelines-pro-bounds-constant-array-index)

    template<std::size_t M>
    constexpr friend fixed_string<T, N + M> operator+(const fixed_string& lhs, const fixed_string<T, M>& rhs) noexcept
    {
        T data[N + M + 1] = {}; //NOLINT(cppcoreguidelines-avoid-c-arrays,modernize-avoid-c-arrays)

        for(size_t i = 0; i < N; ++i)
        {
            data[i] = lhs[i]; //NOLINT(cppcoreguidelines-pro-bounds-constant-array-index)
        }
        for(size_t i = 0; i < M; ++i)
        {
            data[N + i] = rhs[i]; //NOLINT(cppcoreguidelines-pro-bounds-constant-array-index)
        }

        return fixed_string<T, N + M>(data);
    }

    template<typename T2, std::size_t N2>
    friend constexpr bool operator==(const fixed_string&         lhs,
                                     const fixed_string<T2, N2>& rhs)
    {
        if constexpr (N != N2)
        {
            return false;
        }
        else
        {
            auto       first1 = lhs.begin(); //NOLINT(readability-qualified-auto)
            const auto last1  = lhs.end();   //NOLINT(readability-qualified-auto)
            auto       first2 = rhs.begin(); //NOLINT(readability-qualified-auto)

            for(; first1 != last1; ++first1, ++first2)
            {
                if(!(*first1 == *first2))
                {
                    return false;
                }
            }

            return true;
        }
    }

    friend constexpr bool operator==(const fixed_string& lhs,
                                     const char*         rhs)
    {
        const auto rhs_len = strlen(rhs);

        if(N != rhs_len)
        {
            return false;
        }

        auto lhs_iter = std::begin(lhs); //NOLINT(readability-qualified-auto)

        while(*rhs != 0)
        {
            if(*rhs != *lhs_iter)
            {
                return false;
            }

            lhs_iter++;
            rhs++; //NOLINT(cppcoreguidelines-pro-bounds-pointer-arithmetic)
        }

        return true;
    }

    friend std::ostream& operator<<(std::ostream& os, const fixed_string& txt)
    {
        return os << txt.c_str();
    }

private:
    T data_[N + 1] = {}; //NOLINT(cppcoreguidelines-avoid-c-arrays,modernize-avoid-c-arrays)
};

namespace detail {

template<std::intmax_t N>
constexpr auto int_to_string_impl()
{
    if constexpr(N <= 9)
    {
        return fixed_string<char, 1>('0' + N);
    }
    else
    {
        constexpr auto current_digit = N % 10;
        constexpr auto remaining_digits = N / 10;

        return int_to_string_impl<remaining_digits>() + fixed_string<char, 1>('0' + current_digit);
    }
}

template<std::intmax_t N>
constexpr auto int_to_string()
{
    constexpr auto is_positive = N >= 0;

    if constexpr(is_positive)
    {
        return int_to_string_impl<N>();
    }
    else
    {
        return fixed_string<char, 1>("-") + int_to_string_impl<-N>();
    }
}

}

template<std::intmax_t N, typename FixedString>
constexpr auto append_power_to_string(const FixedString& string)
{
    return string + fixed_string<char, 1>('^') + detail::int_to_string<N>();
}

template<std::size_t N>
constexpr auto make_fixed_string(const char (&data)[N]) //NOLINT(cppcoreguidelines-avoid-c-arrays,modernize-avoid-c-arrays)
{
    return fixed_string<char, N - 1>(data);
}


} // namespace xyfund
//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

// Provides std::ssize. See https://wg21.link/p1227r0
// Provides gsl::at
// Provides gsl::narrow_cast

#include <cstddef>
#include <iterator>

#include "xyfund/assert.hpp"
#include "xyfund/types.hpp"

namespace xyfund {

//===========================================================================================================
template<typename C>
constexpr std::ptrdiff_t ssize(const C& c)
{
    return static_cast<std::ptrdiff_t>(std::size(c));
}

//===========================================================================================================
template<typename T, std::ptrdiff_t N>
constexpr std::ptrdiff_t ssize(const T (&/*arr*/)[N]) noexcept // NOLINT(cppcoreguidelines-avoid-c-arrays, modernize-avoid-c-arrays)
{
    return N;
}

//===========================================================================================================
template<typename T, std::size_t N>
constexpr T& at(T (&arr)[N], const index_t i) // NOLINT(cppcoreguidelines-avoid-c-arrays, modernize-avoid-c-arrays)
{
    xyfund_assert(i >= 0 && i < static_cast<index_t>(N));
    return arr[static_cast<std::size_t>(i)];
}

//===========================================================================================================
template<typename Container>
constexpr auto at(Container& cont, const index_t i) -> decltype(cont[cont.size()]) // NOLINT(cppcoreguidelines-pro-bounds-constant-array-index)
{
    xyfund_assert(i >= 0 && i < static_cast<index_t>(cont.size()));
    using size_type = decltype(cont.size());
    return cont[static_cast<size_type>(i)]; // NOLINT(cppcoreguidelines-pro-bounds-constant-array-index)
}

//===========================================================================================================
template<typename T>
constexpr T at(const std::initializer_list<T> cont, const index_t i)
{
    xyfund_assert(i >= 0 && i < static_cast<index_t>(cont.size()));
    return *(cont.begin() + i); //NOLINT(cppcoreguidelines-pro-bounds-pointer-arithmetic)
}

//===========================================================================================================
template<typename T, typename U>
constexpr T narrow_cast(U&& value) noexcept
{
    return static_cast<T>(std::forward<U>(value));
}

} // namespace xyfund

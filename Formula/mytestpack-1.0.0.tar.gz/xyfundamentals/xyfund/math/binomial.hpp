//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <stdexcept>
#include <type_traits>

#include "xyfund/math/factorial.hpp"

namespace xyfund {

template<typename T>
constexpr T binomial(int n, int k)
{
    if(k > n) throw std::domain_error("binomial: undefined for k > n");

    T result = 1;
    if(n <= detail::max_table_factorial<T>())
    {
        // Use fast table lookup:
        result = factorial<T>(n);
        result /= factorial<T>(n - k);
        result /= factorial<T>(k);
    }
    else
    {
        for(int i = 1; i <= k; ++i)
        {
            result *= (n + 1 - i);
            result /= i;
        }
    }
    return result;
}

} // namespace xyfund

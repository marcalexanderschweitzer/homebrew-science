//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <array>
#include <type_traits>

#include "xyfund/utility.hpp"

namespace xyfund {

template<typename T>
inline constexpr std::enable_if_t<std::is_integral_v<T>, T> power_of_10(int pow)
{
    constexpr std::array<uint64_t, 20> powers = {{1ULL,
                                                  10ULL,
                                                  100ULL,
                                                  1000ULL,
                                                  10000ULL,
                                                  100000ULL,
                                                  1000000ULL,
                                                  10000000ULL,
                                                  100000000ULL,
                                                  1000000000ULL,
                                                  10000000000ULL,
                                                  100000000000ULL,
                                                  1000000000000ULL,
                                                  10000000000000ULL,
                                                  100000000000000ULL,
                                                  1000000000000000ULL,
                                                  10000000000000000ULL,
                                                  100000000000000000ULL,
                                                  1000000000000000000ULL,
                                                  10000000000000000000ULL}};

    if(pow < 0 || pow >= xyfund::ssize(powers)) throw std::domain_error("power_of_10: invalid power");

    return static_cast<T>(powers[pow]); // NOLINT(cppcoreguidelines-pro-bounds-constant-array-index)
}

} // namespace xyfund

//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

namespace xyfund {
namespace math {

template<typename Result, typename T>
constexpr Result pow(T&& x, std::intmax_t exp)
{
    bool negative_exponent = false;
    if(exp < 0)
    {
        negative_exponent = true;
        exp               = -exp;
    }

    Result result = x;
    while(--exp)
    {
        result *= x;
    }

    return negative_exponent ? static_cast<Result>(1.0 / result) : result;
}

} // namespace math
} // namespace xyfund
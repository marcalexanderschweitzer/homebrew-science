//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <stdexcept>
#include <type_traits>

namespace xyfund {

template<typename T>
inline constexpr std::enable_if_t<std::is_integral_v<T>, T> power_of_2(int pow)
{
    if(pow < 0) throw std::domain_error("power_of_2: negative power not allowed");
    return static_cast<T>(1ULL << pow);
}

} // namespace xyfund

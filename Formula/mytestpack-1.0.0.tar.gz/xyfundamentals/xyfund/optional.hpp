//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

// Provides std::optional. See https://en.cppreference.com/w/cpp/utility/optional

#include <type_traits>

#if defined(XYFUND_HAVE_STD_ANY) && !defined(XYFUND_USE_BOOST_OPTIONAL)
#    include <optional>
#elif defined(XYFUND_HAVE_BOOST_OPTIONAL)
#    include <boost/optional.hpp>
#    include <boost/version.hpp>
#endif

#include <xyfund/assert.hpp>

namespace xyfund {

#if defined(XYFUND_HAVE_STD_OPTIONAL) && !defined(XYFUND_USE_BOOST_OPTIONAL)

template<typename T>
using optional = std::optional<T>;

using std::make_optional;

using std::bad_optional_access;

using nullopt_t                    = std::nullopt_t;
inline constexpr nullopt_t nullopt = std::nullopt;

using in_place_t                     = std::in_place_t;
inline constexpr in_place_t in_place = std::in_place;

#elif defined(XYFUND_HAVE_BOOST_OPTIONAL)

template<typename T>
using optional = boost::optional<T>;

using boost::make_optional;

using boost::bad_optional_access;

using nullopt_t = boost::none_t;
const nullopt_t nullopt{boost::none_t::init_tag{}};

using in_place_t = boost::in_place_init_t;
const in_place_t in_place{in_place_t::init_tag{}};

template<typename T, typename U>
constexpr bool operator==(const optional<T>& opt, const U& value)
{
    return bool(opt) ? *opt == value : false;
}

template<typename T, typename U>
constexpr bool operator==(const T& value, const optional<U>& opt)
{
    return bool(opt) ? value == *opt : false;
}

template<typename T, typename U>
constexpr bool operator!=(const optional<T>& opt, const U& value)
{
    return bool(opt) ? *opt != value : true;
}

template<typename T, typename U>
constexpr bool operator!=(const T& value, const optional<U>& opt)
{
    return bool(opt) ? value != *opt : true;
}

template<typename T, typename U>
constexpr bool operator<(const optional<T>& opt, const U& value)
{
    return bool(opt) ? *opt < value : true;
}

template<typename T, typename U>
constexpr bool operator<(const T& value, const optional<U>& opt)
{
    return bool(opt) ? value < *opt : false;
}

template<typename T, typename U>
constexpr bool operator<=(const optional<T>& opt, const U& value)
{
    return bool(opt) ? *opt <= value : true;
}

template<typename T, typename U>
constexpr bool operator<=(const T& value, const optional<U>& opt)
{
    return bool(opt) ? value <= *opt : false;
}

template<typename T, typename U>
constexpr bool operator>(const optional<T>& opt, const U& value)
{
    return bool(opt) ? *opt > value : false;
}

template<typename T, typename U>
constexpr bool operator>(const T& value, const optional<U>& opt)
{
    return bool(opt) ? value > *opt : true;
}

template<typename T, typename U>
constexpr bool operator>=(const optional<T>& opt, const U& value)
{
    return bool(opt) ? *opt >= value : false;
}

template<typename T, typename U>
constexpr bool operator>=(const T& value, const optional<U>& opt)
{
    return bool(opt) ? value >= *opt : true;
}

#else // XYFUND_HAVE_(STD/BOOST)_OPTIONAL
#    error "Can not build without 'optional' implementation"
#endif // XYFUND_HAVE_(STD/BOOST)_OPTIONAL


template<typename T, typename... Args>
optional<T> make_optional_if(bool condition, Args... args)
{
    if(condition) return optional<T>(xyfund::in_place, std::forward<Args>(args)...);
    return xyfund::nullopt;
}

template<typename T>
class optional_ref
{
public:
    using value_type = T;

    inline constexpr optional_ref() noexcept;
    inline /*constexpr*/ optional_ref(nullopt_t /*value*/) noexcept;

    inline constexpr optional_ref(T& value);

    template<typename U, std::enable_if_t<std::is_same_v<std::remove_const_t<T>, U>>* = nullptr>
    inline constexpr optional_ref(optional<U>& value);

    template<typename U, std::enable_if_t<std::is_same_v<std::remove_const_t<T>, U> && std::is_const_v<T>>* = nullptr>
    inline constexpr optional_ref(const optional<U>& value);

    optional_ref(const optional_ref& other) noexcept;
    optional_ref(optional_ref&& other) noexcept;

    optional_ref& operator=(const optional_ref& other) = delete;
    optional_ref& operator=(optional_ref&& other) = delete;

    ~optional_ref() = default;

    inline constexpr T* operator->() const;

    inline constexpr T& operator*() const;

    inline constexpr explicit operator bool() const noexcept;
    inline constexpr bool     has_value() const noexcept;

    inline constexpr T& value() const;

private:
    T* value_;
};

//===========================================================================================================
template<typename T>
constexpr optional_ref<T>::optional_ref() noexcept :
    value_(nullptr)
{}

//===========================================================================================================
template<typename T>
/*constexpr*/ optional_ref<T>::optional_ref(nullopt_t /*value*/) noexcept :
    value_(nullptr)
{}

//===========================================================================================================
template<typename T>
inline constexpr optional_ref<T>::optional_ref(T& value) :
    value_(&value)
{}

//===========================================================================================================
template<typename T>
template<typename U, std::enable_if_t<std::is_same_v<std::remove_const_t<T>, U>>*>
inline constexpr optional_ref<T>::optional_ref(optional<U>& value) :
    value_(value ? &(*value) : nullptr)
{}

//===========================================================================================================
template<typename T>
template<typename U, std::enable_if_t<std::is_same_v<std::remove_const_t<T>, U> && std::is_const_v<T>>*>
inline constexpr optional_ref<T>::optional_ref(const optional<U>& value) :
    value_(value ? &(*value) : nullptr)
{}

//===========================================================================================================
template<typename T>
optional_ref<T>::optional_ref(const optional_ref& other) noexcept :
    value_(other.value_)
{}

//===========================================================================================================
template<typename T>
optional_ref<T>::optional_ref(optional_ref&& other) noexcept :
    value_(other.value_)
{}

//===========================================================================================================
template<typename T>
inline constexpr T* optional_ref<T>::operator->() const
{
    xyfund_assert(value_ != nullptr);
    return value_;
}

//===========================================================================================================
template<typename T>
inline constexpr T& optional_ref<T>::operator*() const
{
    xyfund_assert(value_ != nullptr);
    return *value_;
}

//===========================================================================================================
template<typename T>
inline constexpr optional_ref<T>::operator bool() const noexcept
{
    return has_value();
}

//===========================================================================================================
template<typename T>
inline constexpr bool optional_ref<T>::has_value() const noexcept
{
    return value_ != nullptr;
}

//===========================================================================================================
template<typename T>
inline constexpr T& optional_ref<T>::value() const
{
    if(value_ == nullptr) throw bad_optional_access();
    return *value_;
}

//===========================================================================================================
template<typename T>
optional_ref<T> make_optional_ref(T& value)
{
    return optional_ref<T>(value);
}

//===========================================================================================================
template<typename T>
optional_ref<const T> make_optional_cref(const T& value)
{
    return optional_ref<const T>(value);
}

//===========================================================================================================
template<typename T, typename U>
constexpr bool operator==(const optional_ref<T>& lhs, const optional_ref<U>& rhs)
{
    if(lhs.has_value() != rhs.has_value()) return false;
    if(!lhs.has_value() && !rhs.has_value()) return true;
    return *lhs == *rhs;
}

//===========================================================================================================
template<typename T, typename U>
constexpr bool operator!=(const optional_ref<T>& lhs, const optional_ref<U>& rhs)
{
    return !(lhs == rhs);
}

//===========================================================================================================
template<typename T>
/*constexpr*/ bool operator==(const optional_ref<T>& opt, nullopt_t /*other*/) noexcept
{
    return !opt.has_value();
}

//===========================================================================================================
template<typename T>
/*constexpr*/ bool operator==(nullopt_t /*other*/, const optional_ref<T>& opt) noexcept
{
    return !opt.has_value();
}

//===========================================================================================================
template<typename T>
/*constexpr*/ bool operator!=(const optional_ref<T>& opt, nullopt_t /*other*/) noexcept
{
    return opt.has_value();
}

//===========================================================================================================
template<typename T>
/*constexpr*/ bool operator!=(nullopt_t /*other*/, const optional_ref<T>& opt) noexcept
{
    return opt.has_value();
}

//===========================================================================================================
template<typename T, typename U>
constexpr bool operator==(const optional_ref<T>& opt, const U& value)
{
    return opt.has_value() && (*opt == value); //NOLINT(cppcoreguidelines-pro-bounds-array-to-pointer-decay)
}

//===========================================================================================================
template<typename T, typename U>
constexpr bool operator==(const T& value, const optional_ref<U>& opt)
{
    return opt.has_value() && (*opt == value); //NOLINT(cppcoreguidelines-pro-bounds-array-to-pointer-decay)
}

//===========================================================================================================
template<typename T, typename U>
constexpr bool operator!=(const optional_ref<T>& opt, const U& value)
{
    return !opt.has_value() || (*opt != value); //NOLINT(cppcoreguidelines-pro-bounds-array-to-pointer-decay)
}

//===========================================================================================================
template<typename T, typename U>
constexpr bool operator!=(const T& value, const optional_ref<U>& opt)
{
    return !opt.has_value() || (*opt != value); //NOLINT(cppcoreguidelines-pro-bounds-array-to-pointer-decay)
}

} // namespace xyfund

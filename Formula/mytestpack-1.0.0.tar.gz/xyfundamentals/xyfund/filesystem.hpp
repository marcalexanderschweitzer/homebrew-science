//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

// Provides functionality from std::filesystem. See https://en.cppreference.com/w/cpp/filesystem

#include <type_traits>

#if defined(XYFUND_HAVE_STD_FILESYSTEM) && !defined(XYFUND_USE_BOOST_FILESYSTEM)
#    include <filesystem>
#    include <fstream>
#elif defined(XYFUND_HAVE_BOOST_FILESYSTEM)
#    include <boost/filesystem.hpp>
#    include <boost/filesystem/fstream.hpp>
#endif

namespace xyfund {

namespace filesystem {

#if defined(XYFUND_HAVE_STD_FILESYSTEM) && !defined(XYFUND_USE_BOOST_FILESYSTEM)
using namespace std::filesystem;
using ofstream = std::ofstream;
using ifstream = std::ifstream;
using fstream  = std::fstream;
#elif defined(XYFUND_HAVE_BOOST_FILESYSTEM)
using namespace boost::filesystem;
#else
#    error "Can not build without 'filesystem' implementation"
#endif

} // namespace filesystem

} // namespace xyfund

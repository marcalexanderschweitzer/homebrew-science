//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <cstddef>
#include <iomanip>
#include <iostream>

#include <xyfund/optional.hpp>
#include <xyfund/ranges.hpp>
#include <xyfund/scope.hpp>
#include <xyfund/types.hpp>
#include <xyfund/utility.hpp>

namespace xyfund {

//! A simple progress bar that prints the progress relative to a final_count to e.g. std::cout.
class progress_bar
{
public:
    //! Creates a progress bar with known final count.
    //!
    //! The progress bar is immediatly displaced with zero initial progress.
    //!
    //! @param final_count Total number that has to be done.
    //! @param display_length How many characters we may print.
    //! @param out_stream The stream to print to.
    //! @param clear Whether to update the current line, or always print to a new line.
    inline explicit progress_bar(std::ptrdiff_t final_count, std::ptrdiff_t display_length, std::ostream& out_stream = std::cout, bool clear = true);

    //! Creates a progress bar without known final count.
    //!
    //! The progress bar is not printed yet.
    //! It is adviced to set the final count via restart().
    //!
    //! @param final_count Total number that has to be done.
    //! @param display_length How many characters we may print.
    //! @param out_stream The stream to print to.
    //! @param clear Whether to update the current line, or always print to a new line.
    inline explicit progress_bar(std::ptrdiff_t display_length = 80, std::ostream& out_stream = std::cout, bool clear = true);

    inline progress_bar(const progress_bar& other) noexcept = delete;
    inline progress_bar(progress_bar&& other) noexcept      = delete;

    inline progress_bar& operator=(const progress_bar& other) noexcept = delete;
    inline progress_bar& operator=(progress_bar&& other) noexcept = delete;

    inline ~progress_bar();

    //! Resets the progress and sets new final_count
    inline void restart(std::ptrdiff_t final_count);
    inline void finish();

    inline std::ptrdiff_t final_count() const;
    inline std::ptrdiff_t current_count() const;

    inline void display();

    inline progress_bar& operator+=(std::ptrdiff_t increment);
    inline progress_bar& operator++();

private:
    std::ostream&  out_stream_;
    std::ptrdiff_t display_length_;
    //! Number of special characters we print besides the actual progress.
    static constexpr std::ptrdiff_t special_display_char_count = 7; // '[] xxx%' <- 7 characters

    std::ptrdiff_t final_count_ = 0;

    std::ptrdiff_t current_count_      = 0;
    double         next_display_count_ = 0.0;

    bool finished_ = false;
    bool clear_;
};

template<typename Range, typename Iter>
class progress_range_iterator
{
public:
    using difference_type   = typename std::iterator_traits<Iter>::difference_type;
    using value_type        = typename std::iterator_traits<Iter>::value_type;
    using pointer           = typename std::iterator_traits<Iter>::pointer;
    using reference         = typename std::iterator_traits<Iter>::reference;
    using iterator_category = std::forward_iterator_tag;

    progress_range_iterator(Iter iter, progress_bar* bar);

    reference operator*() const;
    pointer   operator->() const;

    progress_range_iterator& operator++();
    progress_range_iterator  operator++(int);

    template<typename OtherIter>
    inline friend bool operator==(const progress_range_iterator<Range, Iter>& lhs, const progress_range_iterator<Range, OtherIter>& rhs)
    {
        return lhs.iter_ == rhs.iter_;
    }

    template<typename OtherIter>
    inline friend bool operator!=(const progress_range_iterator<Range, Iter>& lhs, const progress_range_iterator<Range, OtherIter>& rhs)
    {
        return !(lhs == rhs);
    }

private:
    Iter          iter_;
    progress_bar* progress_bar_;
};

template<typename Range>
class progress_range
{
public:
    using iterator = progress_range_iterator<Range, xyfund::ranges::iterator_t<Range>>;
    using sentinel = progress_range_iterator<Range, xyfund::ranges::sentinel_t<Range>>;

    template<typename R>
    progress_range(R&& range, progress_bar* bar);

    iterator begin() const;
    iterator begin();
    sentinel end() const;
    sentinel end();

private:
    Range         range_;
    progress_bar* progress_bar_;
};

template<typename Range>
struct progress_range_traits
{
    static std::ptrdiff_t estimate_total_progress(const Range& range);

    static std::pair<xyfund::ranges::iterator_t<Range>, std::ptrdiff_t> begin(Range& range);
    static std::pair<xyfund::ranges::iterator_t<const Range>, std::ptrdiff_t> begin(const Range& range);

    template<typename Iter>
    static std::ptrdiff_t increment(Iter& iter);
};

//===========================================================================================================
inline progress_bar::progress_bar(std::ptrdiff_t final_count, std::ptrdiff_t display_length, std::ostream& out_stream, bool clear) :
    out_stream_(out_stream),
    display_length_(display_length),
    final_count_(final_count),
    clear_(clear)
{
    display_length_ = std::max(display_length_, special_display_char_count + 1);
    display();
}

//===========================================================================================================
inline progress_bar::progress_bar(std::ptrdiff_t display_length, std::ostream& out_stream, bool clear) :
    out_stream_(out_stream),
    display_length_(display_length),
    clear_(clear)
{
    display_length_ = std::max(display_length_, special_display_char_count + 1);
}

//===========================================================================================================
inline progress_bar::~progress_bar()
{
    finish();
}

//===========================================================================================================
inline void progress_bar::restart(std::ptrdiff_t final_count)
{
    final_count_        = final_count;
    current_count_      = 0;
    next_display_count_ = 0.0;
    finished_           = false;

    display();
}

//===========================================================================================================
inline void progress_bar::finish()
{
    if(finished_) return;

    if(clear_) out_stream_ << std::endl;
    finished_ = true;
}

//===========================================================================================================
inline std::ptrdiff_t progress_bar::final_count() const
{
    return final_count_;
}

//===========================================================================================================
inline std::ptrdiff_t progress_bar::current_count() const
{
    return current_count_;
}

//===========================================================================================================
inline void progress_bar::display()
{
    const auto max_chars = display_length_ - special_display_char_count;

    const auto count_per_char = static_cast<double>(final_count_) / max_chars;
    const auto current_chars  = final_count_ == 0 ? max_chars : static_cast<std::ptrdiff_t>(current_count_ / count_per_char);
    const auto display_chars  = std::min(max_chars, current_chars);

    const auto percent = final_count_ == 0 ? 100 : static_cast<int>(static_cast<double>(current_count_) / final_count_ * 100);

    if(clear_) out_stream_ << '\r'; // Go to start of current line
    out_stream_ << '[';
    for(index_t i = 0; i < display_chars; ++i) out_stream_ << '=';
    for(index_t i = display_chars; i < max_chars; ++i) out_stream_ << ' ';
    out_stream_ << ']';

    const auto flags         = out_stream_.flags();
    const auto flag_resetter = make_scope_exit([this, flags]() { out_stream_.flags(flags); });
    out_stream_ << std::setfill(' ') << std::setw(4);
    out_stream_ << percent;
    out_stream_ << '%';

    if(clear_)
    {
        out_stream_ << std::flush;
    }
    else
    {
        out_stream_ << std::endl;
    }

    next_display_count_ = static_cast<double>(current_chars + 1) * count_per_char;
}

//===========================================================================================================
inline progress_bar& progress_bar::operator+=(std::ptrdiff_t increment)
{
    current_count_ += increment;

    if(static_cast<double>(current_count_) >= next_display_count_)
    {
        display();
    }
    return *this;
}

//===========================================================================================================
inline progress_bar& progress_bar::operator++()
{
    return (*this) += 1;
}

//===========================================================================================================
template<typename Range>
std::ptrdiff_t progress_range_traits<Range>::estimate_total_progress(const Range& range)
{
    return xyfund::ssize(range);
}

//===========================================================================================================
template<typename Range>
std::pair<xyfund::ranges::iterator_t<Range>, std::ptrdiff_t> progress_range_traits<Range>::begin(Range& range)
{
    return {std::begin(range), 0};
}

//===========================================================================================================
template<typename Range>
std::pair<xyfund::ranges::iterator_t<const Range>, std::ptrdiff_t> progress_range_traits<Range>::begin(const Range& range)
{
    return {std::begin(range), 0};
}

//===========================================================================================================
template<typename Range>
template<typename Iter>
std::ptrdiff_t progress_range_traits<Range>::increment(Iter& iter)
{
    ++iter;
    return 1;
}

//===========================================================================================================
template<typename Range, typename Iter>
progress_range_iterator<Range, Iter>::progress_range_iterator(Iter iter, progress_bar* bar) :
    iter_(std::move(iter)),
    progress_bar_(bar)
{}

//===========================================================================================================
template<typename Range, typename Iter>
typename progress_range_iterator<Range, Iter>::reference progress_range_iterator<Range, Iter>::operator*() const
{
    return *iter_;
}

//===========================================================================================================
template<typename Range, typename Iter>
typename progress_range_iterator<Range, Iter>::pointer progress_range_iterator<Range, Iter>::operator->() const
{
    return iter_.operator->();
}

//===========================================================================================================
template<typename Range, typename Iter>
progress_range_iterator<Range, Iter>& progress_range_iterator<Range, Iter>::operator++()
{
    const auto progress = progress_range_traits<std::decay_t<Range>>::increment(iter_);
    if(progress_bar_ != nullptr) *progress_bar_ += progress;
    return *this;
}

//===========================================================================================================
template<typename Range, typename Iter>
progress_range_iterator<Range, Iter> progress_range_iterator<Range, Iter>::operator++(int)
{
    auto ret = *this;
    ++(*this);
    return ret;
}

//===========================================================================================================
template<typename Range>
template<typename R>
progress_range<Range>::progress_range(R&& range, progress_bar* bar) :
    range_(std::forward<R>(range)),
    progress_bar_(bar)
{
    if(progress_bar_ != nullptr)
    {
        progress_bar_->restart(progress_range_traits<std::decay_t<Range>>::estimate_total_progress(range_));
    }
}

//===========================================================================================================
template<typename Range>
typename progress_range<Range>::iterator progress_range<Range>::begin() const
{
    auto [iter, progress] = progress_range_traits<std::decay_t<Range>>::begin(range_);
    if(progress_bar_ != nullptr) *progress_bar_ += progress;
    return iterator(std::move(iter), progress_bar_);
}

//===========================================================================================================
template<typename Range>
typename progress_range<Range>::iterator progress_range<Range>::begin()
{
    auto [iter, progress] = progress_range_traits<std::decay_t<Range>>::begin(range_);
    if(progress_bar_ != nullptr) *progress_bar_ += progress;
    return iterator(std::move(iter), progress_bar_);
}

//===========================================================================================================
template<typename Range>
typename progress_range<Range>::sentinel progress_range<Range>::end() const
{
    return iterator(std::end(range_), progress_bar_);
}

//===========================================================================================================
template<typename Range>
typename progress_range<Range>::sentinel progress_range<Range>::end()
{
    return iterator(std::end(range_), progress_bar_);
}

//===========================================================================================================
template<typename Range>
auto progress_range_view(Range&& range, const xyfund::optional_ref<progress_bar>& bar)
{
    return progress_range<Range>(std::forward<Range>(range), bar ? &(*bar) : nullptr);
}

} // namespace xyfund

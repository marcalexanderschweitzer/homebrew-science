//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <memory>
#include <tuple>
#include <type_traits>
#include <functional>

//#define XYFUND_HAVE_STD_CONJUNCTION
//#define XYFUND_HAVE_STD_DISJUNCTION

namespace xyfund {

//===========================================================================================================
template<typename...>
using void_t = void;

template<typename T>
struct remove_cvref
{
    using type = std::remove_cv_t<std::remove_reference_t<T>>;
};

template<typename T>
using remove_cvref_t = typename remove_cvref<T>::type;

//===========================================================================================================
#ifdef XYFUND_HAVE_STD_CONJUNCTION
template<typename... T>
using conjunction = std::conjunction<T...>;
template<typename... T>
inline constexpr bool conjunction_v = std::conjunction_v<T...>;
#else
template<class...>
struct conjunction : std::true_type
{};
template<class T>
struct conjunction<T> : T
{};
template<class T, class... Us>
struct conjunction<T, Us...> : std::conditional_t<bool(T::value), conjunction<Us...>, T>
{};
template<class T, class... Us>
inline constexpr bool conjunction_v = conjunction<T, Us...>::value;
#endif // XYFUND_HAVE_STD_CONJUNCTION

//===========================================================================================================
#ifdef XYFUND_HAVE_STD_DISJUNCTION
template<typename... T>
using disjunction = std::disjunction<T...>;
template<typename... T>
inline constexpr bool disjunction_v = std::disjunction_v<T...>;
#else
template<class...>
struct disjunction : std::false_type
{};
template<class T>
struct disjunction<T> : T
{};
template<class T, class... Us>
struct disjunction<T, Us...> : std::conditional_t<bool(T::value), T, disjunction<Us...>>
{};
template<class T, class... Us>
inline constexpr bool disjunction_v = disjunction<T, Us...>::value;
#endif // XYFUND_HAVE_STD_DISJUNCTION

//===========================================================================================================
template<typename T, typename Tuple>
struct has_type;

template<typename T, typename... Us>
struct has_type<T, std::tuple<Us...>> : disjunction<std::is_same<T, Us>...>
{};

template<typename T, typename... Us>
inline constexpr bool has_type_v = has_type<T, Us...>::value;

//===========================================================================================================
template<typename T>
struct dependent_false : std::false_type
{};

template<typename T>
inline constexpr bool dependent_false_v = dependent_false<T>::value;

//===========================================================================================================
template<typename T>
struct is_shared_ptr : std::false_type
{};

template<typename T>
struct is_shared_ptr<std::shared_ptr<T>> : std::true_type
{};

template<typename T>
inline constexpr bool is_shared_ptr_v = is_shared_ptr<T>::value;

//===========================================================================================================
template<typename T>
inline T& deref(T& x)
{
    return x;
}

template<typename T>
inline T& deref(T* x)
{
    return *x;
}

template<typename T>
inline T& deref(const std::unique_ptr<T>& x)
{
    return *x;
}

template<typename T>
inline T& deref(std::unique_ptr<T>& x)
{
    return *x;
}

template<typename T>
inline T& deref(const std::shared_ptr<T>& x)
{
    return *x;
}

template<typename T>
inline T& deref(std::shared_ptr<T>& x)
{
    return *x;
}

template<typename T>
inline T& deref(const std::reference_wrapper<T>& x)
{
    return x.get();
}

template<typename T>
inline T& deref(std::reference_wrapper<T>& x)
{
    return x.get();
}

template<typename T>
using deref_type_t = decltype(xyfund::deref(std::declval<T&>()));

//===========================================================================================================
template<typename F>
struct function_traits : public function_traits<decltype(&F::operator())>
{};

template<typename R, typename... Args>
struct function_traits<R(Args...)>
{
    using result_type = R;

    static const size_t arity = sizeof...(Args);

    template<size_t N>
    struct argument_type
    {
        static_assert(N < arity, "Invalid argument index.");
        using type = typename std::tuple_element<N, std::tuple<Args...>>::type;
    };

    template<size_t N>
    using argument_type_t = typename argument_type<N>::type;
};

template<typename R, typename... Args>
struct function_traits<R (*)(Args...)> : public function_traits<R(Args...)>
{};

template<typename C, typename R, typename... Args>
struct function_traits<R (C::*)(Args...)> : public function_traits<R(Args...)>
{};

template<typename C, typename R, typename... Args>
struct function_traits<R (C::*)(Args...) const> : public function_traits<R(Args...)>
{};

} // namespace xyfund

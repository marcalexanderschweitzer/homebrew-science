//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

// Provides gsl::narrow_error
// Provides gsl::narrow

#include <exception>
#include <type_traits>

#include "xyfund/utility.hpp"

namespace xyfund {

//===========================================================================================================
class narrowing_error : public std::exception
{
public:
    const char* what() const noexcept override
    {
        return "narrowing_error";
    }
};

//===========================================================================================================
template<typename T, typename U>
constexpr T narrow(U value) noexcept(false)
{
    constexpr const bool is_different_signedness = (std::is_signed<T>::value != std::is_signed<U>::value);

    const auto narrowed_value = narrow_cast<T>(value);

    if(static_cast<U>(narrowed_value) != value || (is_different_signedness && ((narrowed_value < T{}) != (value < U{}))))
    {
        throw narrowing_error{};
    }

    return narrowed_value;
}

} // namespace xyfund

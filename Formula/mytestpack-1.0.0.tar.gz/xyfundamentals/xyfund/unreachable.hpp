//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

// Alternative to std::unreachable. See https://wg21.link/p0627

// TODO: this should be changed to a function as in P0627R3.

#if defined(__GNUC__) || defined(__clang__)
#    define XYFUND_UNREACHABLE() __builtin_unreachable()
#elif defined(_MSC_VER)
#    define XYFUND_UNREACHABLE() __assume(0)
#else
#    define XYFUND_UNREACHABLE()
#endif

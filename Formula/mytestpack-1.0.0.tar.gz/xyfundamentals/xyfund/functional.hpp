//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

// Provides std::overload. See https://wg21.link/p0051r3

#include <type_traits>

namespace xyfund {

namespace detail {

//template<typename F>
//struct wrap_call
//{
//};
//
//template<typename F>
//struct overload_storage : std::conditional<std::is_class<F>::value && !std::is_final<F>::value, F, wrap_call<F>>
//{};

template<typename F>
struct overload_storage
{
    static_assert(std::is_class<F>::value && !std::is_final<F>::value, "non-class or final functions not yet supported");
    using type = F;
};

template<typename F>
using overload_storage_t = typename overload_storage<F>::type;

template<typename F, typename... Fs>
class overloader;

template<typename F1>
class overloader<F1> : overload_storage_t<F1>
{
    using base1 = overload_storage_t<F1>;

public:
    template<typename U1>
    // NOLINTNEXTLINE(bugprone-forwarding-reference-overload)
    constexpr explicit overloader(U1&& fct1) :
        base1(std::forward<U1>(fct1))
    {}

    using base1::operator();
};
template<typename F1, typename F2, typename... Fs>
class overloader<F1, F2, Fs...> : overload_storage_t<F1>, overloader<F2, Fs...>
{
    using base1 = overload_storage_t<F1>;
    using bases = overloader<F2, Fs...>;

public:
    template<typename U1, typename U2, typename... Us>
    constexpr explicit overloader(U1&& fct1, U2&& fct2, Us&&... fcts) :
        base1(std::forward<U1>(fct1)),
        bases(std::forward<U2>(fct2), std::forward<Us>(fcts)...)
    {}

    using base1::operator();
    using bases::operator();
};

template<typename R, typename... Fs>
struct explicit_overloader : overloader<Fs...>
{
    using result_type = R;
    using overloader<Fs...>::operator();

    template<class... OFs>
    constexpr explicit_overloader(OFs&&... fs) :
        overloader<Fs...>(std::forward<OFs>(fs)...) {}
};

} // namespace detail

template<typename F1, typename... Fs>
constexpr auto overload(F1&& f1, Fs&&... fs)
{
    return detail::overloader<std::decay_t<F1>, std::decay_t<Fs>...>(std::forward<F1>(f1), std::forward<Fs>(fs)...);
}

template<typename R, typename F1, typename... Fs>
constexpr auto overload(F1&& f1, Fs&&... fcts)
{
    return detail::explicit_overloader<R, std::decay_t<F1>, std::decay_t<Fs>...>(std::forward<F1>(f1), std::forward<Fs>(fcts)...);
}

} // namespace xyfund

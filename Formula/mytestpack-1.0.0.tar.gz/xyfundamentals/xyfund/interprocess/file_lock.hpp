//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <string>

#include "xyfund/filesystem.hpp"

#if _WIN32
#    include "xyfund/interprocess/windows/file_lock.hpp"
#else
#    include "xyfund/interprocess/posix/file_lock.hpp"
#endif // _WIN32

namespace xyfund {

namespace interprocess {

class file_lock : detail::file_lock_impl
{
public:
    using native_handle_type = typename detail::file_lock_impl::native_handle_type;

    // construct/copy/destruct
    inline file_lock() noexcept = default;

    inline file_lock(const file_lock& other) = delete;
    inline file_lock(file_lock&& other) noexcept;

    inline explicit file_lock(const filesystem::path& file_path);

    inline ~file_lock() = default;

    // public member functions
    inline file_lock& operator=(file_lock& other) = delete;
    inline file_lock& operator                    =(file_lock&& other) noexcept;

    inline void lock();
    //inline bool try_lock();

    inline void unlock();

    inline native_handle_type native_handle() const noexcept;
};

//===========================================================================================================
inline file_lock::file_lock(file_lock&& other) noexcept :
    detail::file_lock_impl(std::move(other))
{}

//===========================================================================================================
inline file_lock::file_lock(const filesystem::path& file_path) :
    detail::file_lock_impl(file_path)
{}

//===========================================================================================================
inline file_lock& file_lock::operator=(file_lock&& other) noexcept
{
    detail::file_lock_impl::operator=(std::move(other));
    return *this;
}

//===========================================================================================================
inline void file_lock::lock()
{
    detail::file_lock_impl::lock();
}

//===========================================================================================================
inline void file_lock::unlock()
{
    detail::file_lock_impl::unlock();
}

//===========================================================================================================
inline typename file_lock::native_handle_type file_lock::native_handle() const noexcept
{
    return detail::file_lock_impl::native_handle();
}

} // namespace interprocess

} // namespace xyfund

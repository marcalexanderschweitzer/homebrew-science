//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <string>
#include <system_error>

#include <cerrno>
#include <fcntl.h>

#include "xyfund/filesystem.hpp"

#include "xyfund/algorithm/string.hpp"

namespace xyfund {

namespace detail {

class file_lock_impl
{
public:
    using native_handle_type = int;

    inline file_lock_impl(const file_lock_impl& other) = delete;
    inline file_lock_impl& operator=(file_lock_impl& other) = delete;

protected:
    inline file_lock_impl() noexcept = default;

    inline file_lock_impl(file_lock_impl&& other) noexcept;

    inline explicit file_lock_impl(const filesystem::path& file_path);

    inline ~file_lock_impl();

    inline file_lock_impl& operator=(file_lock_impl&& other) noexcept;

    inline void lock(); // NOLINT(readability-make-member-function-const)
    //inline bool try_lock();

    inline void unlock(); // NOLINT(readability-make-member-function-const)

    inline native_handle_type native_handle() const noexcept;

private:
    native_handle_type file_handle_ = -1;

    inline void open_file(const filesystem::path& file_path, std::error_code& error_code);
    inline void close_file(std::error_code& error_code) const;
};

//===========================================================================================================
inline file_lock_impl::file_lock_impl(file_lock_impl&& other) noexcept :
    file_handle_(other.file_handle_)
{
    other.file_handle_ = -1;
}

//===========================================================================================================
inline file_lock_impl::file_lock_impl(const filesystem::path& file_path)
{
    std::error_code ec;
    open_file(file_path, ec);
    if(ec)
    {
        throw std::system_error(ec, "Could not open file");
    }
}

//===========================================================================================================
inline file_lock_impl::~file_lock_impl()
{
    std::error_code ec;
    close_file(ec);
}

//===========================================================================================================
inline file_lock_impl& file_lock_impl::operator=(file_lock_impl&& other) noexcept
{
    file_handle_       = other.file_handle_;
    other.file_handle_ = -1;
    return *this;
}

//===========================================================================================================
inline void file_lock_impl::lock() // NOLINT(readability-make-member-function-const)
{
    struct ::flock lock{};
    lock.l_type        = F_WRLCK;
    lock.l_whence      = SEEK_SET;
    lock.l_start       = 0;
    lock.l_len         = 0;
    const auto success = ::fcntl(file_handle_, F_SETLKW, &lock); // NOLINT(cppcoreguidelines-pro-type-vararg)
    if(success == -1)
    {
        const auto ec = std::make_error_code(static_cast<std::errc>(errno));
        throw std::system_error(ec, "Could not lock file");
    }
}

//===========================================================================================================
inline void file_lock_impl::unlock() // NOLINT(readability-make-member-function-const)
{
    struct ::flock lock{};
    lock.l_type        = F_UNLCK;
    lock.l_whence      = SEEK_SET;
    lock.l_start       = 0;
    lock.l_len         = 0;
    const auto success = ::fcntl(file_handle_, F_SETLK, &lock); // NOLINT(cppcoreguidelines-pro-type-vararg)
    if(success == -1)
    {
        const auto ec = std::make_error_code(static_cast<std::errc>(errno));
        throw std::system_error(ec, "Could not unlock file");
    }
}

//===========================================================================================================
inline typename file_lock_impl::native_handle_type file_lock_impl::native_handle() const noexcept
{
    return file_handle_;
}

//===========================================================================================================
inline void file_lock_impl::open_file(const filesystem::path& file_path, std::error_code& error_code)
{
    file_handle_ = ::open(file_path.c_str(), O_RDWR); // NOLINT(cppcoreguidelines-pro-type-vararg)

    if(file_handle_ == -1)
    {
        error_code = std::make_error_code(static_cast<std::errc>(errno));
    }
}

//===========================================================================================================
inline void file_lock_impl::close_file(std::error_code& error_code) const
{
    const auto success = ::close(file_handle_);
    if(success != -1)
    {
        error_code = std::make_error_code(static_cast<std::errc>(errno));
    }
}

} // namespace detail

} // namespace xyfund

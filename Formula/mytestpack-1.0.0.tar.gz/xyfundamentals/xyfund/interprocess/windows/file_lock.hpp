//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <string>
#include <system_error>

#include <Windows.h>

#include "xyfund/filesystem.hpp"

#include "xyfund/algorithm/string.hpp"

namespace xyfund {

namespace detail {

class file_lock_impl
{
public:
    using native_handle_type = HANDLE;

    inline file_lock_impl(const file_lock_impl& other) = delete;
    inline file_lock_impl& operator=(file_lock_impl& other) = delete;

protected:
    inline file_lock_impl() noexcept = default;

    inline file_lock_impl(file_lock_impl&& other) noexcept;

    inline explicit file_lock_impl(const filesystem::path& file_path);

    inline ~file_lock_impl();

    inline file_lock_impl& operator=(file_lock_impl&& other) noexcept;

    inline void lock();
    //inline bool try_lock();

    inline void unlock();

    inline native_handle_type native_handle() const noexcept;

private:
    native_handle_type file_handle_ = nullptr;

    inline void open_file(const filesystem::path& file_path, std::error_code& error_code);
    inline void close_file(std::error_code& error_code);
};

//===========================================================================================================
inline file_lock_impl::file_lock_impl(file_lock_impl&& other) noexcept :
    file_handle_(other.file_handle_)
{
    other.file_handle_ = nullptr;
}

//===========================================================================================================
inline file_lock_impl::file_lock_impl(const filesystem::path& file_path)
{
    std::error_code ec;
    open_file(file_path, ec);
    if(ec)
    {
        throw std::system_error(ec, "Could not create file " + file_path.string());
    }
}

//===========================================================================================================
inline file_lock_impl::~file_lock_impl()
{
    std::error_code ec;
    close_file(ec);
}

//===========================================================================================================
inline file_lock_impl& file_lock_impl::operator=(file_lock_impl&& other) noexcept
{
    file_handle_       = other.file_handle_;
    other.file_handle_ = nullptr;
    return *this;
}

//===========================================================================================================
inline void file_lock_impl::lock()
{
    OVERLAPPED overlapped;
    std::memset(&overlapped, 0, sizeof(overlapped));

    const unsigned long len = ((unsigned long)-1);

    const auto success = LockFileEx(file_handle_, LOCKFILE_EXCLUSIVE_LOCK, 0, len, len, &overlapped);
    if(success == FALSE)
    {
        std::error_code ec(GetLastError(), std::system_category());
        throw std::system_error(ec, "Could not lock file");
    }
}

//===========================================================================================================
inline void file_lock_impl::unlock()
{
    OVERLAPPED overlapped;
    std::memset(&overlapped, 0, sizeof(overlapped));

    const unsigned long len = ((unsigned long)-1);

    const auto success = UnlockFileEx(file_handle_, 0, len, len, &overlapped);
    if(success == FALSE)
    {
        std::error_code ec(GetLastError(), std::system_category());
        throw std::system_error(ec, "Could not unlock file");
    }
}

//===========================================================================================================
inline typename file_lock_impl::native_handle_type file_lock_impl::native_handle() const noexcept
{
    return file_handle_;
}

//===========================================================================================================
inline void file_lock_impl::open_file(const filesystem::path& file_path, std::error_code& error_code)
{
    file_handle_ = CreateFileW(file_path.c_str(),
                               GENERIC_READ | GENERIC_WRITE,
                               FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                               nullptr,
                               OPEN_EXISTING,
                               0,
                               nullptr);

    if(file_handle_ == nullptr)
    {
        error_code.assign(GetLastError(), std::system_category());
    }
}

inline void file_lock_impl::close_file(std::error_code& error_code)
{
    const auto success = CloseHandle(file_handle_);
    if(success == FALSE)
    {
        error_code.assign(GetLastError(), std::system_category());
    }
}

} // namespace detail

} // namespace xyfund

//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

// Provides a non-complete implementation for some proposed (C++23?) std::views::enumerate:
// See https://wg21.link/p2164r2
//
// To make it compile with C++17, this implementation uses SFINEA instead of C++20 concepts.

#include <iterator>
#include <utility>

#include "xyfund/ranges.hpp"

namespace xyfund {

namespace detail {

// Pull in some general concepts
#if defined(XYFUND_HAVE_STD_ANY) && !defined(XYFUND_USE_NANORANGE)

using ::std::convertible_to;
using ::std::copy_constructible;
using ::std::copyable;
using ::std::equality_comparable;

// using ::std::simple_view; // TODO: We probably need to define this ourselves?!

#elif defined(XYFUND_HAVE_NANORANGE)

using ::nano::convertible_to;
using ::nano::copy_constructible;
using ::nano::copyable;
using ::nano::equality_comparable;

using ::nano::detail::simple_view;

#endif

} // namespace detail

namespace ranges {

template<typename V>
// requires view<V>
class enumerate_view : public view_interface<enumerate_view<V>>
{
    static_assert(view<V>);
    static_assert(input_range<V>);

private:
    V base_ = {};

    template<bool Const>
    class iterator;

    template<bool Const>
    class sentinel;

public:
    constexpr enumerate_view() = default;
    constexpr enumerate_view(V base) :
        base_(std::move(base))
    {}

    template<typename VV = V, std::enable_if_t<!xyfund::detail::simple_view<VV>, int> = 0>
    constexpr auto begin() // requires(!simple_view<V>)
    {
        return iterator<false>(ranges::begin(base_), 0);
    }

    template<typename VV = V, std::enable_if_t<xyfund::detail::simple_view<VV>, int> = 0>
    constexpr auto begin() const // requires simple_view<V>
    {
        return iterator<true>(ranges::begin(base_), 0);
    }

    constexpr auto end()
    {
        return sentinel<false>{ranges::end(base_)};
    }
    template<typename VV = V, std::enable_if_t<common_range<VV> && sized_range<VV>, int> = 0>
    constexpr auto end() // requires common_range<V>&& sized_range<V>
    {
        return iterator<false>{ranges::end(base_), static_cast<range_difference_t<V>>(size())};
    }
    template<typename VV = V, std::enable_if_t<range<const VV>, int> = 0>
    constexpr auto end() const // requires range<const V>
    {
        return sentinel<true>{ranges::end(base_)};
    }
    template<typename VV = V, std::enable_if_t<common_range<const VV> && sized_range<VV>, int> = 0>
    constexpr auto end() const // requires common_range<const V>&& sized_range<V>
    {
        return iterator<true>{ranges::end(base_), static_cast<range_difference_t<V>>(size())};
    }

    template<typename VV = V, std::enable_if_t<sized_range<VV>, int> = 0>
    constexpr auto size() // requires sized_range<V>
    {
        return ranges::size(base_);
    }
    template<typename VV = V, std::enable_if_t<sized_range<const VV>, int> = 0>
    constexpr auto size() const // requires sized_range<const V>
    {
        return ranges::size(base_);
    }

    template<typename VV = V, std::enable_if_t<xyfund::detail::copy_constructible<VV>, int> = 0>
    constexpr V base() const& //requires copy_constructible<V>
    {
        return base_;
    }
    constexpr V base() &&
    {
        return move(base_);
    }
};

template<typename R>
enumerate_view(R &&) -> enumerate_view<all_view<R>>;

namespace detail {
template<typename Base>
auto select_enumerate_iter_count_type()
{
    if constexpr(sized_range<Base>)
    {
        return range_size_t<Base>();
    }
    else
    {
        return std::make_unsigned_t<range_difference_t<Base>>();
    }
}

} // namespace detail

template<typename V>
// requires view<V>
template<bool Const>
class enumerate_view<V>::iterator
{
    static_assert(view<V>);

    using base_type  = std::conditional_t<Const, const V, V>;
    using count_type = decltype(detail::select_enumerate_iter_count_type<base_type>());

    iterator_t<base_type> current_ = iterator_t<base_type>();
    count_type            pos_     = 0;

public:
    using iterator_category = typename std::iterator_traits<iterator_t<base_type>>::iterator_category;

    struct reference
    {
        const count_type             index;
        range_reference_t<base_type> value;
    };

    struct value_type
    {
        const count_type         index;
        range_value_t<base_type> value;
    };

    using difference_type = range_difference_t<base_type>;

    iterator() = default;
    constexpr explicit iterator(iterator_t<base_type> current, range_difference_t<base_type> pos) :
        current_(std::move(current)),
        pos_(pos)
    {}
    template<typename VV = V, typename B = base_type, bool C = Const, std::enable_if_t<C && xyfund::detail::convertible_to<iterator_t<VV>, iterator_t<B>>, int> = 0>
    constexpr iterator(iterator<!Const> i) : // requires Const&& convertible_to<iterator_t<V>, iterator_t<base_type>>
        current_(i.current_),
        pos_(i.pos_)
    {}

    template<typename B = base_type, std::enable_if_t<xyfund::detail::copyable<iterator_t<B>>, int> = 0>
    constexpr iterator_t<base_type> base() const& // requires copyable<iterator_t<base_type>>
    {
        return current_;
    }
    constexpr iterator_t<base_type> base() &&
    {
        return std::move(current_);
    }

    constexpr decltype(auto) operator*() const
    {
        return reference{pos_, *current_};
    }

    constexpr iterator& operator++()
    {
        current_++;
        pos_++;
        return *this;
    }
    template<typename B = base_type, std::enable_if_t<!forward_range<B>, int> = 0>
    constexpr void operator++(int) // requires(!forward_range<base_type>);
    {
        ++pos_;
        ++current_;
    }
    template<typename B = base_type, std::enable_if_t<forward_range<B>, int> = 0>
    constexpr iterator operator++(int) // requires forward_range<base_type>;
    {
        ++pos_;
        auto tmp = *this;
        ++*this;
        return tmp;
    }

    template<typename B = base_type, std::enable_if_t<bidirectional_range<B>, int> = 0>
    constexpr iterator& operator--() // requires bidirectional_range<base_type>;
    {
        --pos_;
        --current_;
        return *this;
    }
    template<typename B = base_type, std::enable_if_t<bidirectional_range<B>, int> = 0>
    constexpr iterator operator--(int) // requires bidirectional_range<base_type>;
    {
        auto tmp = *this;
        --*this;
        return tmp;
    }

    template<typename B = base_type, std::enable_if_t<random_access_range<B>, int> = 0>
    constexpr iterator& operator+=(difference_type x) // requires random_access_range<base_type>;
    {
        current_ += x;
        pos_ += x;
        return *this;
    }
    template<typename B = base_type, std::enable_if_t<random_access_range<B>, int> = 0>
    constexpr iterator& operator-=(difference_type x) // requires random_access_range<base_type>;
    {
        current_ -= x;
        pos_ -= x;
        return *this;
    }

    template<typename B = base_type, std::enable_if_t<random_access_range<B>, int> = 0>
    constexpr decltype(auto) operator[](difference_type n) const // requires random_access_range<base_type>
    {
        return reference{static_cast<difference_type>(pos_ + n), *(current_ + n)};
    }

    template<typename B = base_type, std::enable_if_t<xyfund::detail::equality_comparable<iterator_t<B>>, int> = 0>
    friend constexpr bool operator==(const iterator& x, const iterator& y) // requires equality_comparable<iterator_t<base_type>>;
    {
        return x.current_ == y.current_;
    }
    template<typename B = base_type, std::enable_if_t<xyfund::detail::equality_comparable<iterator_t<B>>, int> = 0>
    friend constexpr bool operator!=(const iterator& x, const iterator& y) // requires equality_comparable<iterator_t<base_type>>;
    {
        return x.current_ != y.current_;
    }
    template<typename B = base_type, std::enable_if_t<random_access_range<B>, int> = 0>
    friend constexpr bool operator<(const iterator& x, const iterator& y) // requires random_access_range<base_type>;
    {
        return x.current_ < y.current_;
    }
    template<typename B = base_type, std::enable_if_t<random_access_range<B>, int> = 0>
    friend constexpr bool operator>(const iterator& x, const iterator& y) // requires random_access_range<base_type>;
    {
        return x.current_ > y.current_;
    }
    template<typename B = base_type, std::enable_if_t<random_access_range<B>, int> = 0>
    friend constexpr bool operator<=(const iterator& x, const iterator& y) // requires random_access_range<base_type>;
    {
        return x.current_ <= y.current_;
    }
    template<typename B = base_type, std::enable_if_t<random_access_range<B>, int> = 0>
    friend constexpr bool operator>=(const iterator& x, const iterator& y) // requires random_access_range<base_type>;
    {
        return x.current_ >= y.current_;
    }
    // template<typename B = base_type, std::enable_if_t<random_access_range<B> && three_way_comparable<iterator_t<B>>, int> = 0>
    // friend constexpr auto operator<=>(const iterator& x, const iterator& y) // requires random_access_range<base_type>&& three_way_comparable<iterator_t<base_type>>;
    // {}
    template<typename B = base_type, std::enable_if_t<random_access_range<B>, int> = 0>
    friend constexpr iterator operator+(const iterator& x, difference_type y) // requires random_access_range<base_type>;
    {
        return iterator{x.current_ + y, static_cast<difference_type>(x.pos_ + y)};
    }
    template<typename B = base_type, std::enable_if_t<random_access_range<B>, int> = 0>
    friend constexpr iterator operator+(difference_type x, const iterator& y) // requires random_access_range<base_type>;
    {
        return iterator{x.current_ + y, static_cast<difference_type>(x.pos_ + y)};
    }
    template<typename B = base_type, std::enable_if_t<random_access_range<B>, int> = 0>
    friend constexpr iterator operator-(const iterator& x, difference_type y) // requires random_access_range<base_type>;
    {
        return iterator{x.current_ - y, static_cast<difference_type>(x.pos_ - y)};
    }
    template<typename B = base_type, std::enable_if_t<random_access_range<B>, int> = 0>
    friend constexpr difference_type operator-(const iterator& x, const iterator& y) // requires random_access_range<base_type>;
    {
        return iterator{x.current_ - y, static_cast<difference_type>(x.pos_ - y)};
    }
};

template<typename V>
// requires view<V>
template<bool Const>
class enumerate_view<V>::sentinel
{
private:
    using base_type            = std::conditional_t<Const, const V, V>;
    sentinel_t<base_type> end_ = sentinel_t<base_type>();

public:
    sentinel() = default;
    constexpr explicit sentinel(sentinel_t<base_type> end) :
        end_(std::move(end))
    {}
    template<typename VV = V, typename B = base_type, bool C = Const, std::enable_if_t<C && xyfund::detail::convertible_to<sentinel_t<VV>, sentinel_t<B>>, int> = 0>
    constexpr sentinel(sentinel<!Const> other) : // requires Const && convertible_to<sentinel_t<V>, sentinel_t<base_type>>
        end_(other.end_)
    {}

    constexpr sentinel_t<base_type> base() const
    {
        return end_;
    }

    template<bool ConstI>
    friend constexpr bool operator==(const iterator<ConstI>& x, const sentinel& y)
    {
        return x.base() == y.base();
    }
    template<bool ConstI>
    friend constexpr bool operator!=(const iterator<ConstI>& x, const sentinel& y)
    {
        return x.base() != y.base();
    }

    template<typename B = base_type, std::enable_if_t<sized_sentinel_for<sentinel_t<B>, iterator_t<B>>, int> = 0>
    friend constexpr range_difference_t<base_type> operator-(const iterator<Const>& x, const sentinel& y) // requires sized_sentinel_for<sentinel_t<base_type>, iterator_t<base_type>>
    {
        return x.current_ - y.end_;
    }
    template<typename B = base_type, std::enable_if_t<sized_sentinel_for<sentinel_t<B>, iterator_t<B>>, int> = 0>
    friend constexpr range_difference_t<base_type> operator-(const sentinel& x, const iterator<Const>& y) // requires sized_sentinel_for<sentinel_t<base_type>, iterator_t<base_type>>
    {
        return x.end_ - y.current_;
    }
};

namespace views {

namespace detail {

struct enumerate_view_fn
{
    template<typename R>
    constexpr auto operator()(R&& r) const
    {
        return xyfund::ranges::enumerate_view{std::forward<R>(r)};
    }

    template<typename R>
    constexpr friend auto operator|(R&& rng, const enumerate_view_fn& /*unused*/)
    {
        return xyfund::ranges::enumerate_view{std::forward<R>(rng)};
    }
};
} // namespace detail

inline namespace function_objects {
inline constexpr detail::enumerate_view_fn enumerate{};
}

} // namespace views

} // namespace ranges

} // namespace xyfund

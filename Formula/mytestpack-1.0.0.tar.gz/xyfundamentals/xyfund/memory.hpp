//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <memory>

namespace xyfund {

template<typename T>
std::shared_ptr<T> to_shared_ptr(std::unique_ptr<T>&& pointer)
{
    return std::shared_ptr<T>(std::move(pointer));
}

} // namespace xyfund

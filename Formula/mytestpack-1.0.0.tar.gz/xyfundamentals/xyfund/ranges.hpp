//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

// Provides C++20 ranges:
// See https://en.cppreference.com/w/cpp/ranges

#if defined(XYFUND_HAVE_STD_ANY) && !defined(XYFUND_USE_NANORANGE)
#   include <ranges>
// NOLINTNEXTLINE(cppcoreguidelines-macro-usage)
#   define XYFUND_RANGES_NAMESPACE ::std::ranges
#elif defined(XYFUND_HAVE_NANORANGE)
#   include "nanorange.hpp"
// NOLINTNEXTLINE(cppcoreguidelines-macro-usage)
#   define XYFUND_RANGES_NAMESPACE ::nano
#else
#    error "Can not build without 'ranges' implementation"
#endif

namespace xyfund {

namespace ranges {

// access
using XYFUND_RANGES_NAMESPACE::begin;
using XYFUND_RANGES_NAMESPACE::cbegin;

using XYFUND_RANGES_NAMESPACE::end;
using XYFUND_RANGES_NAMESPACE::cend;

using XYFUND_RANGES_NAMESPACE::rbegin;
using XYFUND_RANGES_NAMESPACE::crbegin;

using XYFUND_RANGES_NAMESPACE::rend;
using XYFUND_RANGES_NAMESPACE::crend;

using XYFUND_RANGES_NAMESPACE::size;
using XYFUND_RANGES_NAMESPACE::ssize;

using XYFUND_RANGES_NAMESPACE::empty;

using XYFUND_RANGES_NAMESPACE::data;
using XYFUND_RANGES_NAMESPACE::cdata;

// primitives
using XYFUND_RANGES_NAMESPACE::iterator_t;
using XYFUND_RANGES_NAMESPACE::sentinel_t;

#if defined(XYFUND_HAVE_STD_ANY) && !defined(XYFUND_USE_NANORANGE)
using XYFUND_RANGES_NAMESPACE::range_size_t;
#elif defined(XYFUND_HAVE_NANORANGE)
template <typename R> using range_size_t = std::enable_if_t<XYFUND_RANGES_NAMESPACE::sized_range<R>, decltype(XYFUND_RANGES_NAMESPACE::ranges::size(std::declval<R&>()))>;
#endif
using XYFUND_RANGES_NAMESPACE::range_difference_t;
using XYFUND_RANGES_NAMESPACE::range_value_t;
using XYFUND_RANGES_NAMESPACE::range_reference_t;
using XYFUND_RANGES_NAMESPACE::range_rvalue_reference_t;

// dangling interator handling
using XYFUND_RANGES_NAMESPACE::dangling;
using XYFUND_RANGES_NAMESPACE::borrowed_iterator_t;
using XYFUND_RANGES_NAMESPACE::borrowed_subrange_t;

// concepts
using XYFUND_RANGES_NAMESPACE::range;
using XYFUND_RANGES_NAMESPACE::borrowed_range;
using XYFUND_RANGES_NAMESPACE::sized_range;
using XYFUND_RANGES_NAMESPACE::view;
using XYFUND_RANGES_NAMESPACE::input_range;
using XYFUND_RANGES_NAMESPACE::output_range;
using XYFUND_RANGES_NAMESPACE::forward_range;
using XYFUND_RANGES_NAMESPACE::bidirectional_range;
using XYFUND_RANGES_NAMESPACE::random_access_range;
using XYFUND_RANGES_NAMESPACE::contiguous_range;
using XYFUND_RANGES_NAMESPACE::common_range;
using XYFUND_RANGES_NAMESPACE::viewable_range;

using XYFUND_RANGES_NAMESPACE::sized_sentinel_for;

// views
using XYFUND_RANGES_NAMESPACE::view_interface;
using XYFUND_RANGES_NAMESPACE::subrange;

using XYFUND_RANGES_NAMESPACE::all_view;

// factories and range adaptors

using XYFUND_RANGES_NAMESPACE::empty_view;
using XYFUND_RANGES_NAMESPACE::single_view;
using XYFUND_RANGES_NAMESPACE::iota_view;

using XYFUND_RANGES_NAMESPACE::ref_view;
using XYFUND_RANGES_NAMESPACE::filter_view;
using XYFUND_RANGES_NAMESPACE::transform_view;
using XYFUND_RANGES_NAMESPACE::take_view;
using XYFUND_RANGES_NAMESPACE::take_while_view;
using XYFUND_RANGES_NAMESPACE::drop_view;
using XYFUND_RANGES_NAMESPACE::drop_while_view;
using XYFUND_RANGES_NAMESPACE::join_view;
using XYFUND_RANGES_NAMESPACE::split_view;
using XYFUND_RANGES_NAMESPACE::common_view;
using XYFUND_RANGES_NAMESPACE::reverse_view;
using XYFUND_RANGES_NAMESPACE::basic_istream_view;
using XYFUND_RANGES_NAMESPACE::elements_view;
using XYFUND_RANGES_NAMESPACE::keys_view;
using XYFUND_RANGES_NAMESPACE::values_view;

namespace views {

using XYFUND_RANGES_NAMESPACE::views::empty;
using XYFUND_RANGES_NAMESPACE::views::single;
using XYFUND_RANGES_NAMESPACE::views::iota;

using XYFUND_RANGES_NAMESPACE::views::all;

using XYFUND_RANGES_NAMESPACE::views::filter;
using XYFUND_RANGES_NAMESPACE::views::transform;
using XYFUND_RANGES_NAMESPACE::views::take;
using XYFUND_RANGES_NAMESPACE::views::take_while;
using XYFUND_RANGES_NAMESPACE::views::drop;
using XYFUND_RANGES_NAMESPACE::views::drop_while;
using XYFUND_RANGES_NAMESPACE::views::join;
using XYFUND_RANGES_NAMESPACE::views::join;
using XYFUND_RANGES_NAMESPACE::views::split;
using XYFUND_RANGES_NAMESPACE::views::common;
using XYFUND_RANGES_NAMESPACE::views::reverse;
// using XYFUND_RANGES_NAMESPACE::views::basic_istream;
using XYFUND_RANGES_NAMESPACE::views::elements;
using XYFUND_RANGES_NAMESPACE::views::keys;
using XYFUND_RANGES_NAMESPACE::views::values;

} // namespace views

} // namespace ranges

namespace views = ::xyfund::ranges::views;

} // namespace xyfund

#undef XYFUND_RANGES_NAMESPACE
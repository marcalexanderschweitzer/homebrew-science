//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

// Provides std::flat_map. See https://wg21.link/p0429

// TODO: The implementation does actually resemble more of boost::flat_map.
//       It should be updated to conform with the proposed std::flat_map.

#include <algorithm>
#include <vector>

#ifdef XYFUND_HAVE_CEREAL
#    include <cereal/cereal.hpp>
#endif // XYFUND_HAVE_CEREAL

namespace xyfund {

template<typename Key, typename T, class Compare = std::less<Key>, class Allocator = std::allocator<std::pair<Key, T>>>
class flat_map
{
    using data_type = std::vector<std::pair<Key, T>, Allocator>;

public:
    using key_type               = Key;
    using mapped_type            = T;
    using value_type             = std::pair<const Key, T>;
    using size_type              = typename std::allocator_traits<Allocator>::size_type;
    using difference_type        = typename std::allocator_traits<Allocator>::difference_type;
    using key_compare            = Compare;
    using allocator_type         = Allocator;
    using pointer                = typename std::allocator_traits<Allocator>::pointer;
    using const_pointer          = typename std::allocator_traits<Allocator>::const_pointer;
    using reference              = value_type&;
    using const_reference        = const value_type&;
    using iterator               = typename data_type::iterator;
    using const_iterator         = typename data_type::const_iterator;
    using reverse_iterator       = typename data_type::reverse_iterator;
    using const_reverse_iterator = typename data_type::const_reverse_iterator;

    class value_compare
    {
    public:
        value_compare() = default;
        value_compare(key_compare comp);

        inline bool operator()(const value_type& lhs, const value_type& rhs) const;
        inline bool operator()(const value_type& lhs, const key_type& rhs) const;
        inline bool operator()(const key_type& lhs, const value_type& rhs) const;

        const key_compare& key_comp() const;

#ifdef XYFUND_HAVE_CEREAL
        template<typename Archive>
        inline void serialize(Archive& ar) const;
#endif // XYFUND_HAVE_CEREAL

    private:
        key_compare comp_;
    };

    // Default construction
    inline flat_map() noexcept(std::is_nothrow_default_constructible<data_type>::value&& std::is_nothrow_default_constructible<Compare>::value);
    inline flat_map(const allocator_type& allocator);

    // Copy construction
    inline flat_map(const flat_map& other);
    inline flat_map(const flat_map& other, const allocator_type& allocator);

    // Move construction
    inline flat_map(flat_map&& other) noexcept(std::is_nothrow_move_constructible<data_type>::value&& std::is_nothrow_move_constructible<Compare>::value);
    inline flat_map(flat_map&& other, const allocator_type& allocator);

    // Initialized construction
    explicit inline flat_map(const Compare& compare, const allocator_type& allocator = allocator_type());

    template<typename InputIterator>
    inline flat_map(InputIterator first, InputIterator last, const Compare& compare = Compare(), const allocator_type& allocator = allocator_type());

    inline flat_map(std::initializer_list<value_type> init, const Compare& compare = Compare(), const allocator_type& allocator = allocator_type());

    // Destruction
    inline ~flat_map() = default;

    // Copy& Move assignment
    inline flat_map& operator=(const flat_map& other);
    inline flat_map& operator=(flat_map&& other) noexcept(std::is_nothrow_move_assignable<data_type>::value&& std::is_nothrow_move_assignable<Compare>::value);

    // Members
    inline allocator_type get_allocator() const;

    // Element access
    inline mapped_type&       at(const key_type& key);
    inline const mapped_type& at(const key_type& key) const;

    inline mapped_type& operator[](const key_type& key);
    inline mapped_type& operator[](key_type&& key);

    // Iterators
    inline iterator       begin();
    inline const_iterator begin() const;
    inline iterator       end();
    inline const_iterator end() const;
    inline const_iterator cbegin() const;
    inline const_iterator cend() const;

    inline reverse_iterator       rbegin();
    inline const_reverse_iterator rbegin() const;
    inline reverse_iterator       rend();
    inline const_reverse_iterator rend() const;
    inline const_reverse_iterator crbegin() const;
    inline const_reverse_iterator crend() const;

    // Capacity
    inline bool      empty() const;
    inline size_type size() const;
    inline size_type max_size() const;
    inline size_type capacity() const;
    inline void      reserve(size_type cap);
    inline void      shrink_to_fit();

    // Modifiers
    inline void clear();

    inline std::pair<iterator, bool> insert(const value_type& value);
    inline std::pair<iterator, bool> insert(value_type&& value);
    inline iterator                  insert(const_iterator hint, const value_type& value);
    inline iterator                  insert(const_iterator hint, value_type&& value);
    template<typename InputIterator>
    inline void insert(InputIterator first, InputIterator last);
    inline void insert(std::initializer_list<value_type> init);

    //template<typename... Args>
    //inline std::pair<iterator, bool> emplace(Args&&... args);

    //template<typename... Args>
    //inline iterator emplace_hint(const_iterator hint, Args&&... args);

    inline iterator  erase(iterator position);
    inline size_type erase(const key_type& k);
    inline iterator  erase(const_iterator first, const_iterator last);

    inline void swap(flat_map& other);

    // Lookup
    inline iterator       find(const key_type& k);
    inline const_iterator find(const key_type& k) const;
    template<typename K>
    inline iterator find(const K& k);
    template<typename K>
    inline const_iterator find(const K& k) const;

    inline size_type count(const key_type& k) const;
    template<typename K>
    inline size_type count(const K& k) const;

    inline iterator       lower_bound(const key_type& k);
    inline const_iterator lower_bound(const key_type& k) const;
    template<typename K>
    inline iterator lower_bound(const K& k);
    template<typename K>
    inline const_iterator lower_bound(const K& k) const;

    inline iterator       upper_bound(const key_type& k);
    inline const_iterator upper_bound(const key_type& k) const;
    template<typename K>
    inline iterator upper_bound(const K& k);
    template<typename K>
    inline const_iterator upper_bound(const K& k) const;

    inline std::pair<iterator, iterator>             equal_range(const key_type& k);
    inline std::pair<const_iterator, const_iterator> equal_range(const key_type& k) const;

    // Observers
    inline key_compare key_comp() const;

    inline value_compare value_comp() const;

#ifdef XYFUND_HAVE_CEREAL
    template<typename Archive>
    inline void serialize(Archive& ar);
#endif // XYFUND_HAVE_CEREAL
private:
    value_compare compare_;
    data_type     data_;
};

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline flat_map<Key, T, Compare, Allocator>::value_compare::value_compare(key_compare comp) :
    comp_(std::move(comp))
{}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline bool flat_map<Key, T, Compare, Allocator>::value_compare::operator()(const value_type& lhs, const value_type& rhs) const
{
    return comp_(lhs.first, rhs.first);
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline bool flat_map<Key, T, Compare, Allocator>::value_compare::operator()(const value_type& lhs, const key_type& rhs) const
{
    return comp_(lhs.first, rhs);
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline bool flat_map<Key, T, Compare, Allocator>::value_compare::operator()(const key_type& lhs, const value_type& rhs) const
{
    return comp_(lhs, rhs.first);
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
const typename flat_map<Key, T, Compare, Allocator>::key_compare& flat_map<Key, T, Compare, Allocator>::value_compare::key_comp() const
{
    return comp_;
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
flat_map<Key, T, Compare, Allocator>::flat_map() noexcept(std::is_nothrow_default_constructible<data_type>::value&& std::is_nothrow_default_constructible<Compare>::value) :
    compare_(),
    data_()
{}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline flat_map<Key, T, Compare, Allocator>::flat_map(const allocator_type& allocator) :
    compare_(),
    data_(allocator)
{}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline flat_map<Key, T, Compare, Allocator>::flat_map(const flat_map& other) :
    compare_(other.compare_),
    data_(other.data_)
{}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline flat_map<Key, T, Compare, Allocator>::flat_map(const flat_map& other, const allocator_type& allocator) :
    compare_(other.compare_),
    data_(other.data_, allocator)
{}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline flat_map<Key, T, Compare, Allocator>::flat_map(flat_map&& other) noexcept(std::is_nothrow_move_constructible<data_type>::value&& std::is_nothrow_move_constructible<Compare>::value) :
    compare_(std::move(other.compare_)),
    data_(std::move(other.data_))
{}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline flat_map<Key, T, Compare, Allocator>::flat_map(flat_map&& other, const allocator_type& allocator) :
    compare_(std::move(other.compare_)),
    data_(std::move(other.data_), allocator)
{}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline flat_map<Key, T, Compare, Allocator>::flat_map(const Compare& compare, const allocator_type& allocator) :
    compare_{compare},
    data_(allocator)
{}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
template<typename InputIterator>
inline flat_map<Key, T, Compare, Allocator>::flat_map(InputIterator first, InputIterator last, const Compare& compare, const allocator_type& allocator) :
    compare_{compare},
    data_(allocator)
{
    insert(first, last);
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline flat_map<Key, T, Compare, Allocator>::flat_map(std::initializer_list<value_type> init, const Compare& compare, const allocator_type& allocator) :
    compare_{compare},
    data_(allocator)
{
    insert(init);
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline flat_map<Key, T, Compare, Allocator>& flat_map<Key, T, Compare, Allocator>::operator=(const flat_map& other)
{
    compare_ = other.compare_;
    data_    = other.data_;
    return *this;
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline flat_map<Key, T, Compare, Allocator>& flat_map<Key, T, Compare, Allocator>::operator=(flat_map&& other) noexcept(std::is_nothrow_move_assignable<data_type>::value&& std::is_nothrow_move_assignable<Compare>::value)
{
    compare_ = std::move(other.compare_);
    data_    = std::move(other.data_);
    return *this;
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::allocator_type flat_map<Key, T, Compare, Allocator>::get_allocator() const
{
    return data_.get_allocator();
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::mapped_type& flat_map<Key, T, Compare, Allocator>::at(const key_type& key)
{
    auto i = find(key);
    if(i == end()) throw std::out_of_range("flat_map::at");
    return i->second;
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline const typename flat_map<Key, T, Compare, Allocator>::mapped_type& flat_map<Key, T, Compare, Allocator>::at(const key_type& key) const
{
    auto i = find(key);
    if(i == end()) throw std::out_of_range("flat_map::at");
    return i->second;
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::mapped_type& flat_map<Key, T, Compare, Allocator>::operator[](const key_type& key)
{
    auto i = lower_bound(key);
    if(i == end() || compare_.key_comp()(key, i->first))
    {
        i = data_.emplace(i, value_type(std::piecewise_construct, key, std::forward_as_tuple()));
    }
    return i->second;
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::mapped_type& flat_map<Key, T, Compare, Allocator>::operator[](key_type&& key)
{
    auto i = lower_bound(key);
    if(i == end() || compare_.key_comp()(key, i->first))
    {
        i = data_.emplace(i, value_type(std::piecewise_construct, std::forward_as_tuple(std::forward<Key>(key)), std::forward_as_tuple()));
    }
    return i->second;
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::iterator flat_map<Key, T, Compare, Allocator>::begin()
{
    return data_.begin();
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::const_iterator flat_map<Key, T, Compare, Allocator>::begin() const
{
    return data_.begin();
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::iterator flat_map<Key, T, Compare, Allocator>::end()
{
    return data_.end();
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::const_iterator flat_map<Key, T, Compare, Allocator>::end() const
{
    return data_.end();
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::const_iterator flat_map<Key, T, Compare, Allocator>::cbegin() const
{
    return data_.cbegin();
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::const_iterator flat_map<Key, T, Compare, Allocator>::cend() const
{
    return data_.cend();
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::reverse_iterator flat_map<Key, T, Compare, Allocator>::rbegin()
{
    return data_.rbegin();
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::const_reverse_iterator flat_map<Key, T, Compare, Allocator>::rbegin() const
{
    return data_.rbegin();
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::reverse_iterator flat_map<Key, T, Compare, Allocator>::rend()
{
    return data_.rend();
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::const_reverse_iterator flat_map<Key, T, Compare, Allocator>::rend() const
{
    return data_.rend();
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::const_reverse_iterator flat_map<Key, T, Compare, Allocator>::crbegin() const
{
    return data_.crbegin();
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::const_reverse_iterator flat_map<Key, T, Compare, Allocator>::crend() const
{
    return data_.crend();
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline bool flat_map<Key, T, Compare, Allocator>::empty() const
{
    return data_.empty();
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::size_type flat_map<Key, T, Compare, Allocator>::size() const
{
    return data_.size();
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::size_type flat_map<Key, T, Compare, Allocator>::max_size() const
{
    return data_.max_size();
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::size_type flat_map<Key, T, Compare, Allocator>::capacity() const
{
    return data_.capacity();
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline void flat_map<Key, T, Compare, Allocator>::reserve(size_type cap)
{
    return data_.reserve(cap);
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline void flat_map<Key, T, Compare, Allocator>::shrink_to_fit()
{
    return data_.shrink_to_fit();
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline void flat_map<Key, T, Compare, Allocator>::clear()
{
    return data_.clear();
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline std::pair<typename flat_map<Key, T, Compare, Allocator>::iterator, bool> flat_map<Key, T, Compare, Allocator>::insert(const value_type& value)
{
    bool found = true;
    auto i     = lower_bound(value.first);

    if(i == end() || compare_(value, *i))
    {
        i     = data_.insert(i, value);
        found = false;
    }
    return std::make_pair(i, !found);
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline std::pair<typename flat_map<Key, T, Compare, Allocator>::iterator, bool> flat_map<Key, T, Compare, Allocator>::insert(value_type&& value)
{
    bool found = true;
    auto i     = lower_bound(value.first);

    if(i == end() || compare_(value, *i))
    {
        i     = data_.insert(i, std::move(value));
        found = false;
    }
    return std::make_pair(i, !found);
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::iterator flat_map<Key, T, Compare, Allocator>::insert(const_iterator hint, const value_type& value)
{
    if((hint == begin() || compare_(*(hint - 1), value)) && (hint == end() || compare_(value, hint)))
    {
        return data_.insert(hint, value);
    }
    return insert(value).first;
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::iterator flat_map<Key, T, Compare, Allocator>::insert(const_iterator hint, value_type&& value)
{
    if((hint == begin() || compare_(*(hint - 1), value)) && (hint == end() || compare_(value, hint)))
    {
        return data_.insert(hint, std::move(value));
    }
    return insert(std::move(value)).first;
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
template<typename InputIterator>
inline void flat_map<Key, T, Compare, Allocator>::insert(InputIterator first, InputIterator last)
{
    for(; first != last; ++first) insert(*first);
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline void flat_map<Key, T, Compare, Allocator>::insert(std::initializer_list<value_type> init)
{
    insert(init.begin(), init.end());
}

////===========================================================================================================
//template<typename Key, typename T, class Compare, class Allocator>
//template<typename ...Args>
//inline std::pair<typename flat_map<Key, T, Compare, Allocator>::iterator, bool> flat_map<Key, T, Compare, Allocator>::emplace(Args && ...args)
//{
//    return std::pair<iterator, bool>();
//}
//
////===========================================================================================================
//template<typename Key, typename T, class Compare, class Allocator>
//template<typename ...Args>
//inline typename flat_map<Key, T, Compare, Allocator>::iterator flat_map<Key, T, Compare, Allocator>::emplace_hint(const_iterator hint, Args && ...args)
//{
//    return iterator();
//}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::iterator flat_map<Key, T, Compare, Allocator>::erase(iterator position)
{
    return data_.erase(position);
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::size_type flat_map<Key, T, Compare, Allocator>::erase(const key_type& k)
{
    auto i = find(k);
    if(i == end()) return 0;
    erase(i);
    return 1;
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::iterator flat_map<Key, T, Compare, Allocator>::erase(const_iterator first, const_iterator last)
{
    return data_.erase(first, last);
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline void flat_map<Key, T, Compare, Allocator>::swap(flat_map& other)
{
    std::swap(data_, other.data);
    std::swap(compare_, other.compare_);
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::iterator flat_map<Key, T, Compare, Allocator>::find(const key_type& k)
{
    auto i = lower_bound(k);
    if(i != end() && compare_.key_comp()(k, i->first))
    {
        i = end();
    }
    return i;
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::const_iterator flat_map<Key, T, Compare, Allocator>::find(const key_type& k) const
{
    auto i = lower_bound(k);
    if(i != end() && compare_.key_comp()(k, i->first))
    {
        i = end();
    }
    return i;
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
template<typename K>
inline typename flat_map<Key, T, Compare, Allocator>::iterator flat_map<Key, T, Compare, Allocator>::find(const K& k)
{
    auto i = lower_bound(k);
    if(i != end() && compare_.key_comp()(k, i->first))
    {
        i = end();
    }
    return i;
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
template<typename K>
inline typename flat_map<Key, T, Compare, Allocator>::const_iterator flat_map<Key, T, Compare, Allocator>::find(const K& k) const
{
    auto i = lower_bound(k);
    if(i != end() && compare_.key_comp()(k, i->first))
    {
        i = end();
    }
    return i;
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::size_type flat_map<Key, T, Compare, Allocator>::count(const key_type& k) const
{
    return find(k) != end() ? 1 : 0;
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
template<typename K>
inline typename flat_map<Key, T, Compare, Allocator>::size_type flat_map<Key, T, Compare, Allocator>::count(const K& k) const
{
    return find(k) != end() ? 1 : 0;
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::iterator flat_map<Key, T, Compare, Allocator>::lower_bound(const key_type& k)
{
    return std::lower_bound(begin(), end(), k, compare_);
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::const_iterator flat_map<Key, T, Compare, Allocator>::lower_bound(const key_type& k) const
{
    return std::lower_bound(begin(), end(), k, compare_);
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
template<typename K>
inline typename flat_map<Key, T, Compare, Allocator>::iterator flat_map<Key, T, Compare, Allocator>::lower_bound(const K& k)
{
    return std::lower_bound(begin(), end(), k, compare_);
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
template<typename K>
inline typename flat_map<Key, T, Compare, Allocator>::const_iterator flat_map<Key, T, Compare, Allocator>::lower_bound(const K& k) const
{
    return std::lower_bound(begin(), end(), k, compare_);
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::iterator flat_map<Key, T, Compare, Allocator>::upper_bound(const key_type& k)
{
    return std::upper_bound(begin(), end(), k, compare_);
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::const_iterator flat_map<Key, T, Compare, Allocator>::upper_bound(const key_type& k) const
{
    return std::upper_bound(begin(), end(), k, compare_);
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
template<typename K>
inline typename flat_map<Key, T, Compare, Allocator>::iterator flat_map<Key, T, Compare, Allocator>::upper_bound(const K& k)
{
    return std::upper_bound(begin(), end(), k, compare_);
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
template<typename K>
inline typename flat_map<Key, T, Compare, Allocator>::const_iterator flat_map<Key, T, Compare, Allocator>::upper_bound(const K& k) const
{
    return std::upper_bound(begin(), end(), k, compare_);
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline std::pair<typename flat_map<Key, T, Compare, Allocator>::iterator, typename flat_map<Key, T, Compare, Allocator>::iterator> flat_map<Key, T, Compare, Allocator>::equal_range(const key_type& k)
{
    return std::equal_range(begin(), end(), k, compare_);
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline std::pair<typename flat_map<Key, T, Compare, Allocator>::const_iterator, typename flat_map<Key, T, Compare, Allocator>::const_iterator> flat_map<Key, T, Compare, Allocator>::equal_range(const key_type& k) const
{
    return std::equal_range(begin(), end(), k, compare_);
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::key_compare flat_map<Key, T, Compare, Allocator>::key_comp() const
{
    return compare_.key_comp();
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
inline typename flat_map<Key, T, Compare, Allocator>::value_compare flat_map<Key, T, Compare, Allocator>::value_comp() const
{
    return compare_;
}

#ifdef XYFUND_HAVE_CEREAL
//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
template<typename Archive>
inline void flat_map<Key, T, Compare, Allocator>::value_compare::serialize(Archive& ar) const
{
    ar(comp_);
}

//===========================================================================================================
template<typename Key, typename T, class Compare, class Allocator>
template<typename Archive>
inline void flat_map<Key, T, Compare, Allocator>::serialize(Archive& ar)
{
    ar(data_);
    ar(compare_);
}
#endif // XYFUND_HAVE_CEREAL

} // namespace xyfund

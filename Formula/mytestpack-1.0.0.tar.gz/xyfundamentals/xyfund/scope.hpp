//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

// Provides std::scope_exit. See https://wg21.link/p0052r8

namespace xyfund {

template<typename F>
class scope_exit
{
    F    exit_function_;
    bool execute_;

public:
    template<typename EF>
    inline explicit scope_exit(EF&& exit_function) noexcept(std::is_nothrow_constructible_v<F, EF> || std::is_nothrow_constructible_v<F, EF&>); // NOLINT(bugprone-forwarding-reference-overload)
    inline scope_exit(scope_exit&& other) noexcept;                                                                                             // NOLINT(bugprone-forwarding-reference-overload)
    inline ~scope_exit() noexcept;                                                                                                              // NOLINT(bugprone-exception-escape)

    scope_exit(const scope_exit&) = delete;
    scope_exit& operator=(const scope_exit&) = delete;
    scope_exit& operator=(scope_exit&&) = delete;

    void release();
};

//===========================================================================================================
template<typename F>
template<typename EF>
// NOLINTNEXTLINE(bugprone-forwarding-reference-overload)
inline scope_exit<F>::scope_exit(EF&& exit_function) noexcept(std::is_nothrow_constructible_v<F, EF> || std::is_nothrow_constructible_v<F, EF&>) :
    exit_function_(std::forward<EF>(exit_function)),
    execute_(true)
{}

//===========================================================================================================
template<typename F>
inline scope_exit<F>::scope_exit(scope_exit&& other) noexcept :
    exit_function_(std::move(other.exit_function_)),
    execute_(other.execute_)
{
    other.execute_ = false;
}

//===========================================================================================================
template<typename F>
inline scope_exit<F>::~scope_exit() noexcept
{
    if(execute_)
    {
        exit_function_();
    }
}

//===========================================================================================================
template<typename F>
void scope_exit<F>::release()
{
    execute_ = false;
}

//===========================================================================================================
template<typename F>
scope_exit<F> make_scope_exit(F&& function)
{
    return scope_exit<F>(std::forward<F>(function));
}

} // namespace xyfund

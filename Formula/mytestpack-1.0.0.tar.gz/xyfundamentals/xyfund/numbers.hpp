//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

// Provides std::numbers constants. See https://wg21.link/p0631r8

// Additionally a class xyfund::numbers::constants<T> is provided.
// This class has static member functions that just return the corresponding constant,
// but since those are functions instead of constexpr inline variables, they can be
// overwritten for scalar types that are not literal types.

namespace xyfund {

namespace numbers {

// clang-format off

template<typename T> inline constexpr T e_v          = static_cast<T>(2.7182818284590452353602874713526625L); // e
template<typename T> inline constexpr T log2e_v      = static_cast<T>(1.4426950408889634073599246810018921L); // log2(e)
template<typename T> inline constexpr T log10e_v     = static_cast<T>(0.4342944819032518276511289189166051L); // log10(e)
template<typename T> inline constexpr T pi_v         = static_cast<T>(3.1415926535897932384626433832795029L); // pi
template<typename T> inline constexpr T inv_pi_v     = static_cast<T>(0.3183098861837906715377675267450287L); // 1 / pi
template<typename T> inline constexpr T inv_sqrtpi_v = static_cast<T>(0.5641895835477562869480794515607725L); // 1 / sqrt(pi)
template<typename T> inline constexpr T ln2_v        = static_cast<T>(0.6931471805599453094172321214581766L); // ln(2)
template<typename T> inline constexpr T ln10_v       = static_cast<T>(2.3025850929940456840179914546843642L); // ln(10)
template<typename T> inline constexpr T sqrt2_v      = static_cast<T>(1.4142135623730950488016887242096981L); // sqrt(2)
template<typename T> inline constexpr T sqrt3_v      = static_cast<T>(1.7320508075688772935274463415058723L); // sqrt(3)
template<typename T> inline constexpr T inv_sqrt3_v  = static_cast<T>(0.5773502691896257645091487805019574L); // 1 / sqrt(3)
template<typename T> inline constexpr T egamma_v     = static_cast<T>(0.5772156649015328606065120900824024L); // Euler-Mascheroni constant
template<typename T> inline constexpr T phi_v        = static_cast<T>(1.6180339887498948482045868343656381L); // Golden ratio: (1+sqrt(5)) / 2

inline constexpr double e                = e_v<double>;
inline constexpr double log2e            = log2e_v<double>;
inline constexpr double log10e           = log10e_v<double>;
inline constexpr double pi               = pi_v<double>;
inline constexpr double inv_pi           = inv_pi_v<double>;
inline constexpr double inv_sqrtpi       = inv_sqrtpi_v<double>;
inline constexpr double ln2              = ln2_v<double>;
inline constexpr double ln10             = ln10_v<double>;
inline constexpr double sqrt2            = sqrt2_v<double>;
inline constexpr double sqrt3            = sqrt3_v<double>;
inline constexpr double inv_sqrt3        = inv_sqrt3_v<double>;
inline constexpr double egamma           = egamma_v<double>;
inline constexpr double phi              = phi_v<double>;

template<typename T>
class constants
{
public:
    inline static constexpr T e()          { return e_v<T>; };
    inline static constexpr T log2e()      { return log2e_v<T>; }
    inline static constexpr T log10e()     { return log10e_v<T>; }
    inline static constexpr T pi()         { return pi_v<T>; }
    inline static constexpr T inv_pi()     { return inv_pi_v<T>; }
    inline static constexpr T inv_sqrtpi() { return inv_sqrtpi_v<T>; }
    inline static constexpr T ln2()        { return ln2_v<T>; }
    inline static constexpr T ln10()       { return ln10_v<T>; }
    inline static constexpr T sqrt2()      { return sqrt2_v<T>; }
    inline static constexpr T sqrt3()      { return sqrt3_v<T>; }
    inline static constexpr T inv_sqrt3()  { return inv_sqrt3_v<T>; }
    inline static constexpr T egamma()     { return egamma_v<T>; }
    inline static constexpr T phi()        { return phi_v<T>; }
};

// clang-format on

} // namespace numbers

} // namespace xyfund

//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

// Provides std::any. See https://en.cppreference.com/w/cpp/utility/variant

#include <type_traits>

#if defined(XYFUND_HAVE_STD_VARIANT) && !defined(XYFUND_USE_BOOST_VARIANT)
#    include <variant>
#elif defined(XYFUND_HAVE_BOOST_VARIANT)
#    include <boost/variant.hpp>
#    include <boost/variant/multivisitors.hpp>
#endif

namespace xyfund {

#if defined(XYFUND_HAVE_STD_VARIANT) && !defined(XYFUND_USE_BOOST_VARIANT)

//===========================================================================================================
template<typename... Ts>
using variant = std::variant<Ts...>;

//===========================================================================================================
using std::visit;

//===========================================================================================================
using std::holds_alternative;

//===========================================================================================================
using std::variant_size;
using std::variant_size_v;

//===========================================================================================================
using std::variant_alternative;
using std::variant_alternative_t;

template<typename T, typename... Ts>
constexpr T& get(variant<Ts...>& v)
{
    return std::get<T>(v);
}

template<typename T, typename... Ts>
constexpr T&& get(variant<Ts...>&& v)
{
    return std::get<T>(std::move(v));
}

template<typename T, typename... Ts>
constexpr const T& get(const variant<Ts...>& v)
{
    return std::get<T>(v);
}

template<typename T, typename... Ts>
constexpr const T&& get(const variant<Ts...>&& v)
{
    return std::get<T>(std::move(v));
}

template<typename T, typename... Ts>
constexpr std::add_pointer_t<T> get_if(variant<Ts...>* pv) noexcept
{
    return std::get_if<T>(pv);
}

template<typename T, typename... Ts>
constexpr std::add_pointer_t<const T> get_if(const variant<Ts...>* pv) noexcept
{
    return std::get_if<T>(pv);
}

#elif defined(XYFUND_HAVE_BOOST_VARIANT)

//===========================================================================================================
template<typename... Ts>
using variant = boost::variant<Ts...>;

//===========================================================================================================
template<typename Visitor, typename... Variants>
constexpr decltype(auto) visit(Visitor&& vis, Variants&&... vars)
{
    return boost::apply_visitor(std::forward<Visitor>(vis), std::forward<Variants>(vars)...);
}

//===========================================================================================================
template<typename Variant>
struct variant_size;

template<typename... Ts>
struct variant_size<boost::variant<Ts...>>
{
    static constexpr std::size_t value = sizeof...(Ts);
};

template<typename T>
inline constexpr std::size_t variant_size_v = variant_size<T>::value;

//===========================================================================================================
template<std::size_t I, typename T>
struct variant_alternative;

template<std::size_t I, typename Head, typename... Tail>
struct variant_alternative<I, variant<Head, Tail...>> : variant_alternative<I - 1, variant<Tail...>>
{};

template<typename Head, typename... Tail>
struct variant_alternative<0, variant<Head, Tail...>>
{
    using type = Head;
};

template<std::size_t I, typename T>
using variant_alternative_t = typename variant_alternative<I, T>::type;

//===========================================================================================================
template<typename T, typename... Ts>
constexpr bool holds_alternative(const variant<Ts...>& v) noexcept
{
    return v.type() == typeid(T);
}

//===========================================================================================================
template<typename T, typename... Ts>
constexpr T& get(variant<Ts...>& v)
{
    return boost::get<T>(v);
}

template<typename T, typename... Ts>
constexpr T&& get(variant<Ts...>&& v)
{
    return boost::get<T>(std::move(v));
}

template<typename T, typename... Ts>
constexpr const T& get(const variant<Ts...>& v)
{
    return boost::get<T>(v);
}

template<typename T, typename... Ts>
constexpr const T&& get(const variant<Ts...>&& v)
{
    return boost::get<T>(std::move(v));
}

template<typename T, typename... Ts>
constexpr std::add_pointer_t<T> get_if(variant<Ts...>* pv) noexcept
{
    return boost::strict_get<T>(pv);
}

template<typename T, typename... Ts>
constexpr std::add_pointer_t<const T> get_if(const variant<Ts...>* pv) noexcept
{
    return boost::strict_get<T>(pv);
}

#else
#    error "Can not build without 'variant' implementation"
#endif

} // namespace xyfund

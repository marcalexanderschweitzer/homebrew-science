//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <xyfund/fixed_string.hpp>
#include <xyfund/units/named.hpp>
#include <xyfund/units/traits.hpp>

namespace xyfund {
namespace units {

template<typename, std::intmax_t>
struct unit_power;

template<typename...>
struct unit_product;

template<typename SymbolTag, typename Unit>
struct base_dimension : named<base_dimension<SymbolTag, Unit>>
{
    using unit = Unit;

    static constexpr auto symbol_value = SymbolTag::symbol; 
};

template<typename BaseDimension, std::intmax_t Power>
struct dimension_power : named<dimension_power<BaseDimension, Power>>
{
    static_assert(traits::is_dimension_v<BaseDimension>);
    static_assert(Power != 0, "Power must be nonzero!");

    using unit = unit_power<traits::unit_t<BaseDimension>, Power>;
    
    static constexpr auto symbol_value = append_power_to_string<Power>(BaseDimension::symbol()); 
};

template<typename BaseDimension>
struct dimension_power<BaseDimension, 1> : BaseDimension
{};

template<typename... DimensionPower>
struct dimension_product : named<dimension_product<DimensionPower...>>
{
    static_assert((traits::is_dimension_v<DimensionPower> && ...));

    using unit = unit_product<traits::unit_t<DimensionPower>...>;

    static constexpr auto symbol_value = (... + DimensionPower::symbol()); 
};

namespace traits {
template<typename SymbolTag, typename Unit>
struct is_dimension<base_dimension<SymbolTag, Unit>> : std::true_type
{};

template<typename BaseDimension, std::intmax_t Power>
struct is_dimension<dimension_power<BaseDimension, Power>> : std::true_type
{};

template<typename... DimensionPower>
struct is_dimension<dimension_product<DimensionPower...>> : std::true_type
{};

} // namespace traits

namespace symbol {

struct time
{
    static constexpr fixed_string<char, 1> symbol = "T";
};

struct length
{
    static constexpr fixed_string<char, 1> symbol = "L";
};

struct mass
{
    static constexpr fixed_string<char, 1> symbol = "M";
};

struct temperature
{
    static constexpr fixed_string<char, 1> symbol = "O";
};

struct current
{
    static constexpr fixed_string<char, 1> symbol = "I";
};

struct amount_of_substance
{
    static constexpr fixed_string<char, 1> symbol = "N";
};

struct luminous_intensity
{
    static constexpr fixed_string<char, 1> symbol = "J";
};

struct angle
{
    static constexpr fixed_string<char, 1> symbol = "A";
};

} // namespace symbol

template<typename Unit>
using base_dim_time = base_dimension<symbol::time, Unit>;

template<typename Unit>
using base_dim_length = base_dimension<symbol::length, Unit>;

template<typename Unit>
using base_dim_mass = base_dimension<symbol::mass, Unit>;

template<typename Unit>
using base_dim_temperature = base_dimension<symbol::temperature, Unit>;

template<typename Unit>
using base_dim_current = base_dimension<symbol::current, Unit>;

template<typename Unit>
using base_dim_amount_of_substance = base_dimension<symbol::amount_of_substance, Unit>;

template<typename Unit>
using base_dim_luminous_intensity = base_dimension<symbol::luminous_intensity, Unit>;

template<typename Unit>
using base_dim_angle = base_dimension<symbol::angle, Unit>;

} // namespace units
} // namespace xyfund
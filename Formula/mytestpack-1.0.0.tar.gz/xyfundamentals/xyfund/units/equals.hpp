//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <xyfund/units/quantity.hpp>
#include <xyfund/units/tags.hpp>
#include <xyfund/units/traits.hpp>
#include <xyfund/units/transformation/affine.hpp>
#include <xyfund/units/transformation/ratio.hpp>

namespace xyfund {
namespace units {

template<typename ObjectLhsType, typename ObjectRhsType>
constexpr bool equals(const ObjectLhsType& obj1, const ObjectRhsType& obj2, double epsilon = 1e-8);

namespace detail {

// ------------------- Quantity ----------------- //
template<typename Dimension1, typename Unit1, typename Representation1, typename Dimension2, typename Unit2, typename Representation2>
constexpr bool equals_impl(const quantity<Dimension1, Unit1, Representation1>& lhs, tags::quantity&& /*unused*/, const quantity<Dimension2, Unit2, Representation2>& rhs, tags::quantity&& /*unused*/, double epsilon)
{
    static_assert(traits::is_equivalent_dim_v<Dimension1, Dimension2>, "Units need equivalent dimensions to be comparable!");
    static_assert(traits::is_same_base_reference_unit_v<Unit1, Unit2>, "Units need the same base reference unit to be comparable!");

    const auto lhs_base_reference = to_base_reference_unit(lhs);
    const auto rhs_base_reference = to_base_reference_unit(rhs);

    using lhs_representation = traits::representation_t<decltype(lhs_base_reference)>;
    using rhs_representation = traits::representation_t<decltype(rhs_base_reference)>;

    if constexpr(std::is_integral<lhs_representation>::value && std::is_integral<rhs_representation>::value)
    {
        (void)epsilon;
        return lhs_base_reference.count() == rhs_base_reference.count();
    }
    else
    {
        return (lhs_base_reference.count() > rhs_base_reference.count() ? lhs_base_reference.count() - rhs_base_reference.count() : rhs_base_reference.count() - lhs_base_reference.count()) < epsilon;
    }
}

// ------------------- Identity Transformation ----------------- //
template<typename LhsType, typename RhsType>
constexpr bool equals_impl(const LhsType& /*unused*/, tags::identity&& /*unused*/, const RhsType& /*unused*/, tags::identity&& /*unused*/, double /*unused*/)
{
    return true;
}

// ------------------- Ratio Transformation ----------------- //
template<typename RatioTypeLhs, typename RatioTypeRhs>
constexpr bool equals_impl(const RatioTypeLhs& /*unused*/, tags::ratio&& /*unused*/, const RatioTypeRhs& /*unused*/, tags::ratio&& /*unused*/, double /*unused*/)
{
    return RatioTypeLhs::numerator == RatioTypeRhs::numerator && RatioTypeLhs::denominator == RatioTypeRhs::denominator && RatioTypeLhs::exponent_10 == RatioTypeRhs::exponent_10 && RatioTypeLhs::exponent_pi == RatioTypeRhs::exponent_pi;
}

// ------------------- Affine Transformation ----------------- //
template<typename AffineTypeLhs, typename AffineTypeRhs>
constexpr bool equals_impl(const AffineTypeLhs& /*unused*/, tags::affine&& /*unused*/, const AffineTypeRhs& /*unused*/, tags::affine&& /*unused*/, double /*unused*/)
{
    return equals(traits::factor_t<AffineTypeLhs>(), traits::factor_t<AffineTypeRhs>()) && equals(traits::offset_t<AffineTypeLhs>(), traits::offset_t<AffineTypeRhs>());
}

} // namespace detail

template<typename ObjectLhsType, typename ObjectRhsType>
constexpr bool equals(const ObjectLhsType& obj1, const ObjectRhsType& obj2, double epsilon)
{
    return detail::equals_impl(obj1, traits::type_tag_t<ObjectLhsType>(), obj2, traits::type_tag_t<ObjectRhsType>(), epsilon);
}

} // namespace units
} // namespace xyfund
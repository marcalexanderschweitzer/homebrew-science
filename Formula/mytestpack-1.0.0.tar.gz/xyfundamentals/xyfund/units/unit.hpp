//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <type_traits>

#include <xyfund/units/named.hpp>
#include <xyfund/units/traits.hpp>
#include <xyfund/units/transformation/identity.hpp>
#include <xyfund/units/transformation/power.hpp>
#include <xyfund/units/transformation/product.hpp>
#include <xyfund/units/transformation/make_chain.hpp>

#pragma once

namespace xyfund {
namespace units {

template<typename Transformation, typename ReferenceUnit>
struct scaled_unit
{
    using transformation = Transformation;
    using reference_unit = ReferenceUnit;
};

template<typename SymbolTag>
struct named_unit : named<named_unit<SymbolTag>>, scaled_unit<transformation::identity, named_unit<SymbolTag>>
{
    static constexpr auto symbol_value = SymbolTag::symbol(); 
};

template<typename SymbolTag, typename Transformation, typename ReferenceUnit>
struct named_scaled_unit : named<named_scaled_unit<SymbolTag, Transformation, ReferenceUnit>>, scaled_unit<Transformation, ReferenceUnit>
{
    static constexpr auto symbol_value = SymbolTag::symbol(); 
};

template<typename Prefix, typename ReferenceUnit>
struct prefixed_unit : named<prefixed_unit<Prefix, ReferenceUnit>>, scaled_unit<transformation::chain_result_t<traits::transformation_t<Prefix>, traits::transformation_t<ReferenceUnit>>, ReferenceUnit>
{
    static_assert(ReferenceUnit::is_named, "ReferenceUnit is not named!");

    static constexpr auto symbol_value = Prefix::symbol() + ReferenceUnit::symbol(); 
};

template<typename Unit, std::intmax_t Power>
struct unit_power : named<unit_power<Unit, Power>>
{
    static_assert(Power != 0, "Unit power must be nonzero!");

    static constexpr auto symbol_value = append_power_to_string<Power>(Unit::symbol()); 

    using transformation = transformation::power<traits::transformation_t<Unit>, Power>;
    using reference_unit = unit_power<traits::reference_unit_t<Unit>, Power>;
};

template<typename Unit>
struct unit_power<Unit, 1> : Unit
{};

template<typename... Unit>
struct unit_product : named<unit_product<Unit...>>
{
    static constexpr auto symbol_value = (... + Unit::symbol()); 

    using transformation = transformation::product<typename Unit::transformation...>;
    using reference_unit = unit_product<traits::reference_unit_t<Unit>...>;
};

namespace traits
{

    template<typename... Ts>
    struct is_unit<scaled_unit<Ts...>> : std::true_type
    {};

    template<typename... Ts>
    struct is_unit<named_unit<Ts...>> : std::true_type
    {};

    template<typename... Ts>
    struct is_unit<named_scaled_unit<Ts...>> : std::true_type
    {};

    template<typename... Ts>
    struct is_unit<prefixed_unit<Ts...>> : std::true_type
    {};

    template<typename Unit, std::intmax_t Power>
    struct is_unit<unit_power<Unit, Power>> : std::true_type
    {};

    template<typename... Ts>
    struct is_unit<unit_product<Ts...>> : std::true_type
    {};

    template<typename Unit, std::intmax_t Power, typename NewBaseUnit>
    struct replace_base_unit<unit_power<Unit, Power>, NewBaseUnit>
    {
        using type = unit_power<replace_base_unit_t<Unit, NewBaseUnit>, Power>;
    };

    template<typename NewBaseUnit, typename... Unit>
    struct replace_base_unit<unit_product<Unit...>, NewBaseUnit>
    {
        using type = unit_product<replace_base_unit_t<Unit, NewBaseUnit>...>;
    };

} // namespace traits

} // namespace units
} // namespace xyfund

//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <xyfund/units/base_dimension.hpp>
#include <xyfund/units/traits.hpp>
#include <xyfund/units/transformation/make_chain.hpp>

#include <xyfund/detail/python.hpp>

#pragma once

namespace xyfund {
namespace units {

namespace detail {

template<typename Unit, bool>
struct to_base_reference_unit_transformation
{
    using reference_unit = traits::reference_unit_t<Unit>;

    // recursively chain all transformations until we arrive at the base reference unit
    using type = decltype(make_chain(Unit::transformation::get(), to_base_reference_unit_transformation<reference_unit, traits::is_base_reference_unit_v<reference_unit>>::type::get()));
};

template<typename Unit>
struct to_base_reference_unit_transformation<Unit, true>
{
    using type = traits::transformation_t<Unit>;
};

template<typename Unit>
using to_base_reference_unit_transformation_t = typename to_base_reference_unit_transformation<Unit, traits::is_base_reference_unit_v<Unit>>::type;

template<typename QuantityTo, typename QuantityFrom, typename Enabled = void>
struct total_transformation;

template<typename UnitTo, typename UnitFrom>
struct total_transformation<UnitTo, UnitFrom, std::enable_if_t<traits::is_unit_v<UnitTo> && traits::is_unit_v<UnitFrom>>>
{
    using unit_from_base_reference_transformation = to_base_reference_unit_transformation_t<UnitFrom>;
    using unit_to_base_reference_transformation   = to_base_reference_unit_transformation_t<UnitTo>;

    // transform UnitFrom to base reference unit and then transform back to UnitTo.
    using type = std::conditional_t<traits::is_same_base_reference_unit_v<UnitFrom, UnitTo>, decltype(make_chain(unit_from_base_reference_transformation::get(), unit_to_base_reference_transformation::inverse())), void>;
};

template<typename QuantityTo, typename QuantityFrom>
struct total_transformation<QuantityTo, QuantityFrom, std::enable_if_t<traits::is_quantity_v<QuantityTo> && traits::is_quantity_v<QuantityFrom>>>
{
    using type = typename total_transformation<traits::unit_t<QuantityTo>, traits::unit_t<QuantityFrom>>::type;
};

template<typename To, typename From>
using total_transformation_t = typename total_transformation<To, From>::type;

} // namespace detail

template<typename Dimension, typename Unit, typename Representation = double>
class quantity;

template<typename QuantityTo, typename QuantityFrom, typename std::enable_if_t<traits::is_quantity_v<QuantityTo> && traits::is_quantity_v<QuantityFrom>>* = nullptr>
constexpr auto quantity_cast(const QuantityFrom& q)
{
    static_assert(traits::is_quantity_of_v<QuantityTo, typename QuantityFrom::dimension>, "Quantities do not have the same dimension!");

    using to_dimension      = traits::dimension_t<QuantityTo>;
    using to_unit           = traits::unit_t<QuantityTo>;
    using to_representation = traits::representation_t<QuantityTo>;

    using result_transformation = detail::total_transformation_t<QuantityTo, QuantityFrom>;

    using result_representation = to_representation;
    using result_type           = quantity<to_dimension, to_unit, result_representation>;

    const auto result_value = static_cast<result_representation>(result_transformation::apply(q.count()));

    return result_type(result_value);
}

template<typename UnitTo, typename Quantity, typename std::enable_if_t<traits::is_quantity_v<Quantity> && traits::is_unit_v<UnitTo>>* = nullptr>
constexpr auto quantity_cast(const Quantity& q)
{
    using dimension = traits::dimension_t<Quantity>;
    using unit_from = traits::unit_t<Quantity>;

    static_assert(traits::is_unit_of_v<traits::base_reference_unit_t<UnitTo>, dimension>, "Given unit is not a unit for the dimension of the given quantity!");

    using representation = traits::representation_t<Quantity>;

    using total_transformation = detail::total_transformation_t<UnitTo, unit_from>;

    using result_representation = std::common_type_t<representation, std::conditional_t<total_transformation::is_integral(), std::int64_t, long double>>;

    using result_type = quantity<dimension, UnitTo, result_representation>;

    return quantity_cast<result_type>(q);
}

template<typename NewBaseUnit, typename Quantity, typename std::enable_if_t<traits::is_quantity_v<Quantity>>* = nullptr>
constexpr auto replace_base_unit(const Quantity& q)
{
    using unit = traits::unit_t<Quantity>;

    using result_unit = traits::replace_base_unit_t<unit, NewBaseUnit>;

    return quantity_cast<result_unit>(q);
}

template<typename Quantity, typename std::enable_if_t<traits::is_quantity_v<Quantity>>* = nullptr>
constexpr auto to_reference_unit(const Quantity& q)
{
    using unit           = traits::unit_t<Quantity>;
    using reference_unit = traits::reference_unit_t<unit>;

    return quantity_cast<reference_unit>(q);
}

template<typename Quantity, typename std::enable_if_t<traits::is_quantity_v<Quantity>>* = nullptr>
constexpr auto to_base_reference_unit(const Quantity& q)
{
    using unit                = traits::unit_t<Quantity>;
    using base_reference_unit = traits::base_reference_unit_t<unit>;

    return quantity_cast<base_reference_unit>(q);
}

#ifdef XYFUND_HAVE_PYBIND11
namespace detail {

template<typename QuantityFromType, typename QuantityToType>
using quantity_cast_function_type = QuantityToType (*)(const QuantityFromType&);

template<typename QuantityFromType, typename QuantityToType>
inline void export_quantity_cast_to_python(pybind11::module& mod)
{
    namespace py = pybind11;

    mod.def("quantity_cast", [](const QuantityFromType& q) { return quantity_cast<QuantityToType>(q); });
}

} // namespace detail
#endif // XYFUND_HAVE_PYBIND11

} // namespace units
} // namespace xyfund

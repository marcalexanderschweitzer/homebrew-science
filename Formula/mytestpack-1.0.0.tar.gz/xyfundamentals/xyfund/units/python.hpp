//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <xyfund/units/si/angle.hpp>

#pragma once

namespace xyfund {
namespace detail {

inline void export_units_to_python(pybind11::module& mod)
{
    auto mod_units = mod.def_submodule("units");

    xyfund::units::detail::export_supported_si_angle_to_python(mod_units);
}

} // namespace detail

} // namespace xyfund

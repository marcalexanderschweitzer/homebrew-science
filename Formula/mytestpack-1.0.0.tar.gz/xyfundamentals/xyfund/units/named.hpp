//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

namespace xyfund {
namespace units {

template<typename Base>
struct named
{
    static constexpr bool is_named = true;

    constexpr static auto symbol() { return Base::symbol_value; }
};

} // namespace units
} // namespace xyfund

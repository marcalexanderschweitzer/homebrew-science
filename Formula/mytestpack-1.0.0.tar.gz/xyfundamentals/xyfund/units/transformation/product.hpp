//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <cmath>

#include <xyfund/math/pow.hpp>
#include <xyfund/meta.hpp>
#include <xyfund/units/tags.hpp>
#include <xyfund/units/traits.hpp>
#include <xyfund/units/transformation/ratio.hpp>

#pragma once

namespace xyfund {
namespace units {
namespace transformation {

template<typename... Transformations>
struct product;

namespace detail
{

template<typename... Transformations>
constexpr auto make_product(std::tuple<Transformations...>/*unused*/)
{
    return product<Transformations...>();
}

template<typename... Transformations>
constexpr auto make_reverse_product()
{
    return make_product(xyfund::mp::reverse_t<std::tuple<Transformations...>>());
}

template<typename V, typename Transformation, typename... Transformations>
constexpr auto apply_transformations(const V& v, Transformation /*unused*/, Transformations... ts)
{
    if constexpr(!sizeof...(Transformations))
    {
        return Transformation::apply(v);
    }
    else {
        return apply_transformations(Transformation::apply(v), ts...);
    }
}

} // namespace detail

template<typename... Transformations>
struct product
{
    template<typename V>
    static constexpr auto apply(const V& value) {
        return detail::apply_transformations(value, Transformations()...);
    }

    static constexpr auto inverse() { return detail::make_reverse_product<decltype(Transformations::inverse())...>(); }

    static constexpr auto get() { return product(); }

    static constexpr bool is_integral() { return (Transformations::is_integral() && ...); }

    template<typename... OtherTransformations>
    friend constexpr auto operator*(const product& /*unused*/, const product<OtherTransformations...>& /*unused*/)
    {
        return product<Transformations..., OtherTransformations...>();
    }

    friend std::ostream& operator<<(std::ostream& os, const product& /*unused*/)
    {
        return ((os << Transformations() << " | "), ...);
    }
};

} // namespace transformation

namespace traits {

template<typename... Transformations>
struct type_tag<transformation::product<Transformations...>>
{
    using type = tags::product;
};

} // namespace traits

} // namespace units
} // namespace xyfund

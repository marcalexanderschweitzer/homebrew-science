//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <numeric>

#include <xyfund/units/tags.hpp>
#include <xyfund/units/transformation/ratio.hpp>

#pragma once

namespace xyfund {
namespace units {
namespace transformation {

template<typename Factor, typename Offset>
struct affine
{
    using factor = Factor;
    using offset = Offset;

    template<typename OtherAffineType>
    friend constexpr auto operator*(const affine& /*unused*/, const OtherAffineType& /*unused*/)
    {
        constexpr auto new_factor = factor() * traits::factor_t<OtherAffineType>();
        constexpr auto new_offset = traits::factor_t<OtherAffineType>() * offset() + traits::offset_t<OtherAffineType>();

        return affine<decltype(new_factor), decltype(new_offset)>();
    }

    template<std::intmax_t N, std::intmax_t D, std::intmax_t E10, std::intmax_t EPi>
    friend constexpr auto operator*(const affine& /*unused*/, const ratio<N, D, E10, EPi>& /*unused*/)
    {
        using ratio_t = ratio<N, D, E10, EPi>;

        constexpr auto new_factor = factor() * ratio_t::get();
        constexpr auto new_offset = offset() * ratio_t::get();

        return affine<decltype(new_factor), decltype(new_offset)>();
    }

    template<std::intmax_t N, std::intmax_t D, std::intmax_t E10, std::intmax_t EPi>
    friend constexpr auto operator*(const ratio<N, D, E10, EPi>& r, const affine& a)
    {
        return a * r;
    }

    static constexpr auto inverse()
    {
        using factor_inverse        = decltype(factor::inverse());
        using factor_inverse_offset = decltype(decltype(factor::inverse() * offset::get())::negative());

        return affine<factor_inverse, factor_inverse_offset>();
    }

    template<typename V>
    static constexpr auto apply(const V& value)
    {
        return factor::apply(value) + offset::apply(V{1});
    }

    static constexpr auto get() { return affine(); }

    static constexpr bool is_integral()
    {
        return factor::is_integral() && offset::is_integral();
    }

    friend std::ostream& operator<<(std::ostream& os, const affine& /*unused*/)
    {
        return os << factor() << " * x + " << offset();
    }
};

} // namespace transformation

namespace traits {

template<typename Factor, typename Offset>
struct type_tag<transformation::affine<Factor, Offset>>
{
    using type = tags::affine;
};

} // namespace traits

} // namespace units
} // namespace xyfund

//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <cmath>

#include <xyfund/math/pow.hpp>
#include <xyfund/units/tags.hpp>
#include <xyfund/units/traits.hpp>
#include <xyfund/units/transformation/ratio.hpp>

#pragma once

namespace xyfund {
namespace units {
namespace transformation {

namespace detail
{

template<std::intmax_t N, typename Transformation, typename V>
constexpr auto apply_transformation_n_times(const Transformation& t, const V& v)
{
    static_assert(N >= 0);

    if constexpr(N == 0)
    {
        return v;
    }
    else
    {
        return Transformation::apply(apply_transformation_n_times<N - 1>(t, v));
    }
}

} // namespace detail

template<typename Transformation, std::intmax_t Power>
struct power
{
    static_assert(Power != 0, "Transformation power must be nonzero!");

    using transformation = Transformation;
    static constexpr auto n          = Power; 

    template<typename V>
    static constexpr auto apply(const V& value) { 
        if constexpr(n >= 0)
        {
            return detail::apply_transformation_n_times<n>(transformation(), value); 
        }
        else
        {
            return detail::apply_transformation_n_times<-n>(transformation::inverse(), value); 
        }
    }

    static constexpr auto inverse() { return power<transformation, -n>(); }

    static constexpr auto get() { return power(); }

    static constexpr bool is_integral() { return transformation::is_integral(); }

    friend std::ostream& operator<<(std::ostream& os, const power& /*unused*/)
    {
        return os << "(" << transformation() << ")^" << std::to_string(Power);
    }
};

} // namespace transformation

namespace traits {

template<typename Transformation, std::intmax_t Power>
struct type_tag<transformation::power<Transformation, Power>>
{
    using type = tags::power;
};

} // namespace traits

} // namespace units
} // namespace xyfund

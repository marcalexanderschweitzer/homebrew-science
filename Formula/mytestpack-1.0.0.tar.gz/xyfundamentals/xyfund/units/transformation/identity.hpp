//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <cmath>

#include <xyfund/units/tags.hpp>
#include <xyfund/units/traits.hpp>

#pragma once

namespace xyfund {
namespace units {
namespace transformation {

struct identity
{
    template<typename V>
    static constexpr auto apply(const V& value) { return value; }

    static constexpr auto inverse() { return identity(); }

    static constexpr auto get() { return identity(); }

    static constexpr bool is_integral() { return true; }

    friend std::ostream& operator<<(std::ostream& os, const identity& /*unused*/)
    {
        return os << "id";
    }
};

} // namespace transformation

namespace traits {

template<>
struct type_tag<transformation::identity>
{
    using type = tags::identity;
};

} // namespace traits
} // namespace units
} // namespace xyfund

//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <xyfund/units/tags.hpp>
#include <xyfund/units/traits.hpp>

#include <xyfund/units/transformation/product.hpp>

#pragma once

namespace xyfund {
namespace units {
namespace transformation {

//===========================================================================================================
namespace detail {

template<typename FirstTransformation, typename FirstTransformationTag, typename SecondTransformation, typename SecondTransformationTag>
auto make_chain_impl(FirstTransformation&& /*unused*/, FirstTransformationTag /*unused*/, SecondTransformation&& /*unused*/, SecondTransformationTag /*unused*/)
{
    return product<FirstTransformation, SecondTransformation>();
}

template<typename FirstTransformation, typename SecondTransformation>
auto make_chain_impl(FirstTransformation&& first, tags::ratio /*unused*/, SecondTransformation&& second, tags::affine /*unused*/)
{
    return first * second;
}

template<typename FirstTransformation, typename SecondTransformation>
auto make_chain_impl(FirstTransformation&& first, tags::affine first_tag, SecondTransformation&& second, tags::ratio second_tag)
{
    return make_chain_impl(second, second_tag, first, first_tag);
}

template<typename FirstTransformation, typename SecondTransformation>
auto make_chain_impl(FirstTransformation&& first, tags::affine /*unused*/, SecondTransformation&& second, tags::affine /*unused*/)
{
    return first * second;
}

template<typename FirstTransformation, typename SecondTransformation>
auto make_chain_impl(FirstTransformation&& first, tags::ratio /*unused*/, SecondTransformation&& second, tags::ratio /*unused*/)
{
    return first * second;
}

//===========================================================================================================
// Product with identity
template<typename FirstTransformation, typename FirstTransformationTag, typename SecondTransformation>
auto make_chain_impl(FirstTransformation&& first, FirstTransformationTag /*unused*/, SecondTransformation&& /*unused*/, tags::identity /*unused*/)
{
    return first;
}

template<typename FirstTransformation, typename SecondTransformation, typename SecondTransformationTag>
auto make_chain_impl(FirstTransformation&& first, tags::identity /*unused*/, SecondTransformation&& second, SecondTransformationTag second_transformation_tag)
{
    return make_chain_impl(second, second_transformation_tag, first, tags::identity());
}

template<typename FirstTransformation, typename SecondTransformation>
auto make_chain_impl(FirstTransformation&& first, tags::identity /*unused*/, SecondTransformation&& /*unused*/, tags::identity /*unused*/)
{
    return first;
}

} // namespace detail

//===========================================================================================================
template<typename FirstTransformation, typename SecondTransformation>
auto make_chain(FirstTransformation&& first_transformation, SecondTransformation&& second_transformation)
{
    return detail::make_chain_impl(std::forward<FirstTransformation>(first_transformation), traits::type_tag_t<FirstTransformation>(), std::forward<SecondTransformation>(second_transformation), traits::type_tag_t<SecondTransformation>());
}

template<typename T1, typename T2>
using chain_result_t = decltype(make_chain(std::declval<T1>(), std::declval<T2>()));

} // namespace transformation
} // namespace units
} // namespace xyfund

//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <numeric>

#include <xyfund/units/tags.hpp>

#include <xyfund/math/pow.hpp>
#include <xyfund/math/power_of_10.hpp>
#include <xyfund/numbers.hpp>

#pragma once

namespace xyfund {
namespace units {
namespace transformation {

template<std::intmax_t N, std::intmax_t D = 1, std::intmax_t E10 = 0, std::intmax_t EPi = 0>
struct ratio
{
    static constexpr auto numerator   = N;
    static constexpr auto denominator = D;
    static constexpr auto exponent_10 = E10;
    static constexpr auto exponent_pi = EPi;

    static_assert(denominator > 0, "The denominator must be greater than 0");

    template<std::intmax_t N2, std::intmax_t D2, std::intmax_t E102, std::intmax_t EPi2>
    friend constexpr auto operator*(const ratio& /*unused*/, const ratio<N2, D2, E102, EPi2>& /*unused*/)
    {
        using other_ratio_type = ratio<N2, D2, E102, EPi2>;

        constexpr auto gcd1 = std::gcd(ratio::numerator, other_ratio_type::denominator);
        constexpr auto gcd2 = std::gcd(ratio::denominator, other_ratio_type::numerator);

        constexpr auto new_numerator = (ratio::numerator / gcd1) * (other_ratio_type::numerator / gcd2);

        constexpr auto new_denominator = new_numerator == 0 ? 1 : (ratio::denominator / gcd2) * (other_ratio_type::denominator / gcd1);

        return ratio<new_numerator, new_denominator, ratio::exponent_10 + other_ratio_type::exponent_10, ratio::exponent_pi + other_ratio_type::exponent_pi>();
    }

    template<typename OtherRatioType>
    friend constexpr auto operator+(const ratio& /*unused*/, const OtherRatioType& /*unused*/)
    {
        static_assert(ratio::exponent_10 == OtherRatioType::exponent_10 && ratio::exponent_pi == OtherRatioType::exponent_pi, "Adding currently requires all exponents to be equal!");

        constexpr auto lcm = std::lcm(ratio::denominator, OtherRatioType::denominator);

        constexpr auto numerator1 = ratio::numerator * (lcm / ratio::denominator);
        constexpr auto numerator2 = OtherRatioType::numerator * (lcm / OtherRatioType::denominator);

        constexpr auto sum = numerator1 + numerator2;

        constexpr auto gcd = std::gcd(sum, lcm);

        constexpr auto new_numerator = sum == 0 ? 0 : sum / gcd;

        constexpr auto new_denominator = new_numerator == 0 ? 1 : lcm / gcd;

        return ratio<new_numerator, new_denominator, 0, 0>();
    }

    static constexpr auto inverse()
    {
        constexpr auto new_numerator   = numerator > 0 ? denominator : -denominator;
        constexpr auto new_denominator = numerator > 0 ? numerator : -numerator;

        return ratio<new_numerator, new_denominator, -exponent_10, -exponent_pi>();
    }

    static constexpr auto negative()
    {
        return ratio<-numerator, denominator, exponent_10, exponent_pi>();
    }

    template<typename V>
    static constexpr auto apply(const V& value)
    {
        using ratio_result_type = std::conditional_t<is_integral(), std::int64_t, long double>;
        using result_type       = std::common_type_t<ratio_result_type, V>;

        auto result = static_cast<result_type>(value * numerator);

        result /= denominator;

        if constexpr(exponent_10 != 0) //NOLINT(readability-misleading-indentation)
        {
            result *= xyfund::math::pow<result_type>(10, exponent_10);
        }

        if constexpr(exponent_pi != 0) //NOLINT(readability-misleading-indentation)
        {
            result *= xyfund::math::pow<result_type>(xyfund::numbers::pi_v<double>, exponent_pi);
        }

        return result; //NOLINT(readability-misleading-indentation)
    }

    static constexpr auto get() { return ratio(); }

    static constexpr bool is_integral()
    {
        if constexpr(exponent_pi != 0 || exponent_10 < 0)
        {
            return false;
        }
        else
        {
            return numerator * xyfund::power_of_10<std::intmax_t>(exponent_10) % denominator == 0;
        }
    }

    friend std::ostream& operator<<(std::ostream& os, const ratio& /*unused*/)
    {
        return os << ratio::numerator << " / " << ratio::denominator << " * 10^" << ratio::exponent_10 << " * pi^" << ratio::exponent_pi;
    }
};

template<typename Ratio1, typename Ratio2>
using ratio_multiplication_result_t = decltype(std::declval<Ratio1>() * std::declval<Ratio2>());

} // namespace transformation

namespace traits {

template<std::intmax_t N, std::intmax_t D, std::intmax_t E10, std::intmax_t EPi>
struct type_tag<transformation::ratio<N, D, E10, EPi>>
{
    using type = tags::ratio;
};

} // namespace traits

} // namespace units
} // namespace xyfund

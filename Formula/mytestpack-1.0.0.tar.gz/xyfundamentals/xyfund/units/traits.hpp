//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <xyfund/traits.hpp>

#pragma once

namespace xyfund {
namespace units {

namespace transformation {

struct identity;

}

namespace traits {

//===========================================================================================================
// type extraction

template<typename T>
using dimension_t = typename T::dimension;

template<typename T>
using unit_t = typename T::unit;

template<typename T>
using reference_unit_t = typename T::reference_unit;

template<typename T>
using transformation_t = typename T::transformation;

template<typename T>
using representation_t = typename T::representation;

template<typename T>
using factor_t = typename T::factor;

template<typename T>
using offset_t = typename T::offset;

template<typename T>
constexpr auto symbol(const T& /*unused*/)
{
    return T::symbol();
}

//===========================================================================================================
// dimension
template<typename T>
struct is_dimension : std::false_type
{};

template<typename T>
struct is_dimension<const T> : is_dimension<T>
{};

template<typename T>
struct is_dimension<T&> : is_dimension<T>
{};

template<typename T>
struct is_dimension<const T&> : is_dimension<T>
{};

template<typename T>
inline constexpr bool is_dimension_v = is_dimension<T>::value;

//===========================================================================================================
// quantity
template<typename T>
struct is_quantity : std::false_type
{};

template<typename T>
struct is_quantity<const T> : is_quantity<T>
{};

template<typename T>
struct is_quantity<T&> : is_quantity<T>
{};

template<typename T>
struct is_quantity<const T&> : is_quantity<T>
{};

template<typename T>
inline constexpr bool is_quantity_v = is_quantity<T>::value;

//===========================================================================================================
// transformation tag
template<typename T>
struct type_tag
{};

template<typename T>
struct type_tag<const T> : type_tag<T>
{};

template<typename T>
struct type_tag<T&> : type_tag<T>
{};

template<typename T>
struct type_tag<const T&> : type_tag<T>
{};

template<typename T>
using type_tag_t = typename type_tag<T>::type;

//===========================================================================================================
template<typename From, typename To>
inline constexpr bool is_safe_convertible_v = std::is_convertible<From, To>::value && (std::is_floating_point<To>::value || !std::is_floating_point<From>::value);

//===========================================================================================================
template<typename ResultRepresentation, typename Transformation>
inline constexpr bool is_safe_transformable_v = std::is_floating_point<ResultRepresentation>::value || Transformation::is_integral();

//===========================================================================================================
template<typename ScalarFrom, typename ScalarTo>
inline constexpr bool is_safe_scalar_transformable_v = std::is_arithmetic<ScalarFrom>::value && traits::is_safe_convertible_v<ScalarFrom, ScalarTo>;

//===========================================================================================================
template<typename QuantityFrom, typename QuantityTo, typename Transformation>
inline constexpr bool is_safe_quantity_transformable_v = traits::is_quantity_v<QuantityFrom>&& traits::is_safe_convertible_v<traits::representation_t<QuantityFrom>, traits::representation_t<QuantityTo>>&& traits::is_safe_transformable_v<traits::representation_t<QuantityTo>, Transformation>;

//===========================================================================================================
// unit
template<typename T>
struct is_unit : std::false_type
{};

template<typename T>
struct is_unit<const T> : is_unit<T>
{};

template<typename T>
struct is_unit<T&> : is_unit<T>
{};

template<typename T>
struct is_unit<const T&> : is_unit<T>
{};

template<typename T>
inline constexpr bool is_unit_v = is_unit<T>::value;

//===========================================================================================================
template<typename Unit1, typename Unit2>
struct is_same_unit : public std::is_same<Unit1, Unit2>
{};

template<typename Unit1, typename Unit2>
inline constexpr bool is_same_unit_v = is_same_unit<Unit1, Unit2>::value;

//===========================================================================================================
template<typename Unit1, typename Unit2>
struct is_same_reference_unit : public is_same_unit<reference_unit_t<Unit1>, reference_unit_t<Unit2>>
{};

template<typename Unit1, typename Unit2>
inline constexpr bool is_same_reference_unit_v = is_same_reference_unit<Unit1, Unit2>::value;

//===========================================================================================================
template<typename Unit>
inline constexpr bool is_base_reference_unit_v = std::is_same_v<reference_unit_t<Unit>, Unit>;

//===========================================================================================================
namespace detail {

template<typename Unit, bool>
struct base_reference_unit
{
    using type = typename base_reference_unit<typename Unit::reference_unit, is_base_reference_unit_v<typename Unit::reference_unit>>::type;
};

template<typename Unit>
struct base_reference_unit<Unit, true>
{
    using type = Unit;
};

} // namespace detail

template<typename Unit>
using base_reference_unit_t = typename detail::base_reference_unit<Unit, is_base_reference_unit_v<Unit>>::type;

//===========================================================================================================
template<typename Unit1, typename Unit2>
struct is_same_base_reference_unit : public is_same_unit<base_reference_unit_t<Unit1>, base_reference_unit_t<Unit2>>
{};

template<typename Unit1, typename Unit2>
inline constexpr bool is_same_base_reference_unit_v = is_same_base_reference_unit<Unit1, Unit2>::value;

//===========================================================================================================
template<typename Unit, typename Dimension>
using is_unit_of = std::is_same<traits::base_reference_unit_t<Unit>, traits::unit_t<Dimension>>;

template<typename Unit, typename Dimension>
inline constexpr bool is_unit_of_v = is_unit_of<Unit, Dimension>::value;

//===========================================================================================================
template<typename Unit, typename NewBaseUnit>
struct replace_base_unit
{
    using type = std::conditional_t<is_same_base_reference_unit_v<Unit, NewBaseUnit>, NewBaseUnit, Unit>;
};

template<typename Unit, typename NewBaseUnit>
using replace_base_unit_t = typename replace_base_unit<Unit, NewBaseUnit>::type;

//===========================================================================================================
namespace detail {
template<typename Dimension1, typename Dimension2>
using is_equivalent_dim = xyfund::conjunction<is_dimension<Dimension1>, is_dimension<Dimension2>, std::integral_constant<bool, Dimension1::symbol() == Dimension2::symbol()>, is_same_unit<unit_t<Dimension1>, unit_t<Dimension2>>>;
}

template<typename Dimension1, typename Dimension2>
using is_equivalent_dim = detail::is_equivalent_dim<Dimension1, Dimension2>;

template<typename Dimension1, typename Dimension2>
inline constexpr bool is_equivalent_dim_v = is_equivalent_dim<Dimension1, Dimension2>::value;

//===========================================================================================================
template<typename Quantity, typename Dimension>
inline constexpr bool is_quantity_of_v = traits::is_unit_of_v<traits::unit_t<Quantity>, Dimension> && traits::is_equivalent_dim_v<traits::dimension_t<Quantity>, Dimension>;

//===========================================================================================================
namespace detail {

template<template<typename...> class Base>
struct is_derived_from_impl
{
    template<typename... Ts>
    static constexpr std::true_type  check_base(const Base<Ts...>&);
    static constexpr std::false_type check_base(...);
};

} // namespace detail

template<typename Derived, template<typename...> class Base>
inline constexpr bool is_derived_from_v = decltype(detail::is_derived_from_impl<Base>::check_base(std::declval<Derived>()))::value;

namespace detail {

template<template<typename...> class Template, typename T>
struct is_instance_of : std::false_type
{};

template<template<typename...> class Template, typename... Ts>
struct is_instance_of<Template, Template<Ts...> > : std::true_type
{};

} // namespace detail

} // namespace traits
} // namespace units
} // namespace xyfund

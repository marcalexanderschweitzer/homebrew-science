//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <xyfund/fixed_string.hpp>
#include <xyfund/units/prefix.hpp>
#include <xyfund/units/transformation/ratio.hpp>

#pragma once

namespace xyfund {
namespace units {
namespace si {
namespace prefix {

struct kilo : named<kilo>, xyfund::units::prefix<transformation::ratio<1, 1, 3>>
{
    static constexpr fixed_string<char, 1> symbol_value = "k"; 
};

struct deci : named<deci>, xyfund::units::prefix<transformation::ratio<1, 1, -1>>
{
    static constexpr fixed_string<char, 1> symbol_value = "d"; 
};

struct centi : named<centi>, xyfund::units::prefix<transformation::ratio<1, 1, -2>>
{
    static constexpr fixed_string<char, 1> symbol_value = "c"; 
};

struct milli : named<milli>, xyfund::units::prefix<transformation::ratio<1, 1, -3>>
{
    static constexpr fixed_string<char, 1> symbol_value = "m"; 
};

struct micro : named<micro>, xyfund::units::prefix<transformation::ratio<1, 1, -6>>
{
    static constexpr fixed_string<char, 1> symbol_value = "u"; 
};

struct nano : named<nano>, xyfund::units::prefix<transformation::ratio<1, 1, -9>>
{
    static constexpr fixed_string<char, 1> symbol_value = "n"; 
};

} // namespace prefix
} // namespace si
} // namespace units
} // namespace xyfund
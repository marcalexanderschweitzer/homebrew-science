//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <xyfund/fixed_string.hpp>
#include <xyfund/units/base_dimension.hpp>
#include <xyfund/units/quantity.hpp>
#include <xyfund/units/si/prefix.hpp>
#include <xyfund/units/unit.hpp>

namespace xyfund {
namespace units {
namespace si {
namespace symbol {

struct meter : named<meter>
{
    static constexpr fixed_string<char, 1> symbol_value = "m"; 
};

} // namespace symbol

using meter = named_unit<symbol::meter>;

using kilometer  = prefixed_unit<prefix::kilo, meter>;
using decimeter  = prefixed_unit<prefix::deci, meter>;
using centimeter = prefixed_unit<prefix::centi, meter>;
using millimeter = prefixed_unit<prefix::milli, meter>;
using micrometer = prefixed_unit<prefix::micro, meter>;
using nanometer  = prefixed_unit<prefix::nano, meter>;

using dim_length = base_dim_length<meter>;

template<typename Unit, typename Representation = double>
using length = quantity<dim_length, Unit, Representation>;

inline namespace literals {
constexpr auto operator"" _km(unsigned long long l)
{
    return length<kilometer, std::int64_t>(l);
}
constexpr auto operator"" _km(long double l)
{
    return length<kilometer, long double>(l);
}

constexpr auto operator"" _m(unsigned long long l)
{
    return length<meter, std::int64_t>(l);
}
constexpr auto operator"" _m(long double l)
{
    return length<meter, long double>(l);
}

constexpr auto operator"" _dm(unsigned long long l)
{
    return length<decimeter, std::int64_t>(l);
}
constexpr auto operator"" _dm(long double l)
{
    return length<decimeter, long double>(l);
}

constexpr auto operator"" _cm(unsigned long long l)
{
    return length<centimeter, std::int64_t>(l);
}
constexpr auto operator"" _cm(long double l)
{
    return length<centimeter, long double>(l);
}

constexpr auto operator"" _mm(unsigned long long l)
{
    return length<millimeter, std::int64_t>(l);
}
constexpr auto operator"" _mm(long double l)
{
    return length<millimeter, long double>(l);
}

constexpr auto operator"" _um(unsigned long long l)
{
    return length<micrometer, std::int64_t>(l);
}
constexpr auto operator"" _um(long double l)
{
    return length<micrometer, long double>(l);
}

constexpr auto operator"" _nm(unsigned long long l)
{
    return length<nanometer, std::int64_t>(l);
}
constexpr auto operator"" _nm(long double l)
{
    return length<nanometer, long double>(l);
}
} // namespace literals

} // namespace si
} // namespace units
} // namespace xyfund
//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <cmath>

#include <xyfund/fixed_string.hpp>
#include <xyfund/units/base_dimension.hpp>
#include <xyfund/units/quantity.hpp>
#include <xyfund/units/quantity_cast.hpp>
#include <xyfund/units/si/prefix.hpp>
#include <xyfund/units/unit.hpp>

#include <xyfund/numbers.hpp>

namespace xyfund {
namespace units {
namespace si {
namespace symbol {

struct radian : named<radian>
{
    static constexpr fixed_string<char, 3> symbol_value = "rad"; 
};

struct degree : named<degree>
{
    static constexpr fixed_string<char, 3> symbol_value = "deg"; 
};

} // namespace symbol

using radian = named_unit<symbol::radian>;

using degree = named_scaled_unit<symbol::degree, transformation::ratio<1, 180, 0, 1>, radian>;

using dim_angle = base_dim_angle<radian>;

template<typename Unit, typename Representation = double>
using angle = quantity<dim_angle, Unit, Representation>;

template<typename Representation = double>
using radian_angle = angle<radian, Representation>;

template<typename Representation = double>
using degree_angle = angle<degree, Representation>;

inline namespace literals {
constexpr auto operator"" _rad(unsigned long long l)
{
    return angle<radian, std::int64_t>(l);
}
constexpr auto operator"" _rad(long double l)
{
    return angle<radian, long double>(l);
}

constexpr auto operator"" _deg(unsigned long long l)
{
    return angle<degree, std::int64_t>(l);
}
constexpr auto operator"" _deg(long double l)
{
    return angle<degree, long double>(l);
}
} // namespace literals
} // namespace si

#ifdef XYFUND_HAVE_PYBIND11
namespace detail {
inline void export_supported_si_angle_to_python(pybind11::module& mod)
{
    export_class_to_python<xyfund::units::si::radian_angle<double>>(mod, "RadianDouble", "Radian");
    export_class_to_python<xyfund::units::si::degree_angle<double>>(mod, "DegreeDouble", "Degree");

    xyfund::units::detail::export_quantity_cast_to_python<xyfund::units::si::radian_angle<double>, xyfund::units::si::degree_angle<double>>(mod);
    xyfund::units::detail::export_quantity_cast_to_python<xyfund::units::si::degree_angle<double>, xyfund::units::si::radian_angle<double>>(mod);
}
} // namespace detail

#endif

} // namespace units

} // namespace xyfund
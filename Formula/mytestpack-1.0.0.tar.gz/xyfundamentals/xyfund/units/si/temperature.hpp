//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <cmath>

#include <xyfund/fixed_string.hpp>
#include <xyfund/units/base_dimension.hpp>
#include <xyfund/units/quantity.hpp>
#include <xyfund/units/quantity_cast.hpp>
#include <xyfund/units/si/prefix.hpp>
#include <xyfund/units/unit.hpp>

#include <xyfund/numbers.hpp>

namespace xyfund {
namespace units {
namespace si {
namespace symbol {

struct kelvin : named<kelvin>
{
    static constexpr fixed_string<char, 1> symbol_value = "K"; 
};

struct celsius : named<celsius>
{
    static constexpr fixed_string<char, 1> symbol_value = "C"; 
};

struct fahrenheit : named<fahrenheit>
{
    static constexpr fixed_string<char, 1> symbol_value = "F"; 
};

} // namespace symbol

using kelvin = named_unit<symbol::kelvin>;

using celsius = named_scaled_unit<symbol::celsius, transformation::affine<transformation::ratio<1, 1>, transformation::ratio<27315, 100>>, kelvin>;

using fahrenheit = named_scaled_unit<symbol::fahrenheit, transformation::affine<transformation::ratio<5, 9>, transformation::ratio<45967, 180>>, kelvin>;

using dim_temperature = base_dim_temperature<kelvin>;

template<typename Unit, typename Representation = double>
using temperature = quantity<dim_temperature, Unit, Representation>;

inline namespace literals {
constexpr auto operator"" _K(unsigned long long l)
{
    return temperature<kelvin, std::int64_t>(l);
}
constexpr auto operator"" _K(long double l)
{
    return temperature<kelvin, long double>(l);
}

constexpr auto operator"" _C(unsigned long long l)
{
    return temperature<celsius, std::int64_t>(l);
}
constexpr auto operator"" _C(long double l)
{
    return temperature<celsius, long double>(l);
}

constexpr auto operator"" _F(unsigned long long l)
{
    return temperature<fahrenheit, std::int64_t>(l);
}
constexpr auto operator"" _F(long double l)
{
    return temperature<fahrenheit, long double>(l);
}

} // namespace literals
} // namespace si
} // namespace units
} // namespace xyfund
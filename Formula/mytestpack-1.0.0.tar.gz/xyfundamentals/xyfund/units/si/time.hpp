//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <xyfund/fixed_string.hpp>
#include <xyfund/units/base_dimension.hpp>
#include <xyfund/units/quantity.hpp>
#include <xyfund/units/si/prefix.hpp>
#include <xyfund/units/unit.hpp>

namespace xyfund {
namespace units {
namespace si {
namespace symbol {

struct second : named<second>
{
    static constexpr fixed_string<char, 1> symbol_value = "s"; 
};

struct minute : named<minute>
{
    static constexpr fixed_string<char, 3> symbol_value = "min"; 
};

struct hour : named<hour>
{
    static constexpr fixed_string<char, 1> symbol_value = "h"; 
};

struct day : named<day>
{
    static constexpr fixed_string<char, 1> symbol_value = "d"; 
};

} // namespace symbol

using second      = named_unit<symbol::second>;
using millisecond = prefixed_unit<prefix::milli, second>;
using microsecond = prefixed_unit<prefix::micro, second>;
using nanosecond  = prefixed_unit<prefix::nano, second>;

using minute = named_scaled_unit<symbol::minute, transformation::ratio<60>, second>;
using hour   = named_scaled_unit<symbol::hour, transformation::ratio<60>, minute>;
using day    = named_scaled_unit<symbol::day, transformation::ratio<24>, hour>;

using dim_time = base_dim_time<second>;

template<typename Unit, typename Representation = double>
using time = quantity<dim_time, Unit, Representation>;

inline namespace literals {
constexpr auto operator"" _s(unsigned long long l)
{
    return time<second, std::int64_t>(l);
}
constexpr auto operator"" _s(long double l)
{
    return time<second, long double>(l);
}

constexpr auto operator"" _ms(unsigned long long l)
{
    return time<millisecond, std::int64_t>(l);
}
constexpr auto operator"" _ms(long double l)
{
    return time<millisecond, long double>(l);
}

constexpr auto operator"" _us(unsigned long long l)
{
    return time<microsecond, std::int64_t>(l);
}
constexpr auto operator"" _us(long double l)
{
    return time<microsecond, long double>(l);
}

constexpr auto operator"" _ns(unsigned long long l)
{
    return time<nanosecond, std::int64_t>(l);
}
constexpr auto operator"" _ns(long double l)
{
    return time<nanosecond, long double>(l);
}

constexpr auto operator"" _min(unsigned long long l)
{
    return time<minute, std::int64_t>(l);
}
constexpr auto operator"" _min(long double l)
{
    return time<minute, long double>(l);
}

constexpr auto operator"" _h(unsigned long long l)
{
    return time<hour, std::int64_t>(l);
}
constexpr auto operator"" _h(long double l)
{
    return time<hour, long double>(l);
}

constexpr auto operator"" _d(unsigned long long l)
{
    return time<day, std::int64_t>(l);
}
constexpr auto operator"" _d(long double l)
{
    return time<day, long double>(l);
}

} // namespace literals

} // namespace si
} // namespace units
} // namespace xyfund
//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <xyfund/fixed_string.hpp>
#include <xyfund/units/base_dimension.hpp>
#include <xyfund/units/quantity.hpp>
#include <xyfund/units/si/prefix.hpp>
#include <xyfund/units/unit.hpp>

namespace xyfund {
namespace units {
namespace si {
namespace symbol {

struct candela : named<candela>
{
    static constexpr fixed_string<char, 2> symbol_value = "cd"; 
};

} // namespace symbol

using candela = named_unit<symbol::candela>;

using kilocandela  = prefixed_unit<prefix::kilo, candela>;
using decicandela  = prefixed_unit<prefix::deci, candela>;
using centicandela = prefixed_unit<prefix::centi, candela>;
using millicandela = prefixed_unit<prefix::milli, candela>;
using microcandela = prefixed_unit<prefix::micro, candela>;
using nanocandela  = prefixed_unit<prefix::nano, candela>;

using dim_luminous_intensity = base_dim_luminous_intensity<candela>;

template<typename Unit, typename Representation = double>
using luminous_intensity = quantity<dim_luminous_intensity, Unit, Representation>;

inline namespace literals {

constexpr auto operator"" _kcd(unsigned long long l)
{
    return luminous_intensity<kilocandela, std::int64_t>(l);
}
constexpr auto operator"" _kcd(long double l)
{
    return luminous_intensity<kilocandela, long double>(l);
}

constexpr auto operator"" _cd(unsigned long long l)
{
    return luminous_intensity<candela, std::int64_t>(l);
}
constexpr auto operator"" _cd(long double l)
{
    return luminous_intensity<candela, long double>(l);
}

constexpr auto operator"" _dcd(unsigned long long l)
{
    return luminous_intensity<decicandela, std::int64_t>(l);
}
constexpr auto operator"" _dcd(long double l)
{
    return luminous_intensity<decicandela, long double>(l);
}

constexpr auto operator"" _ccd(unsigned long long l)
{
    return luminous_intensity<centicandela, std::int64_t>(l);
}
constexpr auto operator"" _ccd(long double l)
{
    return luminous_intensity<centicandela, long double>(l);
}

constexpr auto operator"" _mcd(unsigned long long l)
{
    return luminous_intensity<millicandela, std::int64_t>(l);
}
constexpr auto operator"" _mcd(long double l)
{
    return luminous_intensity<millicandela, long double>(l);
}

constexpr auto operator"" _ucd(unsigned long long l)
{
    return luminous_intensity<microcandela, std::int64_t>(l);
}
constexpr auto operator"" _ucd(long double l)
{
    return luminous_intensity<microcandela, long double>(l);
}

constexpr auto operator"" _ncd(unsigned long long l)
{
    return luminous_intensity<nanocandela, std::int64_t>(l);
}
constexpr auto operator"" _ncd(long double l)
{
    return luminous_intensity<nanocandela, long double>(l);
}

} // namespace literals

} // namespace si
} // namespace units
} // namespace xyfund
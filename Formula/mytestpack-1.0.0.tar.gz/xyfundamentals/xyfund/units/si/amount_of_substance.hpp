//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <xyfund/fixed_string.hpp>
#include <xyfund/units/base_dimension.hpp>
#include <xyfund/units/quantity.hpp>
#include <xyfund/units/si/prefix.hpp>
#include <xyfund/units/unit.hpp>

namespace xyfund {
namespace units {
namespace si {
namespace symbol {

struct mole : named<mole>
{
    static constexpr fixed_string<char, 3> symbol_value = "mol"; 
};

} // namespace symbol

using mole = named_unit<symbol::mole>;

using kilomole  = prefixed_unit<prefix::kilo, mole>;
using decimole  = prefixed_unit<prefix::deci, mole>;
using centimole = prefixed_unit<prefix::centi, mole>;
using millimole = prefixed_unit<prefix::milli, mole>;
using micromole = prefixed_unit<prefix::micro, mole>;
using nanomole  = prefixed_unit<prefix::nano, mole>;

using dim_amount_of_substance = base_dim_amount_of_substance<mole>;

template<typename Unit, typename Representation = double>
using amount_of_substance = quantity<dim_amount_of_substance, Unit, Representation>;

inline namespace literals {

constexpr auto operator"" _kmol(unsigned long long l)
{
    return amount_of_substance<kilomole, std::int64_t>(l);
}
constexpr auto operator"" _kmol(long double l)
{
    return amount_of_substance<kilomole, long double>(l);
}

constexpr auto operator"" _mol(unsigned long long l)
{
    return amount_of_substance<mole, std::int64_t>(l);
}
constexpr auto operator"" _mol(long double l)
{
    return amount_of_substance<mole, long double>(l);
}

constexpr auto operator"" _dmol(unsigned long long l)
{
    return amount_of_substance<decimole, std::int64_t>(l);
}
constexpr auto operator"" _dmol(long double l)
{
    return amount_of_substance<decimole, long double>(l);
}

constexpr auto operator"" _cmol(unsigned long long l)
{
    return amount_of_substance<centimole, std::int64_t>(l);
}
constexpr auto operator"" _cmol(long double l)
{
    return amount_of_substance<centimole, long double>(l);
}

constexpr auto operator"" _mmol(unsigned long long l)
{
    return amount_of_substance<millimole, std::int64_t>(l);
}
constexpr auto operator"" _mmol(long double l)
{
    return amount_of_substance<millimole, long double>(l);
}

constexpr auto operator"" _umol(unsigned long long l)
{
    return amount_of_substance<micromole, std::int64_t>(l);
}
constexpr auto operator"" _umol(long double l)
{
    return amount_of_substance<micromole, long double>(l);
}

constexpr auto operator"" _nmol(unsigned long long l)
{
    return amount_of_substance<nanomole, std::int64_t>(l);
}
constexpr auto operator"" _nmol(long double l)
{
    return amount_of_substance<nanomole, long double>(l);
}

} // namespace literals

} // namespace si
} // namespace units
} // namespace xyfund
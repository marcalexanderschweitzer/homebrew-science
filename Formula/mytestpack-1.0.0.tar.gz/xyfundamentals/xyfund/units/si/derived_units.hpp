//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <xyfund/units/si/time.hpp>

#ifdef pascal
#   define pascal_was_defined
#   pragma push_macro("pascal")
#   undef pascal
#endif // pascal

namespace xyfund {
namespace units {
namespace si {

//===========================================================================================================
namespace symbol {

struct herz : named<herz>
{
    static constexpr fixed_string<char, 2> symbol_value = "Hz"; 
};

} // namespace symbol

using herz      = named_scaled_unit<symbol::herz, transformation::identity, unit_power<second, -1>>;
using kiloherz  = prefixed_unit<prefix::kilo, herz>;

using dim_frequency = dimension_power<dim_time, -1>;

template<typename Unit, typename Representation = double>
using frequency = quantity<dim_frequency, Unit, Representation>;

inline namespace literals {

constexpr auto operator"" _kHz(unsigned long long l)
{
    return frequency<kiloherz, std::int64_t>(l);
}
constexpr auto operator"" _kHz(long double l)
{
    return frequency<kiloherz, long double>(l);
}

constexpr auto operator"" _Hz(unsigned long long l)
{
    return frequency<herz, std::int64_t>(l);
}
constexpr auto operator"" _Hz(long double l)
{
    return frequency<herz, long double>(l);
}

} // namespace literals

//===========================================================================================================
namespace symbol {

struct newton : named<newton>
{
    static constexpr fixed_string<char, 1> symbol_value = "N"; 
};

} // namespace symbol

using newton      = named_scaled_unit<symbol::newton, transformation::identity, unit_product<kilogram, meter, unit_power<second, -2>>>;
using kilonewton  = prefixed_unit<prefix::kilo, newton>;

using dim_force = dimension_product<dim_mass, dim_length, dimension_power<dim_time, -2>>;

template<typename Unit, typename Representation = double>
using force = quantity<dim_force, Unit, Representation>;

inline namespace literals {

constexpr auto operator"" _kN(unsigned long long l)
{
    return force<kilonewton, std::int64_t>(l);
}
constexpr auto operator"" _kN(long double l)
{
    return force<kilonewton, long double>(l);
}

constexpr auto operator"" _N(unsigned long long l)
{
    return force<newton, std::int64_t>(l);
}
constexpr auto operator"" _N(long double l)
{
    return force<newton, long double>(l);
}

} // namespace literals

//===========================================================================================================
namespace symbol {

struct pascal : named<pascal>
{
    static constexpr fixed_string<char, 2> symbol_value = "Pa"; 
};

} // namespace symbol

using pascal      = named_scaled_unit<symbol::pascal, transformation::identity, unit_product<kilogram, unit_power<meter, -1>, unit_power<second, -2>>>;
using kilopascal  = prefixed_unit<prefix::kilo, pascal>;

using dim_pressure = dimension_product<dim_mass, dimension_power<dim_length, -1>, dimension_power<dim_time, -2>>;

template<typename Unit, typename Representation = double>
using pressure = quantity<dim_pressure, Unit, Representation>;

inline namespace literals {

constexpr auto operator"" _kPa(unsigned long long l)
{
    return pressure<kilopascal, std::int64_t>(l);
}
constexpr auto operator"" _kPa(long double l)
{
    return pressure<kilopascal, long double>(l);
}

constexpr auto operator"" _Pa(unsigned long long l)
{
    return pressure<pascal, std::int64_t>(l);
}
constexpr auto operator"" _Pa(long double l)
{
    return pressure<pascal, long double>(l);
}

} // namespace literals

//===========================================================================================================
namespace symbol {

struct joule : named<joule>
{
    static constexpr fixed_string<char, 1> symbol_value = "J"; 
};

} // namespace symbol

using joule      = named_scaled_unit<symbol::joule, transformation::identity, unit_product<kilogram, unit_power<meter, 2>, unit_power<second, -2>>>;
using kilojoule  = prefixed_unit<prefix::kilo, joule>;

using dim_energy = dimension_product<dim_mass, dimension_power<dim_length, 2>, dimension_power<dim_time, -2>>;

template<typename Unit, typename Representation = double>
using energy = quantity<dim_energy, Unit, Representation>;

inline namespace literals {

constexpr auto operator"" _kJ(unsigned long long l)
{
    return energy<kilojoule, std::int64_t>(l);
}
constexpr auto operator"" _kJ(long double l)
{
    return energy<kilojoule, long double>(l);
}

constexpr auto operator"" _J(unsigned long long l)
{
    return energy<joule, std::int64_t>(l);
}
constexpr auto operator"" _J(long double l)
{
    return energy<joule, long double>(l);
}

} // namespace literals

//===========================================================================================================
namespace symbol {

struct watt : named<watt>
{
    static constexpr fixed_string<char, 1> symbol_value = "W"; 
};

} // namespace symbol

using watt      = named_scaled_unit<symbol::watt, transformation::identity, unit_product<kilogram, unit_power<meter, 2>, unit_power<second, -3>>>;
using kilowatt  = prefixed_unit<prefix::kilo, watt>;

using dim_power = dimension_product<dim_mass, dimension_power<dim_length, 2>, dimension_power<dim_time, -3>>;

template<typename Unit, typename Representation = double>
using power = quantity<dim_power, Unit, Representation>;

inline namespace literals {

constexpr auto operator"" _kW(unsigned long long l)
{
    return power<kilowatt, std::int64_t>(l);
}
constexpr auto operator"" _kW(long double l)
{
    return power<kilowatt, long double>(l);
}

constexpr auto operator"" _W(unsigned long long l)
{
    return power<watt, std::int64_t>(l);
}
constexpr auto operator"" _W(long double l)
{
    return power<watt, long double>(l);
}

} // namespace literals

} // namespace si
} // namespace units
} // namespace xyfund

#ifdef pascal_was_defined 
#   pragma pop_macro("pascal")
#endif // pascal_was_defined
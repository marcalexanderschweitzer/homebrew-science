//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <xyfund/fixed_string.hpp>
#include <xyfund/units/base_dimension.hpp>
#include <xyfund/units/quantity.hpp>
#include <xyfund/units/si/prefix.hpp>
#include <xyfund/units/unit.hpp>

namespace xyfund {
namespace units {
namespace si {
namespace symbol {

struct gram : named<gram>
{
    static constexpr fixed_string<char, 1> symbol_value = "g"; 
};

} // namespace symbol

using gram = named_unit<symbol::gram>;

using kilogram  = prefixed_unit<prefix::kilo, gram>;
using decigram  = prefixed_unit<prefix::deci, gram>;
using centigram = prefixed_unit<prefix::centi, gram>;
using milligram = prefixed_unit<prefix::milli, gram>;
using microgram = prefixed_unit<prefix::micro, gram>;
using nanogram  = prefixed_unit<prefix::nano, gram>;

using dim_mass = base_dim_mass<gram>;

template<typename Unit, typename Representation = double>
using mass = quantity<dim_mass, Unit, Representation>;

inline namespace literals {

constexpr auto operator"" _kg(unsigned long long l)
{
    return mass<kilogram, std::int64_t>(l);
}
constexpr auto operator"" _kg(long double l)
{
    return mass<kilogram, long double>(l);
}

constexpr auto operator"" _g(unsigned long long l)
{
    return mass<gram, std::int64_t>(l);
}
constexpr auto operator"" _g(long double l)
{
    return mass<gram, long double>(l);
}

constexpr auto operator"" _dg(unsigned long long l)
{
    return mass<decigram, std::int64_t>(l);
}
constexpr auto operator"" _dg(long double l)
{
    return mass<decigram, long double>(l);
}

constexpr auto operator"" _cg(unsigned long long l)
{
    return mass<centigram, std::int64_t>(l);
}
constexpr auto operator"" _cg(long double l)
{
    return mass<centigram, long double>(l);
}

constexpr auto operator"" _mg(unsigned long long l)
{
    return mass<milligram, std::int64_t>(l);
}
constexpr auto operator"" _mg(long double l)
{
    return mass<milligram, long double>(l);
}

constexpr auto operator"" _ug(unsigned long long l)
{
    return mass<microgram, std::int64_t>(l);
}
constexpr auto operator"" _ug(long double l)
{
    return mass<microgram, long double>(l);
}

constexpr auto operator"" _ng(unsigned long long l)
{
    return mass<nanogram, std::int64_t>(l);
}
constexpr auto operator"" _ng(long double l)
{
    return mass<nanogram, long double>(l);
}

} // namespace literals

} // namespace si
} // namespace units
} // namespace xyfund
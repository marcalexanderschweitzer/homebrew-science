//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <xyfund/fixed_string.hpp>
#include <xyfund/units/base_dimension.hpp>
#include <xyfund/units/quantity.hpp>
#include <xyfund/units/si/prefix.hpp>
#include <xyfund/units/unit.hpp>

namespace xyfund {
namespace units {
namespace si {
namespace symbol {

struct ampere : named<ampere>
{
    static constexpr fixed_string<char, 1> symbol_value = "A"; 
};

} // namespace symbol

using ampere = named_unit<symbol::ampere>;

using kiloampere  = prefixed_unit<prefix::kilo, ampere>;
using deciampere  = prefixed_unit<prefix::deci, ampere>;
using centiampere = prefixed_unit<prefix::centi, ampere>;
using milliampere = prefixed_unit<prefix::milli, ampere>;
using microampere = prefixed_unit<prefix::micro, ampere>;
using nanoampere  = prefixed_unit<prefix::nano, ampere>;

using dim_current = base_dim_current<ampere>;

template<typename Unit, typename Representation = double>
using current = quantity<dim_current, Unit, Representation>;

inline namespace literals {

constexpr auto operator"" _kA(unsigned long long l)
{
    return current<kiloampere, std::int64_t>(l);
}
constexpr auto operator"" _kA(long double l)
{
    return current<kiloampere, long double>(l);
}

constexpr auto operator"" _A(unsigned long long l)
{
    return current<ampere, std::int64_t>(l);
}
constexpr auto operator"" _A(long double l)
{
    return current<ampere, long double>(l);
}

constexpr auto operator"" _dA(unsigned long long l)
{
    return current<deciampere, std::int64_t>(l);
}
constexpr auto operator"" _dA(long double l)
{
    return current<deciampere, long double>(l);
}

constexpr auto operator"" _cA(unsigned long long l)
{
    return current<centiampere, std::int64_t>(l);
}
constexpr auto operator"" _cA(long double l)
{
    return current<centiampere, long double>(l);
}

constexpr auto operator"" _mA(unsigned long long l)
{
    return current<milliampere, std::int64_t>(l);
}
constexpr auto operator"" _mA(long double l)
{
    return current<milliampere, long double>(l);
}

constexpr auto operator"" _uA(unsigned long long l)
{
    return current<microampere, std::int64_t>(l);
}
constexpr auto operator"" _uA(long double l)
{
    return current<microampere, long double>(l);
}

constexpr auto operator"" _nA(unsigned long long l)
{
    return current<nanoampere, std::int64_t>(l);
}
constexpr auto operator"" _nA(long double l)
{
    return current<nanoampere, long double>(l);
}

} // namespace literals

} // namespace si
} // namespace units
} // namespace xyfund
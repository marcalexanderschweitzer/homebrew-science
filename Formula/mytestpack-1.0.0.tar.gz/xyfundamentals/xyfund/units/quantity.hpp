//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <xyfund/units/quantity_cast.hpp>
#include <xyfund/units/traits.hpp>

#include <xyfund/detail/python.hpp>

#pragma once

namespace xyfund {
namespace units {

template<typename Dimension, typename Unit, typename Representation>
class quantity
{
public:
    using dimension      = Dimension;
    using unit           = Unit;
    using representation = Representation;

    static_assert(traits::is_unit_of_v<unit, dimension>, "Unit is not a unit for the given dimension!");

    quantity()                    = default;
    quantity(const quantity&)     = default;
    quantity(quantity&&) noexcept = default;
    ~quantity()                   = default;

    template<typename Scalar, typename std::enable_if_t<traits::is_safe_scalar_transformable_v<Scalar, representation>>* = nullptr>
    constexpr explicit quantity(const Scalar& value) :
        value_(static_cast<representation>(value)) {}

    // Only implicitly convert if its possible without loss off accuracy
    template<typename OtherQuantityType, typename std::enable_if_t<traits::is_safe_quantity_transformable_v<OtherQuantityType, quantity, detail::total_transformation_t<quantity, OtherQuantityType>>>* = nullptr>
    constexpr quantity(const OtherQuantityType& q) :
        value_(quantity_cast<quantity>(q).count()) {}

    template<typename OtherQuantityType, typename std::enable_if_t<!(traits::is_safe_scalar_transformable_v<OtherQuantityType, representation>)&&!(traits::is_safe_quantity_transformable_v<OtherQuantityType, quantity, detail::total_transformation_t<quantity, OtherQuantityType>>)>* = nullptr>
    constexpr quantity(const OtherQuantityType& /*unused*/)
    {
        static_assert(xyfund::dependent_false<Dimension>::value, "No safe implicit copy available (possibly due to different representations!). Use quantity_cast<> explicitly!");
    }

    constexpr quantity& operator=(const quantity&) = default;
    constexpr quantity& operator=(quantity&&) noexcept = default;

    constexpr representation count() const { return value_; }

    constexpr quantity& operator-()
    {
        value_ = -value_;

        return *this;
    }

    template<typename Scalar, typename std::enable_if_t<traits::is_safe_scalar_transformable_v<Scalar, representation>>* = nullptr>
    constexpr quantity& operator*=(const Scalar& value)
    {
        value_ *= value;

        return *this;
    }

    template<typename Scalar, typename std::enable_if_t<traits::is_safe_scalar_transformable_v<Scalar, representation>>* = nullptr>
    constexpr quantity operator*(const Scalar& value) const
    {
        quantity result = *this;

        result *= value;

        return result;
    }

    template<typename Scalar, typename std::enable_if_t<traits::is_safe_scalar_transformable_v<Scalar, representation>>* = nullptr>
    constexpr quantity& operator/=(const Scalar& value)
    {
        value_ /= value;

        return *this;
    }

    template<typename Scalar, typename std::enable_if_t<traits::is_safe_scalar_transformable_v<Scalar, representation>>* = nullptr>
    constexpr quantity operator/(const Scalar& value) const
    {
        quantity result = *this;

        result /= value;

        return result;
    }

    template<typename OtherQuantityType, typename std::enable_if_t<traits::is_quantity_v<OtherQuantityType>>* = nullptr>
    constexpr quantity& operator+=(const OtherQuantityType& q2)
    {
        if constexpr(std::is_same_v<quantity, OtherQuantityType>)
        {
            value_ += q2.count();
        }
        else
        {
            const auto q2_cast = quantity_cast<quantity>(q2);

            value_ += q2_cast.count();
        }

        return *this;
    }

    template<typename OtherQuantityType, typename std::enable_if_t<traits::is_quantity_v<OtherQuantityType>>* = nullptr>
    constexpr auto operator+(const OtherQuantityType& q2) const
    {
        using result_representation = std::common_type_t<traits::representation_t<OtherQuantityType>, representation>;

        using result_type = quantity<Dimension, Unit, result_representation>;

        auto result = quantity_cast<result_type>(*this);
        result += quantity_cast<result_type>(q2);

        return result;
    }

    template<typename OtherQuantityType, typename std::enable_if_t<traits::is_quantity_v<OtherQuantityType>>* = nullptr>
    constexpr quantity& operator-=(const OtherQuantityType& q2)
    {
        if constexpr(std::is_same_v<quantity, OtherQuantityType>)
        {
            value_ -= q2.count();
        }
        else
        {
            const auto q2_cast = quantity_cast<quantity>(q2);

            value_ -= q2_cast.count();
        }
        return *this;
    }

    template<typename OtherQuantityType, typename std::enable_if_t<traits::is_quantity_v<OtherQuantityType>>* = nullptr>
    constexpr auto operator-(const OtherQuantityType& q2) const
    {
        using result_representation = std::common_type_t<traits::representation_t<OtherQuantityType>, representation>;

        using result_type = quantity<Dimension, Unit, result_representation>;

        auto result = quantity_cast<result_type>(*this);
        result -= quantity_cast<result_type>(q2);

        return result;
    }

    friend std::ostream& operator<<(std::ostream& os, const quantity& q)
    {
        return os << q.count() << quantity::unit::symbol();
    }

private:
    representation value_{};
};

namespace traits {
template<typename Dimension, typename Unit, typename Representation>
struct is_quantity<quantity<Dimension, Unit, Representation>> : std::true_type
{};

template<typename Dimension, typename Unit, typename Representation>
struct type_tag<quantity<Dimension, Unit, Representation>>
{
    using type = tags::quantity;
};
} // namespace traits
} // namespace units

#ifdef XYFUND_HAVE_PYBIND11
namespace detail {

template<typename Dimension, typename Unit, typename Representation>
struct exporter<xyfund::units::quantity<Dimension, Unit, Representation>>
{
    static pybind11::class_<xyfund::units::quantity<Dimension, Unit, Representation>> apply(pybind11::module& mod, const char* name, const char* factory_name)
    {
        namespace py = pybind11;

        auto cls = py::class_<xyfund::units::quantity<Dimension, Unit, Representation>>(mod, name)
                       .def(py::init<>())
                       .def(py::init<Representation>(), py::arg("value"))
                       .def("count", &xyfund::units::quantity<Dimension, Unit, Representation>::count);

        mod.def(
            factory_name != nullptr ? factory_name : name,
            [](Representation value) {
                return xyfund::units::quantity<Dimension, Unit, Representation>(value);
            },
            py::arg("value"));

        return cls;
    }
};
} // namespace detail
#endif // XYFUND_HAVE_PYBIND11

} // namespace xyfund

//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

namespace xyfund {
namespace units {
namespace tags {

struct any_tag
{};

struct transformation : any_tag
{};

struct identity : transformation
{};

struct ratio : transformation
{};

struct affine : transformation
{};

struct product : transformation
{};

struct power : transformation
{};

struct quantity : any_tag
{};

} // namespace tags
} // namespace units
} // namespace xyfund
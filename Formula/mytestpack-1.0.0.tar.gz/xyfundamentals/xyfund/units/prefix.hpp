//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

namespace xyfund {
namespace units {

template<typename Transformation>
struct prefix
{
    using transformation = Transformation;
};

} // namespace units
} // namespace xyfund

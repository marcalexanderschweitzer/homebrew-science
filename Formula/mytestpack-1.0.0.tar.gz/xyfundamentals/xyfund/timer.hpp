//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <chrono>

namespace xyfund {

template<typename ClockType = std::chrono::high_resolution_clock>
class timer
{
public:
    using time_point = typename ClockType::time_point;
    using duration   = typename ClockType::duration;

    timer();

    template<typename ResultDurationType = duration>
    ResultDurationType elapsed() const;

    void restart();

private:
    time_point start_;
};

//===========================================================================================================
template<typename ClockType>
timer<ClockType>::timer()
{
    start_ = ClockType::now();
}

//===========================================================================================================
template<typename ClockType>
template<typename ResultDurationType>
ResultDurationType timer<ClockType>::elapsed() const
{
    return std::chrono::duration_cast<ResultDurationType>(ClockType::now() - start_);
}

//===========================================================================================================
template<typename ClockType>
void timer<ClockType>::restart()
{
    start_ = ClockType::now();
}

} // namespace xyfund

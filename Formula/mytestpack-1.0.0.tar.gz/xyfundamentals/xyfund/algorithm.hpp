//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include "xyfund/algorithm/contains.hpp"
#include "xyfund/algorithm/numeric.hpp"
#include "xyfund/algorithm/remove_duplicates.hpp"
#include "xyfund/algorithm/string.hpp"
#include "xyfund/algorithm/tuple.hpp"

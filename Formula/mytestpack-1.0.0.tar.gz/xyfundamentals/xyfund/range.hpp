//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

namespace xyfund {

template<typename Iter, typename Sentinel = Iter>
class iterator_range
{
public:
    inline iterator_range(Iter begin, Sentinel end);

    inline Iter     begin() const;
    inline Sentinel end() const;

private:
    Iter     begin_;
    Sentinel end_;
};

//===========================================================================================================
template<typename Iter, typename Sentinel>
inline iterator_range<Iter, Sentinel>::iterator_range(Iter begin, Sentinel end) :
    begin_(std::move(begin)),
    end_(std::move(end))
{}

//===========================================================================================================
template<typename Iter, typename Sentinel>
inline Iter iterator_range<Iter, Sentinel>::begin() const
{
    return begin_;
}

//===========================================================================================================
template<typename Iter, typename Sentinel>
inline Sentinel iterator_range<Iter, Sentinel>::end() const
{
    return end_;
}

} // namespace xyfund

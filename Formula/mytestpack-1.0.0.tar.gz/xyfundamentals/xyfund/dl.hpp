//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

// Provides std::shared_library. See https://wg21.link/p0275r3

#include "xyfund/dl/shared_library.hpp"

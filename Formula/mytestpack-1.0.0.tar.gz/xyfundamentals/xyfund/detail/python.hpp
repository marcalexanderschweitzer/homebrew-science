//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#ifdef XYFUND_HAVE_PYBIND11
#    include <pybind11/pybind11.h>
#    include <pybind11/operators.h>
#    include <pybind11/stl.h>
#endif

namespace xyfund {

namespace detail {

template<typename T>
struct exporter;

} // namespace detail

#ifdef XYFUND_HAVE_PYBIND11

template<typename T>
pybind11::class_<T> export_class_to_python(pybind11::module& mod, const char* name, const char* factory_name)
{
    return detail::exporter<T>::apply(mod, name, factory_name);
}

template<typename T>
pybind11::class_<T> export_class_to_python(pybind11::module& mod, const char* name)
{
    return detail::exporter<T>::apply(mod, name);
}

template<typename T>
pybind11::class_<T> export_class_to_python(pybind11::module& mod)
{
    return detail::exporter<T>::apply(mod);
}

#endif // XYFUND_HAVE_PYBIND11

} // namespace xyfund

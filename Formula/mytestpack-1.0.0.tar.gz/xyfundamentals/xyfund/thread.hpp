//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include "xyfund/thread/enumerable_thread_specific.hpp"
#include "xyfund/thread/parallel_for.hpp"

//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

// Provides a non-complete implementation for some C++20 traits:
// See https://en.cppreference.com/w/cpp/iterator/iter_t

#include <iterator>

#include <xyfund/traits.hpp>

namespace xyfund {

template<typename T>
using iter_value_t = typename std::iterator_traits<xyfund::remove_cvref_t<T>>::value_type;

template<typename T>
using iter_reference_t = decltype(*std::declval<T&>());

template<typename T>
using iter_difference_t = typename std::iterator_traits<xyfund::remove_cvref_t<T>>::difference_type;

//template<typename T>
//using iter_rvalue_reference_t = decltype(xyfund::ranges::iter_move(std::declval<T&>()));
//
//template<typename T>
//using iter_common_reference_t = std::common_reference_t<xyfund::iter_reference_t<T>, xyfund::iter_value_t<T>&>;

} // namespace xyfund

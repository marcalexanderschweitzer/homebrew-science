//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

// Provides std::span. See https://wg21.link/p0122r7 or https://en.cppreference.com/w/cpp/container/span

#if defined(XYFUND_HAVE_STD_SPAN) && !defined(XYFUND_USE_XYFUND_SPAN)
#    include <span>
#else
#    include <array>
#    include <cctype>
#    include <iterator>
#    include <type_traits>

#    include "xyfund/assert.hpp"
#endif

namespace xyfund {

#if defined(XYFUND_HAVE_STD_SPAN) && !defined(XYFUND_USE_XYFUND_SPAN)

using std::dynamic_extent;
using std::span;

#else // XYFUND_HAVE_STD_SPAN

constexpr const std::ptrdiff_t dynamic_extent = -1;

template<typename ElementType, std::ptrdiff_t Extent = dynamic_extent>
class span;

namespace detail {

template<typename T>
struct is_span_oracle : std::false_type
{};

template<typename ElementType, std::ptrdiff_t Extent>
struct is_span_oracle<xyfund::span<ElementType, Extent>> : std::true_type
{};

template<typename T>
struct is_span : public is_span_oracle<std::remove_cv_t<T>>
{};

template<typename T>
struct is_std_array_oracle : std::false_type
{};

template<typename ElementType, std::size_t Extent>
struct is_std_array_oracle<std::array<ElementType, Extent>> : std::true_type
{};

template<typename T>
struct is_std_array : public is_std_array_oracle<std::remove_cv_t<T>>
{};

template<std::ptrdiff_t From, std::ptrdiff_t To>
struct is_allowed_extent_conversion : public std::integral_constant<bool, From == To || From == xyfund::dynamic_extent || To == xyfund::dynamic_extent>
{};

template<typename From, typename To>
struct is_allowed_element_type_conversion : public std::integral_constant<bool, std::is_convertible<From (*)[], To (*)[]>::value> // NOLINT(cppcoreguidelines-avoid-c-arrays, modernize-avoid-c-arrays)
{};

template<typename Span, bool IsConst>
class span_iterator
{
    using element_type = typename Span::element_type;

public:
    using iterator_category = std::random_access_iterator_tag;
    using value_type        = std::remove_cv_t<element_type>;
    using difference_type   = typename Span::index_type;

    using reference = std::conditional_t<IsConst, const element_type, element_type>&;
    using pointer   = std::add_pointer_t<reference>;

    span_iterator() = default;

    constexpr span_iterator(const Span* span, typename Span::index_type idx) noexcept :
        span_(span),
        index_(idx)
    {}

    friend span_iterator<Span, true>;

    template<bool OtherIsConst, std::enable_if_t<!OtherIsConst && IsConst>* = nullptr>
    constexpr span_iterator(const span_iterator<Span, OtherIsConst>& other) noexcept :
        span_iterator(other.span_, other.index_)
    {}

    constexpr reference operator*() const
    {
        xyfund_assert(index_ != span_->size());
        return *(span_->data() + index_);
    }

    constexpr pointer operator->() const
    {
        xyfund_assert(index_ != span_->size());
        return span_->data() + index_;
    }

    constexpr span_iterator& operator++()
    {
        xyfund_assert(0 <= index_ && index_ != span_->size());
        ++index_;
        return *this;
    }

    constexpr span_iterator operator++(int)
    {
        auto ret = *this;
        ++(*this);
        return ret;
    }

    constexpr span_iterator& operator--()
    {
        xyfund_assert(index_ != 0 && index_ <= span_->size());
        --index_;
        return *this;
    }

    constexpr span_iterator operator--(int)
    {
        auto ret = *this;
        --(*this);
        return ret;
    }

    constexpr span_iterator operator+(difference_type n) const
    {
        auto ret = *this;
        return ret += n;
    }

    friend constexpr span_iterator operator+(difference_type n, span_iterator const& rhs)
    {
        return rhs + n;
    }

    constexpr span_iterator& operator+=(difference_type n)
    {
        xyfund_assert((index_ + n) >= 0 && (index_ + n) <= span_->size());
        index_ += n;
        return *this;
    }

    constexpr span_iterator operator-(difference_type n) const
    {
        auto ret = *this;
        return ret -= n;
    }

    constexpr span_iterator& operator-=(difference_type n)
    {
        return *this += -n;
    }

    constexpr difference_type operator-(span_iterator rhs) const
    {
        xyfund_assert(span_ == rhs.span_);
        return index_ - rhs.index_;
    }

    constexpr reference operator[](difference_type n) const
    {
        return *(*this + n);
    }

    constexpr friend bool operator==(span_iterator lhs, span_iterator rhs) noexcept
    {
        return lhs.span_ == rhs.span_ && lhs.index_ == rhs.index_;
    }

    constexpr friend bool operator!=(span_iterator lhs, span_iterator rhs) noexcept
    {
        return !(lhs == rhs);
    }

    constexpr friend bool operator<(span_iterator lhs, span_iterator rhs) noexcept
    {
        return lhs.index_ < rhs.index_;
    }

    constexpr friend bool operator<=(span_iterator lhs, span_iterator rhs) noexcept
    {
        return !(rhs < lhs);
    }

    constexpr friend bool operator>(span_iterator lhs, span_iterator rhs) noexcept
    {
        return rhs < lhs;
    }

    constexpr friend bool operator>=(span_iterator lhs, span_iterator rhs) noexcept
    {
        return !(rhs > lhs);
    }

private:
    const Span*    span_  = nullptr;
    std::ptrdiff_t index_ = 0;
};

template<std::ptrdiff_t Ext>
class extent_type
{
public:
    using index_type = std::ptrdiff_t;

    static_assert(Ext >= 0, "A fixed-size span must be >= 0 in size.");

    constexpr extent_type() noexcept = default;

    template<index_type Other>
    constexpr extent_type(extent_type<Other> ext)
    {
        static_assert(Other == Ext || Other == dynamic_extent, "Mismatch between fixed-size extent and size of initializing data.");
        xyfund_assert(ext.size() == Ext);
    }

    constexpr extent_type(index_type size)
    {
        xyfund_assert(size == Ext);
    }

    constexpr index_type size() const noexcept
    {
        return Ext;
    }
};

template<>
class extent_type<dynamic_extent>
{
public:
    using index_type = std::ptrdiff_t;

    template<index_type Other>
    explicit constexpr extent_type(extent_type<Other> ext) :
        size_(ext.size())
    {}

    explicit constexpr extent_type(index_type size) :
        size_(size)
    {
        xyfund_assert(size >= 0);
    }

    constexpr index_type size() const noexcept
    {
        return size_;
    }

private:
    index_type size_;
};

template<typename ElementType, std::ptrdiff_t Extent, std::ptrdiff_t Offset, std::ptrdiff_t Count>
struct calculate_subspan_type
{
    using type = span<ElementType, Count != dynamic_extent
                                       ? Count
                                       : (Extent != dynamic_extent ? Extent - Offset : Extent)>;
};

} // namespace detail

template<typename ElementType, std::ptrdiff_t Extent>
class span // NOLINT(cppcoreguidelines-special-member-functions)
{
public:
    // constants and types
    using element_type = ElementType;
    using value_type   = std::remove_cv_t<ElementType>;
    using index_type   = std::ptrdiff_t;
    using pointer      = element_type*;
    using reference    = element_type&;

    using iterator               = detail::span_iterator<span<ElementType, Extent>, false>;
    using const_iterator         = detail::span_iterator<span<ElementType, Extent>, true>;
    using reverse_iterator       = std::reverse_iterator<iterator>;
    using const_reverse_iterator = std::reverse_iterator<const_iterator>;

    using size_type = index_type;

    static constexpr const index_type extent{Extent};

    template<bool Dependent = false, typename = std::enable_if_t<(Dependent || Extent <= 0)>>
    constexpr span() noexcept :
        storage_(nullptr, detail::extent_type<0>())
    {}

    constexpr span(pointer ptr, index_type count) :
        storage_(ptr, count)
    {}

    constexpr span(pointer firstElem, pointer lastElem) :
        storage_(firstElem, std::distance(firstElem, lastElem))
    {}

    template<std::size_t N>
    // NOLINTNEXTLINE(cppcoreguidelines-avoid-c-arrays, modernize-avoid-c-arrays)
    constexpr span(element_type (&arr)[N]) noexcept :
        storage_(known_not_null{std::addressof(arr[0])}, detail::extent_type<N>())
    {}

    template<std::size_t N, typename ArrayElementType = std::remove_const_t<element_type>>
    constexpr span(std::array<ArrayElementType, N>& arr) noexcept :
        storage_(arr.data(), detail::extent_type<N>())
    {}

    template<std::size_t N>
    constexpr span(const std::array<std::remove_const_t<element_type>, N>& arr) noexcept :
        storage_(arr.data(), detail::extent_type<N>())
    {}

    template<typename Container,
             typename = std::enable_if_t<
                 !detail::is_span<Container>::value && !detail::is_std_array<Container>::value &&
                 std::is_convertible<typename Container::pointer, pointer>::value &&
                 std::is_convertible<typename Container::pointer,
                                     decltype(std::declval<Container>().data())>::value>>
    constexpr span(Container& cont) :
        span(cont.data(), static_cast<index_type>(cont.size()))
    {}

    template<typename Container,
             typename = std::enable_if_t<
                 std::is_const<element_type>::value && !detail::is_span<Container>::value &&
                 std::is_convertible<typename Container::pointer, pointer>::value &&
                 std::is_convertible<typename Container::pointer,
                                     decltype(std::declval<Container>().data())>::value>>
    constexpr span(const Container& cont) :
        span(cont.data(), static_cast<index_type>(cont.size()))
    {}

    constexpr span(const span& other) noexcept = default;

    template<
        typename OtherElementType, std::ptrdiff_t OtherExtent,
        typename = std::enable_if_t<
            detail::is_allowed_extent_conversion<OtherExtent, Extent>::value &&
            detail::is_allowed_element_type_conversion<OtherElementType, element_type>::value>>
    constexpr span(const span<OtherElementType, OtherExtent>& other) :
        storage_(other.data(), detail::extent_type<OtherExtent>(other.size()))
    {}

    ~span() noexcept        = default;
    constexpr span& operator=(const span& other) noexcept = default;

    template<std::ptrdiff_t Count>
    constexpr span<element_type, Count> first() const
    {
        xyfund_assert(Count >= 0 && Count <= size());
        return {data(), Count};
    }

    template<std::ptrdiff_t Count>
    constexpr span<element_type, Count> last() const
    {
        xyfund_assert(Count >= 0 && size() - Count >= 0);
        return {data() + (size() - Count), Count};
    }

    template<std::ptrdiff_t Offset, std::ptrdiff_t Count = dynamic_extent>
    constexpr auto subspan() const -> typename detail::calculate_subspan_type<ElementType, Extent, Offset, Count>::type
    {
        xyfund_assert((Offset >= 0 && size() - Offset >= 0) &&
                      (Count == dynamic_extent || (Count >= 0 && Offset + Count <= size())));

        return {data() + Offset, Count == dynamic_extent ? size() - Offset : Count};
    }

    constexpr span<element_type, dynamic_extent> first(index_type count) const
    {
        xyfund_assert(count >= 0 && count <= size());
        return {data(), count};
    }

    constexpr span<element_type, dynamic_extent> last(index_type count) const
    {
        return make_subspan(size() - count, dynamic_extent, subspan_selector<Extent>{});
    }

    constexpr span<element_type, dynamic_extent> subspan(index_type offset, index_type count = dynamic_extent) const
    {
        return make_subspan(offset, count, subspan_selector<Extent>{});
    }

    constexpr index_type size() const noexcept { return storage_.size(); }
    constexpr index_type size_bytes() const noexcept
    {
        return size() * static_cast<index_type>(sizeof(element_type));
    }
    constexpr bool empty() const noexcept
    {
        return size() == 0;
    }

    constexpr reference operator[](index_type idx) const
    {
        return data()[idx];
    }

    constexpr reference at(index_type idx) const { return this->operator[](idx); }
    constexpr reference operator()(index_type idx) const { return this->operator[](idx); }
    constexpr pointer   data() const noexcept { return storage_.data(); }

    constexpr iterator begin() const noexcept { return {this, 0}; }
    constexpr iterator end() const noexcept { return {this, size()}; }

    constexpr const_iterator cbegin() const noexcept { return {this, 0}; }
    constexpr const_iterator cend() const noexcept { return {this, size()}; }

    constexpr reverse_iterator rbegin() const noexcept { return reverse_iterator{end()}; }
    constexpr reverse_iterator rend() const noexcept { return reverse_iterator{begin()}; }

    constexpr const_reverse_iterator crbegin() const noexcept
    {
        return const_reverse_iterator{cend()};
    }
    constexpr const_reverse_iterator crend() const noexcept
    {
        return const_reverse_iterator{cbegin()};
    }

private:
    struct known_not_null
    {
        pointer p;
    };

    template<typename ExtentType>
    class storage_type : public ExtentType
    {
    public:
        template<typename OtherExtentType>
        constexpr storage_type(known_not_null data, OtherExtentType ext) :
            ExtentType(ext),
            data_(data.p)
        {
            xyfund_assert(ExtentType::size() >= 0);
        }

        template<typename OtherExtentType>
        constexpr storage_type(pointer data, OtherExtentType ext) :
            ExtentType(ext),
            data_(data)
        {
            xyfund_assert(ExtentType::size() >= 0);
            xyfund_assert(data || ExtentType::size() == 0);
        }

        constexpr pointer data() const noexcept
        {
            return data_;
        }

    private:
        pointer data_;
    };

    storage_type<detail::extent_type<Extent>> storage_;

    constexpr span(known_not_null ptr, index_type count) :
        storage_(ptr, count)
    {}

    template<std::ptrdiff_t CallerExtent>
    class subspan_selector
    {};

    template<std::ptrdiff_t CallerExtent>
    span<element_type, dynamic_extent> make_subspan(index_type offset, index_type count, subspan_selector<CallerExtent> /*subspan_selector*/) const
    {
        const span<element_type, dynamic_extent> tmp(*this);
        return tmp.subspan(offset, count);
    }

    span<element_type, dynamic_extent> make_subspan(index_type offset, index_type count, subspan_selector<dynamic_extent> /*subspan_selector*/) const
    {
        xyfund_assert(offset >= 0 && size() - offset >= 0);

        if(count == dynamic_extent) { return {known_not_null{data() + offset}, size() - offset}; }

        xyfund_assert(count >= 0 && size() - offset >= count);
        return {known_not_null{data() + offset}, count};
    }
};

#endif // XYFUND_HAVE_STD_SPAN

template<typename ElementType>
constexpr span<ElementType> make_span(ElementType* ptr, typename span<ElementType>::index_type count)
{
    return span<ElementType>(ptr, count);
}

template<typename ElementType>
constexpr span<ElementType> make_span(ElementType* firstElem, ElementType* lastElem)
{
    return span<ElementType>(firstElem, lastElem);
}

template<typename ElementType, std::size_t N>
constexpr span<ElementType, N> make_span(ElementType (&arr)[N]) noexcept // NOLINT(cppcoreguidelines-avoid-c-arrays, modernize-avoid-c-arrays)
{
    return span<ElementType, N>(arr);
}

template<typename Container>
constexpr span<typename Container::value_type> make_span(Container& cont)
{
    return span<typename Container::value_type>(cont);
}

template<typename Container>
constexpr span<const typename Container::value_type> make_span(const Container& cont)
{
    return span<const typename Container::value_type>(cont);
}

template<typename Ptr>
constexpr span<typename Ptr::element_type> make_span(Ptr& cont, std::ptrdiff_t count)
{
    return span<typename Ptr::element_type>(cont, count);
}

template<typename Ptr>
constexpr span<typename Ptr::element_type> make_span(Ptr& cont)
{
    return span<typename Ptr::element_type>(cont);
}

} // namespace xyfund

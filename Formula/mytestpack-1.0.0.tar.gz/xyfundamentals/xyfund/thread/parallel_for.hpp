//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#ifdef XYFUND_HAVE_TBB
#    include <tbb/parallel_for.h>
#endif

namespace xyfund {

namespace detail {

template<typename Index, typename F>
void non_parallel_for(Index begin, Index end, F&& f)
{
    for(auto i = begin; i < end; ++i)
    {
        f(i);
    }
}

} // namespace detail

#ifdef XYFUND_HAVE_TBB

template<typename Index, typename F>
void parallel_for(Index begin, Index end, F&& f)
{
    tbb::parallel_for(begin, end, std::forward<F>(f));
}

#else // XYFUND_HAVE_TBB

template<typename Index, typename F>
void parallel_for(Index begin, Index end, F&& f)
{
    // Fall-back to non-parallel implementation
    detail::non_parallel_for(begin, end, std::forward<F>(f));
}

#endif // XYFUND_HAVE_TBB

template<typename Index, typename F>
void conditional_parallel_for(bool parallel, Index begin, Index end, F&& f)
{
    if(parallel)
    {
        parallel_for(begin, end, std::forward<F>(f));
    }
    else
    {
        detail::non_parallel_for(begin, end, std::forward<F>(f));
    }
}

} // namespace xyfund

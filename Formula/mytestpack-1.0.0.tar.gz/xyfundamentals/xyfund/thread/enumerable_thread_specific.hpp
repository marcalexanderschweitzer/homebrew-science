//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <array>

#include "xyfund/optional.hpp"

#ifdef XYFUND_HAVE_TBB
#    include <tbb/enumerable_thread_specific.h>
#endif

namespace xyfund {

#ifdef XYFUND_HAVE_TBB

using tbb::enumerable_thread_specific;

#else // XYFUND_HAVE_TBB

template<typename T>
class enumerable_thread_specific
{
public:
    // Basic types
    //using allocator_type = Allocator;
    using value_type      = T;
    using reference       = T&;
    using const_reference = const T&;
    using size_type       = std::size_t;
    using difference_type = std::ptrdiff_t;

    // Iterator types
    using iterator       = typename std::array<T, 1>::iterator;
    using const_iterator = typename std::array<T, 1>::const_iterator;

    // Construction and destruction
    inline enumerable_thread_specific();
    inline explicit enumerable_thread_specific(const T& exemplar);
    inline explicit enumerable_thread_specific(T&& exemplar);
    // template<typename... Args>
    // inline enumerable_thread_specific(Args&&... args);
    inline ~enumerable_thread_specific();

    // Copying constructors and assignments
    inline enumerable_thread_specific(const enumerable_thread_specific& other);
    inline enumerable_thread_specific(enumerable_thread_specific&& other);

    inline enumerable_thread_specific& operator=(const enumerable_thread_specific& other);
    inline enumerable_thread_specific& operator=(enumerable_thread_specific&& other);

    // Other whole container operations
    inline void clear();

    // Concurrent operations
    inline reference local();
    inline reference local(bool& exists);
    inline size_type size() const;
    inline bool      empty() const;

    // Combining
    //template<typename BinaryFunc> inline T combine(BinaryFunc f);
    //template<typename UnaryFunc> inline void combine_each(UnaryFunc f);

    // Parallel iteration
    //inline range_type range(size_t grainsize = 1);
    //inline const_range_type range(size_t grainsize = 1) const;

    // Iterators
    inline iterator       begin();
    inline iterator       end();
    inline const_iterator begin() const;
    inline const_iterator end() const;

private:
    std::array<T, 1> data_;
};

//===========================================================================================================
template<typename T>
inline enumerable_thread_specific<T>::enumerable_thread_specific()
{}

//===========================================================================================================
template<typename T>
inline enumerable_thread_specific<T>::enumerable_thread_specific(const T& exemplar) :
    data_{exemplar}
{}

//===========================================================================================================
template<typename T>
inline enumerable_thread_specific<T>::enumerable_thread_specific(T&& exemplar) :
    data_{std::forward<T>(exemplar)}
{}

//===========================================================================================================
// Rejected by GCC 9 on Linux
// template<typename T>
// template<typename... Args>
// inline enumerable_thread_specific<T>::enumerable_thread_specific(Args&& ... args) :
//     data_{ T(std::forward<Args>(args)...) }
// {}

//===========================================================================================================
template<typename T>
inline enumerable_thread_specific<T>::~enumerable_thread_specific()
{}

//===========================================================================================================
template<typename T>
inline enumerable_thread_specific<T>::enumerable_thread_specific(const enumerable_thread_specific& other) :
    data_(other.data_)
{}

//===========================================================================================================
template<typename T>
inline enumerable_thread_specific<T>::enumerable_thread_specific(enumerable_thread_specific&& other) :
    data_(std::move(other.data_))
{}

//===========================================================================================================
template<typename T>
inline enumerable_thread_specific<T>& enumerable_thread_specific<T>::operator=(const enumerable_thread_specific& other)
{
    data_ = other.data_;
}

//===========================================================================================================
template<typename T>
inline enumerable_thread_specific<T>& enumerable_thread_specific<T>::operator=(enumerable_thread_specific&& other)
{
    data_ = std::move(other.data_);
}

//===========================================================================================================
template<typename T>
inline void enumerable_thread_specific<T>::clear()
{}

//===========================================================================================================
template<typename T>
inline typename enumerable_thread_specific<T>::reference enumerable_thread_specific<T>::local()
{
    return data_[0];
}

//===========================================================================================================
template<typename T>
inline typename enumerable_thread_specific<T>::reference enumerable_thread_specific<T>::local(bool& exists)
{
    exists = true;
    return data_[0];
}

//===========================================================================================================
template<typename T>
inline typename enumerable_thread_specific<T>::size_type enumerable_thread_specific<T>::size() const
{
    return data_.size();
}

//===========================================================================================================
template<typename T>
inline bool enumerable_thread_specific<T>::empty() const
{
    return data_.empty();
}

//===========================================================================================================
template<typename T>
inline typename enumerable_thread_specific<T>::iterator enumerable_thread_specific<T>::begin()
{
    return data_.begin();
}

//===========================================================================================================
template<typename T>
inline typename enumerable_thread_specific<T>::iterator enumerable_thread_specific<T>::end()
{
    return data_.end();
}

//===========================================================================================================
template<typename T>
inline typename enumerable_thread_specific<T>::const_iterator enumerable_thread_specific<T>::begin() const
{
    return data_.begin();
}

//===========================================================================================================
template<typename T>
inline typename enumerable_thread_specific<T>::const_iterator enumerable_thread_specific<T>::end() const
{
    return data_.end();
}

#endif // XYFUND_HAVE_TBB

} // namespace xyfund

//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <iostream>
#include <type_traits>

// NOLINTNEXTLINE(cppcoreguidelines-macro-usage)
#define XYFUND_SELECT_MACRO(_1, _2, NAME, ...) NAME

// NOLINTNEXTLINE(cppcoreguidelines-macro-usage)
#define XYFUND_EXPAND_MACRO(x) x

#if !defined(XYFUND_CLANG_ANALYZER_NORETURN) && defined(__has_feature)
#   if __has_feature(attribute_analyzer_noreturn)
#       define XYFUND_CLANG_ANALYZER_NORETURN __attribute__((analyzer_noreturn)) // NOLINT(cppcoreguidelines-macro-usage)
#   endif
#endif
#ifndef XYFUND_CLANG_ANALYZER_NORETURN
#   define XYFUND_CLANG_ANALYZER_NORETURN // NOLINT(cppcoreguidelines-macro-usage)
#endif

#ifndef XYFUND_ASSERT_HALT
#   if defined(__has_builtin)
#       if __has_builtin(__builtin_debugtrap)
#           define XYFUND_ASSERT_HALT() __builtin_debugtrap() // NOLINT(cppcoreguidelines-macro-usage)
#       endif
#       if __has_builtin(__debugbreak)
#           define XYFUND_ASSERT_HALT() __debugbreak() // NOLINT(cppcoreguidelines-macro-usage)
#       endif
#   endif
#   ifndef XYFUND_ASSERT_HALT
#       if defined(_MSC_VER)
#           define XYFUND_ASSERT_HALT() __debugbreak() // NOLINT(cppcoreguidelines-macro-usage)
#       elif defined(__i386__) || defined(__x86_64__)
            namespace xyfund { namespace detail { __attribute__((always_inline)) __inline__ static void debug_break() { __asm__ __volatile__("int3"); } } }
#           define XYFUND_ASSERT_HALT() ::xyfund::detail::debug_break() // NOLINT(cppcoreguidelines-macro-usage)
#       elif defined(__aarch64__)
            namespace xyfund { namespace detail { __attribute__((always_inline)) __inline__ static void debug_break() { __asm__ __volatile__(".inst 0xd4200000"); } } }
#           define XYFUND_ASSERT_HALT() ::xyfund::detail::debug_break() // NOLINT(cppcoreguidelines-macro-usage)
#       elif defined(__arm__)
            namespace xyfund { namespace detail { __attribute__((always_inline)) __inline__ static void debug_break() { __asm__ __volatile__(".inst 0xe7f001f0"); } } }
#           define XYFUND_ASSERT_HALT() ::xyfund::detail::debug_break() // NOLINT(cppcoreguidelines-macro-usage)
#       else
#           include <csignal>
#           ifdef SIGTRAP
#               define XYFUND_ASSERT_HALT() std::raise(SIGTRAP) // NOLINT(cppcoreguidelines-macro-usage)
#           else
#               define XYFUND_ASSERT_HALT() std::raise(SIGABRT) // NOLINT(cppcoreguidelines-macro-usage)
#           endif
#       endif
#   endif
#endif

// NOLINTNEXTLINE(cppcoreguidelines-macro-usage)
#define XYFUND_ASSERT_NO_MSG(expression) (void)((!!(expression)) ||                                                        \
                                                (::xyfund::detail::handle_assert((#expression), __FILE__, __LINE__), 0) || \
                                                (XYFUND_ASSERT_HALT(), 0))

// NOLINTNEXTLINE(cppcoreguidelines-macro-usage)
#define XYFUND_ASSERT_WITH_MSG(expression, message) (void)((!!(expression)) ||                                                                 \
                                                           (::xyfund::detail::handle_assert((#expression), __FILE__, __LINE__, message), 0) || \
                                                           (XYFUND_ASSERT_HALT(), 0))

// NOLINTNEXTLINE(cppcoreguidelines-macro-usage)
#define XYFUND_DISABLED_ASSERT_NO_MSG(expression) (void)(true ? (void)0 : ((void)(expression)))

// NOLINTNEXTLINE(cppcoreguidelines-macro-usage)
#define XYFUND_DISABLED_ASSERT_WITH_MSG(expression, message) (void)(true ? (void)0 : ((void)(expression), (void)(message)))

// NOLINTNEXTLINE(cppcoreguidelines-macro-usage)
#define XYFUND_ENABLED_ASSERT(...) XYFUND_EXPAND_MACRO(XYFUND_SELECT_MACRO(__VA_ARGS__, XYFUND_ASSERT_WITH_MSG, XYFUND_ASSERT_NO_MSG, 0)(__VA_ARGS__))

// NOLINTNEXTLINE(cppcoreguidelines-macro-usage)
#define XYFUND_DISABLED_ASSERT(...) XYFUND_EXPAND_MACRO(XYFUND_SELECT_MACRO(__VA_ARGS__, XYFUND_DISABLED_ASSERT_WITH_MSG, XYFUND_DISABLED_ASSERT_NO_MSG, 0)(__VA_ARGS__))

#ifdef XYFUND_NO_ASSERT
// NOLINTNEXTLINE(cppcoreguidelines-macro-usage)
#    define xyfund_assert(...) XYFUND_DISABLED_ASSERT(__VA_ARGS__)
#else
// NOLINTNEXTLINE(cppcoreguidelines-macro-usage)
#    define xyfund_assert(...) XYFUND_ENABLED_ASSERT(__VA_ARGS__)
#endif

namespace xyfund {

namespace detail {

inline void handle_assert(const char* expression, const char* file, int line) XYFUND_CLANG_ANALYZER_NORETURN
{
    std::cerr << "assertion " << expression << " failed in " << file << ":" << line << std::endl;
}

inline void handle_assert(const char* expression, const char* file, int line, const char* message) XYFUND_CLANG_ANALYZER_NORETURN
{
    std::cerr << "assertion " << expression << " failed in " << file << ":" << line << ": " << message << std::endl;
}

} // namespace detail

} // namespace xyfund

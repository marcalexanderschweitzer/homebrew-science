//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include "xyfund/filesystem.hpp"
#include "xyfund/optional.hpp"
#include "xyfund/variant.hpp"
#include "xyfund/units/python.hpp"

#ifdef XYFUND_HAVE_PYBIND11

#    include <pybind11/operators.h>
#    include <pybind11/pybind11.h>
#    include <pybind11/stl.h>

namespace pybind11 {
namespace detail {

#    if defined(XYFUND_HAVE_BOOST_OPTIONAL) && (!defined(XYFUND_HAVE_STD_OPTIONAL) || defined(XYFUND_USE_BOOST_OPTIONAL))
template<typename T>
struct type_caster<boost::optional<T>> : optional_caster<boost::optional<T>>
{};
#    endif // XYFUND_HAVE_BOOST_OPTIONAL

#    if defined(XYFUND_HAVE_BOOST_VARIANT) && (!defined(XYFUND_HAVE_STD_VARIANT) || defined(XYFUND_USE_BOOST_VARIANT))
template<typename... Ts>
struct type_caster<boost::variant<Ts...>> : variant_caster<boost::variant<Ts...>>
{};

// Specifies the function used to visit the variant -- `apply_visitor` instead of `visit`
template<>
struct visit_helper<boost::variant>
{
    template<typename... Args>
    static auto call(Args&&... args) -> decltype(boost::apply_visitor(args...))
    {
        return boost::apply_visitor(args...);
    }
};
#    endif // XYFUND_HAVE_BOOST_VARIANT

template<typename T>
class type_caster<xyfund::optional_ref<T>>
{
private:
    using caster_t = make_caster<T>;
    caster_t subcaster_;
    bool loaded_none_ = false;

    using subcaster_cast_op_type = typename caster_t::template cast_op_type<T>;
    static_assert(std::is_same<typename std::remove_const<T>::type&, subcaster_cast_op_type>::value,
                    "xyfund::optional_ref<T> caster requires T to have a caster with an `T &` operator");
public:
    static constexpr auto name = _("OptionalRef[") + caster_t::name + _("]");

    bool load(handle src, bool convert)
    {
        if(!src)
        {
            return false;
        }
        if(src.is_none())
        {
            loaded_none_ = true;
            return true;
        }
        loaded_none_ = false;
        return subcaster_.load(src, convert);
    }

    static handle cast(const xyfund::optional_ref<T>& src, return_value_policy policy, handle parent)
    {
        if(!src) return none().inc_ref();
        // It is definitely wrong to take ownership of this pointer, so mask that rvp
        if(policy == return_value_policy::take_ownership || policy == return_value_policy::automatic)
        {
            policy = return_value_policy::automatic_reference;
        }
        return caster_t::cast(&src.value(), policy, parent);
    }

    template <typename U>
    using cast_op_type = xyfund::optional_ref<std::remove_reference_t<T>>;

    operator xyfund::optional_ref<T>()
    {
        if(loaded_none_) return xyfund::optional_ref<T>();
        return subcaster_.operator subcaster_cast_op_type &();
    }
};

struct path_caster
{
    using value_type  = std::string;
    using caster_type = type_caster<value_type>;

    static handle cast(const xyfund::filesystem::path& src, return_value_policy policy, handle parent)
    {
        return type_caster<std::string>::cast(src.string(), policy, parent);
    }

    bool load(handle src, bool convert)
    {
        if(!src || src.is_none()) return false;

        if(!inner_.load(src, convert)) return false;

        value = static_cast<const value_type&>(inner_);
        return true;
    }

    PYBIND11_TYPE_CASTER(xyfund::filesystem::path, _("path")); // NOLINT(cppcoreguidelines-non-private-member-variables-in-classes, cppcoreguidelines-owning-memory, misc-non-private-member-variables-in-classes, readability-else-after-return)

private:
    caster_type inner_;
};

template<>
struct type_caster<xyfund::filesystem::path> : public path_caster
{};

} // namespace detail
} // namespace pybind11

namespace xyfund {

inline void export_all_to_python(pybind11::module& mod)
{
    detail::export_units_to_python(mod);
}

} // namespace xyfund

#endif // XYFUND_HAVE_PYBIND11

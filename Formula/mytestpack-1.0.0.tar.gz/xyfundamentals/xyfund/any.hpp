//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

// Provides std::any. See https://en.cppreference.com/w/cpp/utility/any

#include <functional>
#include <unordered_map>
#include <utility>

#include <type_traits>

#include <typeindex>
#include <typeinfo>

#if defined(XYFUND_HAVE_STD_ANY) && !defined(XYFUND_USE_BOOST_ANY)
#    include <any>
#elif defined(XYFUND_HAVE_BOOST_ANY)
#    include <boost/any.hpp>
#endif

#include "xyfund/traits.hpp"

namespace xyfund {

#if defined(XYFUND_HAVE_STD_ANY) && !defined(XYFUND_USE_BOOST_ANY)
using any = std::any;
using std::any_cast;
using std::bad_any_cast;

inline bool has_value(const any& a)
{
    return a.has_value();
}
#elif defined(XYFUND_HAVE_BOOST_ANY)
using any = boost::any;
using boost::any_cast;
using boost::bad_any_cast;

inline bool has_value(const any& a)
{
    return !a.empty();
}
#else
#    error "Can not build without 'any' implementation"
#endif

class any_visitor
{
    using function_type = std::function<void(any&, bool)>;

public:
    template<typename F, typename T = typename xyfund::function_traits<std::decay_t<F>>::template argument_type_t<0>>
    void insert(F&& function)
    {
        visitors_.insert(std::make_pair(
            std::type_index(typeid(T)),
            function_type([function](any& x, bool was_const) {
                if(was_const && std::is_reference<T>::value && !std::is_const<std::remove_reference_t<T>>::value) throw bad_any_cast();
                function(any_cast<T&>(x));
            })));
    }

    bool operator()(any& x)
    {
        auto it = visitors_.find(x.type());
        if(it != visitors_.end())
        {
            it->second(x, false);
            return true;
        }

        return false;
    }

    bool operator()(const any& x)
    {
        auto it = visitors_.find(x.type());
        if(it != visitors_.end())
        {
            it->second(const_cast<any&>(x), true); // NOLINT(cppcoreguidelines-pro-type-const-cast)
            return true;
        }

        return false;
    }

private:
    std::unordered_map<std::type_index, function_type> visitors_;
};

} // namespace xyfund

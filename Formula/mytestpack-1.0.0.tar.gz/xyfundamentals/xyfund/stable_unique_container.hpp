//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <set>
#include <utility>
#include <vector>

#include "xyfund/types.hpp"
#include "xyfund/utility.hpp"

namespace xyfund {

//! A simple container wrapper class that stores unique values (no duplicates) and keeps the order of insertions.
//!
//! The underlying data storage type is a std::vector.
//!
//! NOTE: this type is not cheap to move, due to some limitations in the implemenation.
//!
//! @tparam ValueType The type of the elements to be stored.
//! @tparam Compare   Less-than (<) comparison functor type for the elements stored in the container.
template<typename ValueType, typename Compare = std::less<ValueType>>
class stable_unique_container
{
public:
    using value_type = ValueType;

    inline stable_unique_container();
    inline stable_unique_container(Compare&& compare);

    inline ~stable_unique_container() = default;

    inline stable_unique_container(const stable_unique_container& other);
    inline stable_unique_container(stable_unique_container&& other) noexcept;

    inline stable_unique_container& operator=(const stable_unique_container& other);
    inline stable_unique_container& operator=(stable_unique_container&& other) noexcept;

    //! Inserts a new entry into the container.
    //!
    //! If the entry is already present in the container, no insertion will be performed.
    //!
    //! @param value The entry to be added.
    //! @return A pair with the index to the added entry in the underlying data storage and a
    //!         boolean that indices whether the insertion has been performed or not.
    //!         If an insertion took place the returned index will always be the index of the last
    //!         entry in the underlying data storage.
    inline std::pair<xyfund::index_t, bool> insert(const ValueType& value);

    //! Returns the underlying vector that stores the inserted values.
    //!
    //! The values in the vector are in the same order as `insert` has been called.
    inline const std::vector<ValueType>& data() const;

    //! Returns the underlying vector that stores the inserted values by value. 
    //!
    //! The values in the vector are in the same order as `insert` has been called.
    //! 
    //! After the call to this function the stable unique container will be cleared.
    inline std::vector<ValueType> release();
private:
    struct indirect_compare
    {
        using is_transparent = std::true_type;

        inline bool operator()(xyfund::index_t lhs, xyfund::index_t rhs) const;
        inline bool operator()(xyfund::index_t lhs, const ValueType& rhs) const;
        inline bool operator()(const ValueType& lhs, xyfund::index_t rhs) const;

        const std::vector<ValueType>* data_ = nullptr;  // NOLINT(misc-non-private-member-variables-in-classes)
        Compare                       value_compare_{}; // NOLINT(misc-non-private-member-variables-in-classes)
    };

    //! The actual data stored in the container.
    std::vector<ValueType>                      data_;

    //! Set of indices into the real data. This is basically a sorted view into the data
    //! that allows for O(log N) look-up whether a value has been inserted already.
    std::set<xyfund::index_t, indirect_compare> data_index_set_;
};

//===========================================================================================================
template<typename ValueType, typename Compare>
inline stable_unique_container<ValueType, Compare>::stable_unique_container() :
    data_index_set_(indirect_compare{&data_, Compare{}})
{}

//===========================================================================================================
template<typename ValueType, typename Compare>
inline stable_unique_container<ValueType, Compare>::stable_unique_container(Compare&& compare) :
    data_index_set_(indirect_compare{&data_, std::move(compare)})
{}

//===========================================================================================================
template<typename ValueType, typename Compare>
inline stable_unique_container<ValueType, Compare>::stable_unique_container(const stable_unique_container& other) :
    data_(other.data_),
    data_index_set_(other.data_index_set_.begin(), other.data_index_set_.end(), indirect_compare{&data_, other.data_index_set_.value_comp().value_compare_})
{}

//===========================================================================================================
template<typename ValueType, typename Compare>
inline stable_unique_container<ValueType, Compare>::stable_unique_container(stable_unique_container&& other) noexcept :
    data_(std::move(other.data_)),
    // NOTE: We do actually copy instead of move here. This is necessary because we need to change the compare-functor in the set
    //       so that it points to the right data vector. The move constructor of the std::set does not allow us to change the compare-functor.
    data_index_set_(other.data_index_set_.begin(), other.data_index_set_.end(), indirect_compare{&data_, other.data_index_set_.value_comp().value_compare_})
{}

//===========================================================================================================
template<typename ValueType, typename Compare>
inline stable_unique_container<ValueType, Compare>& stable_unique_container<ValueType, Compare>::operator=(const stable_unique_container& other)
{
    data_           = other.data_;
    data_index_set_ = std::set<xyfund::index_t, indirect_compare>(other.data_index_set_.begin(), other.data_index_set_.end(), indirect_compare{&data_, other.data_index_set_.value_comp().value_compare_});
    return *this;
}

//===========================================================================================================
template<typename ValueType, typename Compare>
inline stable_unique_container<ValueType, Compare>& stable_unique_container<ValueType, Compare>::operator=(stable_unique_container&& other) noexcept
{
    data_           = std::move(other.data_);
    // NOTE: We do actually copy instead of move here. See the comment in the move-constructor for a more detailed explanation.
    data_index_set_ = std::set<xyfund::index_t, indirect_compare>(other.data_index_set_.begin(), other.data_index_set_.end(), indirect_compare{&data_, other.data_index_set_.value_comp().value_compare_});
    return *this;
}

//===========================================================================================================
template<typename ValueType, typename Compare>
std::pair<xyfund::index_t, bool> stable_unique_container<ValueType, Compare>::insert(const ValueType& value)
{
    const auto iter = data_index_set_.find(value);
    if(iter != data_index_set_.end())
    {
        // Value is already present
        return {*iter, false};
    }

    // Insert the new value
    data_.emplace_back(value);
    const auto new_index = xyfund::ssize(data_) - 1;
    data_index_set_.insert(new_index);
    return {new_index, true};
}

//===========================================================================================================
template<typename ValueType, typename Compare>
const std::vector<ValueType>& stable_unique_container<ValueType, Compare>::data() const
{
    return data_;
}

//===========================================================================================================
template<typename ValueType, typename Compare>
std::vector<ValueType> stable_unique_container<ValueType, Compare>::release()
{
    auto return_data = std::move(data_);
    data_index_set_.clear();
    data_.clear();
    return return_data;
}

//===========================================================================================================
template<typename ValueType, typename Compare>
bool stable_unique_container<ValueType, Compare>::indirect_compare::operator()(xyfund::index_t lhs, xyfund::index_t rhs) const
{
    return value_compare_((*data_)[lhs], (*data_)[rhs]);
}

//===========================================================================================================
template<typename ValueType, typename Compare>
bool stable_unique_container<ValueType, Compare>::indirect_compare::operator()(xyfund::index_t lhs, const ValueType& rhs) const
{
    return value_compare_((*data_)[lhs], rhs);
}

//===========================================================================================================
template<typename ValueType, typename Compare>
bool stable_unique_container<ValueType, Compare>::indirect_compare::operator()(const ValueType& lhs, xyfund::index_t rhs) const
{
    return value_compare_(lhs, (*data_)[rhs]);
}

} // namespace xyfund

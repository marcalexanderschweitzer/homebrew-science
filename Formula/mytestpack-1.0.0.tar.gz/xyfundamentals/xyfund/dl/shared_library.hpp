//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <string>

#include "xyfund/filesystem.hpp"

#if _WIN32
#    include "xyfund/dl/windows/shared_library.hpp"
#else
#    include "xyfund/dl/posix/shared_library.hpp"
#endif // _WIN32

namespace xyfund {

namespace dl {

class shared_library : detail::shared_library_impl
{
public:
    using native_handle_type = typename detail::shared_library_impl::native_handle_type;
    using dl_mode            = typename detail::shared_library_impl::dl_mode;

    using detail::shared_library_impl::add_decorations;
    using detail::shared_library_impl::default_mode;
    using detail::shared_library_impl::rtld_global;
    using detail::shared_library_impl::rtld_lazy;
    using detail::shared_library_impl::rtld_local;
    using detail::shared_library_impl::rtld_now;
    using detail::shared_library_impl::search_system_directories;

    // construct/copy/destruct
    inline shared_library() noexcept                 = default;
    inline shared_library(const shared_library& lib) = delete;
    inline shared_library(shared_library&& lib) noexcept;

    inline explicit shared_library(const filesystem::path& library_path);
    inline shared_library(const filesystem::path& library_path, dl_mode mode);

    inline ~shared_library() = default;

    // public member functions
    inline shared_library& operator=(const shared_library& lib) = delete;
    inline shared_library& operator                             =(shared_library&& lib) noexcept;

    inline void reset() noexcept;

    inline explicit operator bool() const noexcept;

    template<typename SymbolT>
    inline SymbolT* get_if(const char* symbol_name) const noexcept;
    template<typename SymbolT>
    inline SymbolT* get_if(const std::string& symbol_name) const noexcept;

    template<typename SymbolT>
    inline SymbolT& get(const char* symbol_name) const;
    template<typename SymbolT>
    inline SymbolT& get(const std::string& symbol_name) const;

    inline native_handle_type native_handle() const noexcept;
};

//===========================================================================================================
inline shared_library::shared_library(shared_library&& lib) noexcept :
    detail::shared_library_impl(std::move(lib))
{}

//===========================================================================================================
inline shared_library::shared_library(const filesystem::path& library_path) :
    detail::shared_library_impl(library_path)
{}

//===========================================================================================================
inline shared_library::shared_library(const filesystem::path& library_path, dl_mode mode) :
    detail::shared_library_impl(library_path, mode)
{}

//===========================================================================================================
inline shared_library& shared_library::operator=(shared_library&& lib) noexcept
{
    detail::shared_library_impl::operator=(std::move(lib));
    return *this;
}

//===========================================================================================================
inline void shared_library::reset() noexcept
{
    detail::shared_library_impl::reset();
}

//===========================================================================================================
inline shared_library::operator bool() const noexcept
{
    return detail::shared_library_impl::operator bool();
}

//===========================================================================================================
inline typename shared_library::native_handle_type shared_library::native_handle() const noexcept
{
    return detail::shared_library_impl::native_handle();
}

//===========================================================================================================
template<typename SymbolT>
inline SymbolT* shared_library::get_if(const char* symbol_name) const noexcept
{
    return detail::shared_library_impl::get_if<SymbolT>(symbol_name);
}

//===========================================================================================================
template<typename SymbolT>
inline SymbolT* shared_library::get_if(const std::string& symbol_name) const noexcept
{
    return detail::shared_library_impl::get_if<SymbolT>(symbol_name);
}

//===========================================================================================================
template<typename SymbolT>
inline SymbolT& shared_library::get(const char* symbol_name) const
{
    return detail::shared_library_impl::get<SymbolT>(symbol_name);
}

//===========================================================================================================
template<typename SymbolT>
inline SymbolT& shared_library::get(const std::string& symbol_name) const
{
    return detail::shared_library_impl::get<SymbolT>(symbol_name);
}

} // namespace dl

} // namespace xyfund

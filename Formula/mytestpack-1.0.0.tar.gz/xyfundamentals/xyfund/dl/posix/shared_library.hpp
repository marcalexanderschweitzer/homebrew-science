//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <cstring>

#include <string>
#include <system_error>

#include <dlfcn.h>

#include "xyfund/filesystem.hpp"

namespace xyfund {

namespace detail {

inline std::string posix_get_last_error_message()
{
    const auto* const error_message_ptr = ::dlerror();
    return std::string(error_message_ptr == nullptr ? "" : error_message_ptr);
}

class shared_library_impl
{
public:
    using native_handle_type = void*;

    // shared library file load modes
    using dl_mode = unsigned int;

    static constexpr dl_mode rtld_lazy                 = RTLD_LAZY;
    static constexpr dl_mode rtld_now                  = RTLD_NOW;
    static constexpr dl_mode rtld_global               = RTLD_GLOBAL;
    static constexpr dl_mode rtld_local                = RTLD_LOCAL;
    static constexpr dl_mode add_decorations           = 0x00800000;
    static constexpr dl_mode search_system_directories = (add_decorations << 1);
    static constexpr dl_mode default_mode              = rtld_lazy | rtld_local;

    inline shared_library_impl(const shared_library_impl& lib) = delete;
    inline shared_library_impl& operator=(const shared_library_impl& lib) = delete;

protected:
    inline shared_library_impl() noexcept = default;
    inline shared_library_impl(shared_library_impl&& lib) noexcept;

    inline explicit shared_library_impl(const filesystem::path& library_path);
    inline shared_library_impl(const filesystem::path& library_path, dl_mode mode);

    inline ~shared_library_impl();

    inline shared_library_impl& operator=(shared_library_impl&& lib) noexcept;

    inline void reset() noexcept;

    inline explicit operator bool() const noexcept;

    template<typename SymbolT>
    inline SymbolT* get_if(const char* symbol_name) const noexcept;
    template<typename SymbolT>
    inline SymbolT* get_if(const std::string& symbol_name) const noexcept;

    template<typename SymbolT>
    inline SymbolT& get(const char* symbol_name) const;
    template<typename SymbolT>
    inline SymbolT& get(const std::string& symbol_name) const;

    inline native_handle_type native_handle() const noexcept;

private:
    native_handle_type handle_ = nullptr;

    inline void load(const filesystem::path& library_path, dl_mode mode, std::error_code& error_code);
    inline void unload();
};

//===========================================================================================================
inline shared_library_impl::shared_library_impl(shared_library_impl&& lib) noexcept :
    handle_(lib.handle_)
{
    lib.handle_ = nullptr;
}

//===========================================================================================================
inline shared_library_impl::shared_library_impl(const filesystem::path& library_path) :
    shared_library_impl(library_path, default_mode)
{}

//===========================================================================================================
inline shared_library_impl::shared_library_impl(const filesystem::path& library_path, dl_mode mode)
{
    std::error_code ec;
    load(library_path, mode, ec);
    if(ec)
    {
        throw std::system_error(ec, posix_get_last_error_message());
    }
}

//===========================================================================================================
inline shared_library_impl::~shared_library_impl()
{
    unload();
}

//===========================================================================================================
inline shared_library_impl& shared_library_impl::operator=(shared_library_impl&& lib) noexcept
{
    handle_     = lib.handle_;
    lib.handle_ = nullptr;
    return *this;
}

//===========================================================================================================
inline void shared_library_impl::reset() noexcept
{
    unload();
}

//===========================================================================================================
inline shared_library_impl::operator bool() const noexcept
{
    return handle_ != nullptr;
}

//===========================================================================================================
template<typename SymbolT>
inline SymbolT* shared_library_impl::get_if(const char* symbol_name) const noexcept
{
    return (SymbolT*)dlsym(handle_, symbol_name);
}

//===========================================================================================================
template<typename SymbolT>
inline SymbolT* shared_library_impl::get_if(const std::string& symbol_name) const noexcept
{
    return get_if<SymbolT>(symbol_name.c_str());
}

//===========================================================================================================
template<typename SymbolT>
inline SymbolT& shared_library_impl::get(const char* symbol_name) const
{
    const auto symbol_address = get_if<SymbolT>(symbol_name); // NOLINT(readability-qualified-auto)
    if(!symbol_address)
    {
        throw std::system_error(std::make_error_code(std::errc::bad_file_descriptor), posix_get_last_error_message());
    }
    return *symbol_address;
}

//===========================================================================================================
template<typename SymbolT>
inline SymbolT& shared_library_impl::get(const std::string& symbol_name) const
{
    return get<SymbolT>(symbol_name.c_str());
}

//===========================================================================================================
inline typename shared_library_impl::native_handle_type shared_library_impl::native_handle() const noexcept
{
    return handle_;
}

//===========================================================================================================
inline void shared_library_impl::load(const filesystem::path& library_path, dl_mode mode, std::error_code& error_code)
{
    error_code.clear();

    if((mode & rtld_now) == 0)
    {
        mode |= rtld_lazy;
    }

    if((mode & rtld_global) == 0)
    {
        mode |= rtld_local;
    }

    filesystem::path final_library_path;
#if defined(__linux__)
    if(!library_path.has_parent_path() && (mode & search_system_directories) == 0)
    {
        final_library_path = "." / library_path;
    }
#else
    if(!library_path.is_absolute() && (mode & search_system_directories) == 0)
    {
        final_library_path = filesystem::current_path() / library_path;
    }
#endif
    else
    {
        final_library_path = library_path;
    }

    mode &= ~search_system_directories;

    if((mode & add_decorations) != 0)
    {
        mode &= ~add_decorations;

        auto decorated_path = (std::strncmp(final_library_path.filename().string().c_str(), "lib", 3) != 0
                                   ? (final_library_path.has_parent_path() ? final_library_path.parent_path() / L"lib" : L"lib").native() + final_library_path.filename().native()
                                   : final_library_path.native());
#if defined(__APPLE__)
        decorated_path += ".dylib";
#else
        decorated_path += ".so";
#endif

        handle_ = dlopen(decorated_path.c_str(), mode);
        if(handle_ != nullptr) return;
    }

    handle_ = dlopen(final_library_path.c_str(), mode);

    if(handle_ == nullptr)
    {
        error_code = std::make_error_code(std::errc::bad_file_descriptor);
    }
}

//===========================================================================================================
inline void shared_library_impl::unload()
{
    if(handle_ != nullptr)
    {
        dlclose(handle_);
        handle_ = nullptr;
    }
}

} // namespace detail

} // namespace xyfund

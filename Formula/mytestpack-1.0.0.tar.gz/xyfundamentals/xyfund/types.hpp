//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

// Provides gsl::index. See http://isocpp.github.io/CppCoreGuidelines/CppCoreGuidelines#Res-subscripts

// NOTE: use together with xyfund::ssize()

#include <cstddef>

namespace xyfund {

using index_t = std::ptrdiff_t;

} // namespace xyfund

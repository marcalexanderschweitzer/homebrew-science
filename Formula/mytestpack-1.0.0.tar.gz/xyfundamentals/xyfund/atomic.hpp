//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <atomic>
#include <functional>

// Provides min/max operations on atomics. Similar to what is proposed
//   in  http://www.open-std.org/jtc1/sc22/wg21/docs/papers/2013/n3696.htm
//   and http://www.open-std.org/jtc1/sc22/wg21/docs/papers/2016/p0493r0.pdf

namespace xyfund {

template<typename T, typename P>
T atomic_priority_update(std::atomic<T>* obj, T arg, P&& predicate)
{
    T prev_arg = obj->load();
    while(predicate(prev_arg, arg) && !obj->compare_exchange_weak(prev_arg, arg))
    {}
    return prev_arg;
}

template<typename T>
T atomic_fetch_min(std::atomic<T>* obj, T arg)
{
    return atomic_priority_update(obj, arg, std::greater<T>());
}

template<typename T>
T atomic_fetch_max(std::atomic<T>* obj, T arg)
{
    return atomic_priority_update(obj, arg, std::less<T>());
}

} // namespace xyfund

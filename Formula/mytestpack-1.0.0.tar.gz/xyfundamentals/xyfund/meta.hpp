//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

// Meta-programming utilities similar to functionality provided by boost.mp11.
// See https://www.boost.org/doc/libs/release/libs/mp11/doc/html/mp11.html

#include <xyfund/traits.hpp>

namespace xyfund {

namespace mp {

//===========================================================================================================
// constants
template<int V>
using int_c = std::integral_constant<int, V>;

template<bool V>
using bool_c = std::integral_constant<bool, V>;

template<std::size_t V>
using size_c = std::integral_constant<std::size_t, V>;

//===========================================================================================================
// identity
template<typename T>
struct identity
{
    using type = T;
};

template<typename T>
using identity_t = typename identity<T>::type;

//===========================================================================================================
// inherit
template<typename... T>
struct inherit : T...
{};

//===========================================================================================================
// to_bool
template<typename T>
using to_bool = bool_c<static_cast<bool>(T::value)>;

//===========================================================================================================
// to_bool
template<typename T>
using not_t = bool_c<!T::value>;

//===========================================================================================================
// not_fn
template<template<typename...> typename P>
struct not_fn
{
    template<typename... T>
    using type = not_t<P<T...>>;
};

//===========================================================================================================
// list
template<typename... T>
struct list
{};

//===========================================================================================================
// integer_range
template<typename T, T Begin, T End>
struct integer_range
{
    static_assert(std::is_integral_v<T>, "Invalid integer range integral type");
    static_assert(End >= Begin, "Invalid integer range");
};

//===========================================================================================================
// list_size
template<typename T>
struct list_size : std::tuple_size<T>
{};

template<typename T>
struct list_size<const T> : list_size<T>
{};

template<typename T>
struct list_size<volatile T> : list_size<T>
{};

template<typename T>
struct list_size<const volatile T> : list_size<T>
{};

template<typename... T>
struct list_size<list<T...>> : size_c<sizeof...(T)>
{};

template<typename T, T Begin, T End>
struct list_size<integer_range<T, Begin, End>> : size_c<End - Begin>
{};

template<typename T>
inline constexpr std::size_t list_size_v = list_size<T>::value;

//===========================================================================================================
// list_element
template<std::size_t I, typename T>
struct list_element : std::tuple_element<I, T>
{};

template<std::size_t I, typename T>
struct list_element<I, const T> : list_element<I, T>
{};

template<std::size_t I, typename T>
struct list_element<I, volatile T> : list_element<I, T>
{};

template<std::size_t I, typename T>
struct list_element<I, const volatile T> : list_element<I, T>
{};

template<std::size_t I, typename... T>
struct list_element<I, list<T...>> : std::tuple_element<I, std::tuple<T...>>
{};

template<std::size_t I, typename T, T Begin, T End>
struct list_element<I, integer_range<T, Begin, End>>
{
    static_assert(Begin + I < End, "Index of bounds");
    using type = std::integral_constant<T, Begin + I>;
};

template<std::size_t I, typename T>
using list_element_t = typename list_element<I, T>::type;

//===========================================================================================================
// argument
template<std::size_t I>
struct arg
{
    template<typename... T>
    using type = list_element_t<I, std::tuple<T...>>;
};

template<std::size_t I, typename... T>
using arg_t = typename arg<I>::template type<T...>;

using _0 = arg<0>; //NOLINT(readability-identifier-naming)
using _1 = arg<1>; //NOLINT(readability-identifier-naming)
using _2 = arg<2>; //NOLINT(readability-identifier-naming)
using _3 = arg<3>; //NOLINT(readability-identifier-naming)
using _4 = arg<4>; //NOLINT(readability-identifier-naming)
using _5 = arg<5>; //NOLINT(readability-identifier-naming)
using _6 = arg<6>; //NOLINT(readability-identifier-naming)
using _7 = arg<7>; //NOLINT(readability-identifier-naming)
using _8 = arg<8>; //NOLINT(readability-identifier-naming)

//===========================================================================================================
// access
template<std::size_t I, typename... T>
constexpr typename std::tuple_element<I, std::tuple<T...>>::type& acc(std::tuple<T...>& t) noexcept
{
    return std::get<I>(t);
}

template<std::size_t I, typename... T>
constexpr typename std::tuple_element<I, std::tuple<T...>>::type&& acc(std::tuple<T...>&& t) noexcept
{
    return std::get<I>(std::move(t));
}

template<std::size_t I, typename... T>
constexpr const typename std::tuple_element<I, std::tuple<T...>>::type& acc(const std::tuple<T...>& t) noexcept
{
    return std::get<I>(t);
}

template<std::size_t I, typename... T>
constexpr const typename std::tuple_element<I, std::tuple<T...>>::type&& acc(const std::tuple<T...>&& t) noexcept
{
    return std::get<I>(std::move(t));
}

template<std::size_t I, typename... T>
constexpr arg_t<I, T...> acc(const list<T...>& /*list*/) noexcept(std::is_nothrow_constructible<arg_t<I, T...>>::value)
{
    return arg_t<I, T...>();
}

template<std::size_t I, typename T, T Begin, T End>
constexpr std::integral_constant<T, I + Begin> acc(const integer_range<T, Begin, End>& /*range*/) noexcept
{
    return std::integral_constant<T, I + Begin>();
}

//===========================================================================================================
// bind
template<template<typename...> typename F, typename... T>
struct bind;

namespace detail {

template<typename V, typename... T>
struct evaluate_bound_arg
{
    using type = V;
};

template<std::size_t I, typename... T>
struct evaluate_bound_arg<arg<I>, T...>
{
    using type = arg_t<I, T...>;
};

template<template<typename...> typename F, typename... U, typename... T>
struct evaluate_bound_arg<bind<F, U...>, T...>
{
    using type = typename bind<F, U...>::template type<T...>;
};

} // namespace detail

template<template<typename...> typename F, typename... T>
struct bind
{
    template<typename... U>
    using type = F<typename detail::evaluate_bound_arg<T, U...>::type...>;
};

//===========================================================================================================
// rename
namespace detail {

template<typename A, template<typename...> typename B>
struct rename_impl
{
    static_assert(dependent_false_v<A>, "First argument has to be a list");
};

template<template<typename...> typename A, typename... T, template<typename...> typename B>
struct rename_impl<A<T...>, B>
{
    using type = B<T...>;
};

} // namespace detail

template<typename A, template<typename...> typename B>
using rename = detail::rename_impl<A, B>;

template<typename A, template<typename...> typename B>
using rename_t = typename rename<A, B>::type;

//===========================================================================================================
// apply

template<template<typename...> typename F, typename L>
using apply = rename<L, F>;

template<template<typename...> typename F, typename L>
using apply_t = typename apply<F, L>::type;

//===========================================================================================================
// append
namespace detail {

template<typename... L>
struct append_impl;

template<>
struct append_impl<>
{
    using type = list<>;
};

template<template<typename...> typename L, typename... T>
struct append_impl<L<T...>>
{
    using type = L<T...>;
};

template<template<typename...> typename L1, typename... T1, template<typename...> typename L2, typename... T2, typename... Lr>
struct append_impl<L1<T1...>, L2<T2...>, Lr...>
{
    using type = typename append_impl<L1<T1..., T2...>, Lr...>::type;
};

} // namespace detail

template<typename... L>
using append = detail::append_impl<L...>;

template<typename... L>
using append_t = typename append<L...>::type;

//===========================================================================================================
// push_front
namespace detail {

template<typename L, typename... T>
struct push_front_impl
{
    static_assert(dependent_false_v<L>, "First argument has to be a list");
};

template<template<typename...> typename L, typename... U, typename... T>
struct push_front_impl<L<U...>, T...>
{
    using type = L<T..., U...>;
};

} // namespace detail

template<typename L, typename... T>
using push_front = detail::push_front_impl<L, T...>;

template<typename L, typename... T>
using push_front_t = typename push_front<L, T...>::type;

//===========================================================================================================
// push_back
namespace detail {

template<typename L, typename... T>
struct push_back_impl
{
    static_assert(dependent_false_v<L>, "First argument has to be a list");
};

template<template<typename...> typename L, typename... U, typename... T>
struct push_back_impl<L<U...>, T...>
{
    using type = L<U..., T...>;
};

} // namespace detail

template<typename L, typename... T>
using push_back = detail::push_back_impl<L, T...>;

template<typename L, typename... T>
using push_back_t = typename push_back<L, T...>::type;

//===========================================================================================================
// pop_front
namespace detail {

template<typename L>
struct pop_front_impl {}; // An empty list will fail here

template<template<typename...> typename L, typename T1, typename... T>
struct pop_front_impl<L<T1, T...>>
{
    using type = L<T...>;
};

} // namespace detail

template<typename L>
using pop_front = detail::pop_front_impl<L>;

template<typename L>
using pop_front_t = typename pop_front<L>::type;

//===========================================================================================================
// assign
namespace detail {

template<typename L1, typename L2>
struct assign_impl;

template<template<typename...> typename L1, typename... T, template<typename...> typename L2, typename... U>
struct assign_impl<L1<T...>, L2<U...>>
{
    using type = L1<U...>;
};

} // namespace detail

template<typename L1, typename L2>
using assign = detail::assign_impl<L1, L2>;

template<typename L1, typename L2>
using assign_t = typename assign<L1, L2>::type;

//===========================================================================================================
// transform
namespace detail {

template<template<typename...> typename F, typename... L>
struct transform_impl
{};

template<template<typename...> typename F, template<typename...> typename L, typename... T>
struct transform_impl<F, L<T...>>
{
    using type = L<F<T>...>;
};

} // namespace detail

template<template<typename...> typename F, typename... L>
using transform = detail::transform_impl<F, L...>;

template<template<typename...> typename F, typename... L>
using transform_t = typename transform<F, L...>::type;

//===========================================================================================================
// reverse
namespace detail {

template<typename L>
struct reverse_impl;

template<template<typename...> typename L>
struct reverse_impl<L<>>
{
    using type = L<>;
};

template<template<typename...> typename L, typename T1>
struct reverse_impl<L<T1>>
{
    using type = L<T1>;
};

template<template<typename...> typename L, typename T1, typename T2>
struct reverse_impl<L<T1, T2>>
{
    using type = L<T2, T1>;
};

template<template<typename...> typename L, typename T1, typename T2, typename T3>
struct reverse_impl<L<T1, T2, T3>>
{
    using type = L<T3, T2, T1>;
};

template<template<typename...> typename L, typename T1, typename T2, typename T3, typename T4>
struct reverse_impl<L<T1, T2, T3, T4>>
{
    using type = L<T4, T3, T2, T1>;
};

template<template<typename...> typename L, typename T1, typename T2, typename T3, typename T4, typename T5>
struct reverse_impl<L<T1, T2, T3, T4, T5>>
{
    using type = L<T5, T4, T3, T2, T1>;
};

template<template<typename...> typename L, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6>
struct reverse_impl<L<T1, T2, T3, T4, T5, T6>>
{
    using type = L<T6, T5, T4, T3, T2, T1>;
};

template<template<typename...> typename L, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7>
struct reverse_impl<L<T1, T2, T3, T4, T5, T6, T7>>
{
    using type = L<T7, T6, T5, T4, T3, T2, T1>;
};

template<template<typename...> typename L, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7, typename T8>
struct reverse_impl<L<T1, T2, T3, T4, T5, T6, T7, T8>>
{
    using type = L<T8, T7, T6, T5, T4, T3, T2, T1>;
};

template<template<typename...> typename L, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7, typename T8, typename T9>
struct reverse_impl<L<T1, T2, T3, T4, T5, T6, T7, T8, T9>>
{
    using type = L<T9, T8, T7, T6, T5, T4, T3, T2, T1>;
};

template<template<typename...> typename L, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7, typename T8, typename T9, typename T10, typename... T>
struct reverse_impl<L<T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T...>>
{
    using type = push_back_t<typename reverse_impl<L<T...>>::type, T10, T9, T8, T7, T6, T5, T4, T3, T2, T1>;
};

} // namespace detail

template<typename L>
using reverse = detail::reverse_impl<L>;

template<typename L>
using reverse_t = typename reverse<L>::type;

//===========================================================================================================
// accumulate
namespace detail {

template<typename L, typename V, template<typename...> typename F>
struct accumulate_impl
{
    static_assert(dependent_false_v<L>, "L has to be a list argument");
};

template<template<typename...> typename L, typename V, template<typename...> typename F>
struct accumulate_impl<L<>, V, F>
{
    using type = V;
};

template<template<typename...> typename L, typename T1, typename... T, typename V, template<typename...> typename F>
struct accumulate_impl<L<T1, T...>, V, F>
{
    using type = typename accumulate_impl<L<T...>, F<V, T1>, F>::type;
};

} // namespace detail

template<template<typename...> typename F, typename V, typename L>
using accumulate = detail::accumulate_impl<L, V, F>;

template<template<typename...> typename F, typename V, typename L>
using accumulate_t = typename accumulate<F, V, L>::type;

//===========================================================================================================
// count_if
namespace detail {

template<typename L, template<typename...> typename P>
struct count_if_impl;

template<template<typename...> typename L, typename... T, template<typename...> typename P>
struct count_if_impl<L<T...>, P>
{
    using type = size_c<(P<T>::value + ... + 0)>;
};

} // namespace detail

template<typename L, template<typename...> typename P>
using count_if = detail::count_if_impl<L, P>;

template<typename L, template<typename...> typename P>
using count_if_t = typename count_if<L, P>::type;

template<typename L, template<typename...> typename P>
inline constexpr std::size_t count_if_v = count_if_t<L, P>::value;

//===========================================================================================================
// product
namespace detail {

template<template<typename...> typename F, typename P, typename... L>
struct product_impl_2;

template<template<typename...> typename F, typename P>
struct product_impl_2<F, P>
{
    using type = list<rename_t<P, F>>;
};

template<template<typename...> typename F, typename P, template<typename...> typename L1, typename... T1, typename... L>
struct product_impl_2<F, P, L1<T1...>, L...>
{
    using type = append_t<typename product_impl_2<F, push_back_t<P, T1>, L...>::type...>;
};

template<template<typename...> typename F, typename... L>
struct product_impl;

template<template<typename...> typename F, typename L1, typename... L>
struct product_impl<F, L1, L...>
{
    using type = assign_t<L1, typename product_impl_2<F, list<>, L1, L...>::type>;
};

} // namespace detail

template<template<typename...> typename F, typename... L>
using product = detail::product_impl<F, L...>;

template<template<typename...> typename F, typename... L>
using product_t = typename product<F, L...>::type;

//===========================================================================================================
// find_if
namespace detail {

struct index_holder
{
    std::size_t i_;
    bool        f_;
};

constexpr inline index_holder operator+(const index_holder& v, bool f)
{
    if(v.f_) return v;
    if(f) return {v.i_, true};
    return {v.i_ + 1, false};
}

template<typename L, template<typename...> typename P>
struct find_if_impl;

template<template<typename...> typename L, typename... T, template<typename...> typename P>
struct find_if_impl<L<T...>, P>
{
    static constexpr index_holder v{0, false};
    using type = size_c<(v + ... + P<T>::value).i_>;
};

} // namespace detail

template<typename L, template<typename...> typename P>
using find_if = detail::find_if_impl<L, P>;

template<typename L, template<typename...> typename P>
using find_if_t = typename find_if<L, P>::type;

template<typename L, template<typename...> typename P>
inline constexpr std::size_t find_if_v = find_if_t<L, P>::value;

//===========================================================================================================
// set_contains
namespace detail {

template<typename S, typename V>
struct set_contains_impl;

template<template<typename...> typename L, typename... T, typename V>
struct set_contains_impl<L<T...>, V>
{
    using type = to_bool<std::is_base_of<identity<V>, inherit<identity<T>...>>>;
};

} // namespace detail

template<typename S, typename V>
using set_contains = detail::set_contains_impl<S, V>;

template<typename S, typename V>
using set_contains_t = typename set_contains<S, V>::type;

template<typename S, typename V>
inline constexpr bool set_contains_v = set_contains_t<S, V>::value;

//===========================================================================================================
// set_push_back
namespace detail {

template<typename S, typename... T>
struct set_push_back_impl;

template<template<typename...> typename L, typename... U>
struct set_push_back_impl<L<U...>>
{
    using type = L<U...>;
};

template<template<typename...> typename L, typename... U, typename T1, typename... T>
struct set_push_back_impl<L<U...>, T1, T...>
{
    using new_set = std::conditional_t<set_contains_v<L<U...>, T1>, L<U...>, L<U..., T1>>;
    using type    = typename set_push_back_impl<new_set, T...>::type;
};

} // namespace detail

template<typename S, typename... T>
using set_push_back = detail::set_push_back_impl<S, T...>;

template<typename S, typename... T>
using set_push_back_t = typename set_push_back<S, T...>::type;

//===========================================================================================================
// unique
namespace detail {

template<typename L>
struct unique_impl;

template<template<typename...> typename L, typename... T>
struct unique_impl<L<T...>>
{
    using type = rename_t<set_push_back_t<list<>, T...>, L>;
};

} // namespace detail

template<typename L>
using unique = detail::unique_impl<L>;

template<typename L>
using unique_t = typename unique<L>::type;

//===========================================================================================================
// for_each
namespace detail {

template<typename Seq, typename F, std::size_t... Indices>
void for_each_impl(Seq&& seq, F&& f, std::index_sequence<Indices...> /*indices*/)
{
    using swallow = int[]; // NOLINT(cppcoreguidelines-avoid-c-arrays, modernize-avoid-c-arrays)
    (void)swallow{1, (f(xyfund::mp::acc<Indices>(std::forward<Seq>(seq))), void(), int{})...};
}

} // namespace detail

template<typename Seq, typename F>
void for_each(Seq&& seq, F&& f)
{
    constexpr auto n = xyfund::mp::list_size_v<std::remove_reference_t<Seq>>;
    detail::for_each_impl(std::forward<Seq>(seq), std::forward<F>(f), std::make_index_sequence<n>{});
}

} // namespace mp

} // namespace xyfund

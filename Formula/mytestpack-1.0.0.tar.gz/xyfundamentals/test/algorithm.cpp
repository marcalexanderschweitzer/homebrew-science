//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <gtest/gtest.h>

#include <xyfund/algorithm.hpp>

namespace {

template<typename T>
bool equal_span(const xyfund::span<T>& lhs, const xyfund::span<T>& rhs)
{
    return lhs.data() == rhs.data() &&
        lhs.size() == rhs.size();
}

} // namespace

TEST(AsLiteral, Basic) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    std::string          str      = "ABC";
    const std::string    str_c    = "ABC";
    std::wstring         wstr     = L"ABC";
    const std::wstring   wstr_c   = L"ABC";
    std::u16string       u16str   = u"ABC";
    const std::u16string u16str_c = u"ABC";
    std::u32string       u32str   = U"ABC";
    const std::u32string u32str_c = U"ABC";

    ASSERT_TRUE(equal_span(xyfund::as_literal(str), xyfund::span<char>(str)));
    ASSERT_TRUE(equal_span(xyfund::as_literal(str_c), xyfund::span<const char>(str_c)));

    ASSERT_TRUE(equal_span(xyfund::as_literal(wstr), xyfund::span<wchar_t>(wstr)));
    ASSERT_TRUE(equal_span(xyfund::as_literal(wstr_c), xyfund::span<const wchar_t>(wstr_c)));

    ASSERT_TRUE(equal_span(xyfund::as_literal(u16str), xyfund::span<char16_t>(u16str)));
    ASSERT_TRUE(equal_span(xyfund::as_literal(u16str_c), xyfund::span<const char16_t>(u16str_c)));

    ASSERT_TRUE(equal_span(xyfund::as_literal(u32str), xyfund::span<char32_t>(u32str)));
    ASSERT_TRUE(equal_span(xyfund::as_literal(u32str_c), xyfund::span<const char32_t>(u32str_c)));

    ASSERT_TRUE(equal_span(xyfund::as_literal(str.data()), xyfund::span<char>(str)));
    ASSERT_TRUE(equal_span(xyfund::as_literal(str_c.data()), xyfund::span<const char>(str_c)));

    ASSERT_TRUE(equal_span(xyfund::as_literal(wstr.data()), xyfund::span<wchar_t>(wstr)));
    ASSERT_TRUE(equal_span(xyfund::as_literal(wstr_c.data()), xyfund::span<const wchar_t>(wstr_c)));

    ASSERT_TRUE(equal_span(xyfund::as_literal(u16str.data()), xyfund::span<char16_t>(u16str)));
    ASSERT_TRUE(equal_span(xyfund::as_literal(u16str_c.data()), xyfund::span<const char16_t>(u16str_c)));

    ASSERT_TRUE(equal_span(xyfund::as_literal(u32str.data()), xyfund::span<char32_t>(u32str)));
    ASSERT_TRUE(equal_span(xyfund::as_literal(u32str_c.data()), xyfund::span<const char32_t>(u32str_c)));
}

TEST(Equals, Basic) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const std::string ABC  = "ABC";  //NOLINT(readability-identifier-naming)
    const std::string ABD  = "ABD";  //NOLINT(readability-identifier-naming)
    const std::string ABCD = "ABCD"; //NOLINT(readability-identifier-naming)
    const std::string abc  = "abc";  //NOLINT(readability-identifier-naming)
    const std::string aBc  = "aBc";  //NOLINT(readability-identifier-naming)

    ASSERT_TRUE(xyfund::equals("ABC", "ABC"));
    ASSERT_TRUE(xyfund::equals("abc", "abc"));
    ASSERT_FALSE(xyfund::equals("ABC", "abc"));
    ASSERT_FALSE(xyfund::equals("abc", "ABC"));
    ASSERT_FALSE(xyfund::equals("ABC", "aBc"));
    ASSERT_FALSE(xyfund::equals("aBc", "ABC"));

    ASSERT_TRUE(xyfund::equals(ABC, "ABC"));
    ASSERT_TRUE(xyfund::equals(abc, "abc"));
    ASSERT_FALSE(xyfund::equals(ABC, "abc"));
    ASSERT_FALSE(xyfund::equals(abc, "ABC"));
    ASSERT_FALSE(xyfund::equals(ABC, "aBc"));
    ASSERT_FALSE(xyfund::equals(aBc, "ABC"));

    ASSERT_TRUE(xyfund::equals("ABC", ABC));
    ASSERT_TRUE(xyfund::equals("abc", abc));
    ASSERT_FALSE(xyfund::equals("ABC", abc));
    ASSERT_FALSE(xyfund::equals("abc", ABC));
    ASSERT_FALSE(xyfund::equals("ABC", aBc));
    ASSERT_FALSE(xyfund::equals("aBc", ABC));

    ASSERT_TRUE(xyfund::equals(ABC, ABC));
    ASSERT_TRUE(xyfund::equals(abc, abc));
    ASSERT_FALSE(xyfund::equals(ABC, abc));
    ASSERT_FALSE(xyfund::equals(abc, ABC));
    ASSERT_FALSE(xyfund::equals(ABC, aBc));
    ASSERT_FALSE(xyfund::equals(aBc, ABC));

    ASSERT_FALSE(xyfund::equals("ABCD", "ABC"));
    ASSERT_FALSE(xyfund::equals("ABC", "ABCD"));
    ASSERT_FALSE(xyfund::equals("ABC", "ABD"));
    ASSERT_FALSE(xyfund::equals("ABD", "ABC"));

    ASSERT_FALSE(xyfund::equals(ABCD, "ABC"));
    ASSERT_FALSE(xyfund::equals(ABC, "ABCD"));
    ASSERT_FALSE(xyfund::equals(ABC, "ABD"));
    ASSERT_FALSE(xyfund::equals(ABD, "ABC"));

    ASSERT_FALSE(xyfund::equals("ABCD", ABC));
    ASSERT_FALSE(xyfund::equals("ABC", ABCD));
    ASSERT_FALSE(xyfund::equals("ABC", ABD));
    ASSERT_FALSE(xyfund::equals("ABD", ABC));

    ASSERT_FALSE(xyfund::equals(ABCD, ABC));
    ASSERT_FALSE(xyfund::equals(ABC, ABCD));
    ASSERT_FALSE(xyfund::equals(ABC, ABD));
    ASSERT_FALSE(xyfund::equals(ABD, ABC));
}

TEST(IEquals, Basic) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    ASSERT_TRUE(xyfund::iequals("ABC", "ABC"));
    ASSERT_TRUE(xyfund::iequals("abc", "abc"));
    ASSERT_TRUE(xyfund::iequals("ABC", "abc"));
    ASSERT_TRUE(xyfund::iequals("abc", "ABC"));
    ASSERT_TRUE(xyfund::iequals("ABC", "aBc"));
    ASSERT_TRUE(xyfund::iequals("aBc", "ABC"));

    ASSERT_FALSE(xyfund::iequals("ABCD", "ABC"));
    ASSERT_FALSE(xyfund::iequals("ABC", "ABCD"));
    ASSERT_FALSE(xyfund::iequals("ABC", "ABD"));
    ASSERT_FALSE(xyfund::iequals("ABD", "ABC"));
}

TEST(StartsWith, Basic) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const std::string ABC  = "ABC";  //NOLINT(readability-identifier-naming)
    const std::string ABCD = "ABCD"; //NOLINT(readability-identifier-naming)
    const std::string abc  = "abc";  //NOLINT(readability-identifier-naming)

    ASSERT_TRUE(xyfund::starts_with("ABCD", "ABC"));
    ASSERT_TRUE(xyfund::starts_with("ABC", "ABC"));
    ASSERT_FALSE(xyfund::starts_with("ABC", "ABCD"));
    ASSERT_FALSE(xyfund::starts_with("ABCD", "abc"));

    ASSERT_TRUE(xyfund::starts_with(ABCD, "ABC"));
    ASSERT_TRUE(xyfund::starts_with(ABC, "ABC"));
    ASSERT_FALSE(xyfund::starts_with(ABC, "ABCD"));
    ASSERT_FALSE(xyfund::starts_with(ABCD, "abc"));

    ASSERT_TRUE(xyfund::starts_with("ABCD", ABC));
    ASSERT_TRUE(xyfund::starts_with("ABC", ABC));
    ASSERT_FALSE(xyfund::starts_with("ABC", ABCD));
    ASSERT_FALSE(xyfund::starts_with("ABCD", abc));

    ASSERT_TRUE(xyfund::starts_with(ABCD, ABC));
    ASSERT_TRUE(xyfund::starts_with(ABC, ABC));
    ASSERT_FALSE(xyfund::starts_with(ABC, ABCD));
    ASSERT_FALSE(xyfund::starts_with(ABCD, abc));
}

TEST(IStartsWith, Basic) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    ASSERT_TRUE(xyfund::istarts_with("ABCD", "ABC"));
    ASSERT_TRUE(xyfund::istarts_with("ABC", "ABC"));
    ASSERT_FALSE(xyfund::istarts_with("ABC", "ABCD"));
    ASSERT_TRUE(xyfund::istarts_with("ABCD", "abc"));
}

TEST(EndsWith, Basic) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const std::string BCD  = "BCD";  //NOLINT(readability-identifier-naming)
    const std::string ABCD = "ABCD"; //NOLINT(readability-identifier-naming)
    const std::string bcd  = "bcd";  //NOLINT(readability-identifier-naming)

    ASSERT_TRUE(xyfund::ends_with("ABCD", "BCD"));
    ASSERT_TRUE(xyfund::ends_with("BCD", "BCD"));
    ASSERT_FALSE(xyfund::ends_with("BCD", "ABCD"));
    ASSERT_FALSE(xyfund::ends_with("ABCD", "bcd"));

    ASSERT_TRUE(xyfund::ends_with(ABCD, "BCD"));
    ASSERT_TRUE(xyfund::ends_with(BCD, "BCD"));
    ASSERT_FALSE(xyfund::ends_with(BCD, "ABCD"));
    ASSERT_FALSE(xyfund::ends_with(ABCD, "bcd"));

    ASSERT_TRUE(xyfund::ends_with("ABCD", BCD));
    ASSERT_TRUE(xyfund::ends_with("BCD", BCD));
    ASSERT_FALSE(xyfund::ends_with("BCD", ABCD));
    ASSERT_FALSE(xyfund::ends_with("ABCD", bcd));

    ASSERT_TRUE(xyfund::ends_with(ABCD, BCD));
    ASSERT_TRUE(xyfund::ends_with(BCD, BCD));
    ASSERT_FALSE(xyfund::ends_with(BCD, ABCD));
    ASSERT_FALSE(xyfund::ends_with(ABCD, bcd));
}

TEST(IEndsWith, Basic) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    ASSERT_TRUE(xyfund::iends_with("ABCD", "BCD"));
    ASSERT_TRUE(xyfund::iends_with("ABC", "ABC"));
    ASSERT_FALSE(xyfund::iends_with("BCD", "ABCD"));
    ASSERT_TRUE(xyfund::iends_with("ABCD", "bcd"));
}

TEST(Join, Strings) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    EXPECT_STREQ(xyfund::join(std::vector<std::string>{}, ";").c_str(), "");
    EXPECT_STREQ(xyfund::join(std::vector<std::string>{"A"}, ";").c_str(), "A");
    EXPECT_STREQ(xyfund::join(std::vector<std::string>{"A", "B"}, ";").c_str(), "A;B");
    EXPECT_STREQ(xyfund::join(std::vector<std::string>{"A", "B", "C"}, ";").c_str(), "A;B;C");

    EXPECT_STREQ(xyfund::join(std::vector<std::string>{}, " - ").c_str(), "");
    EXPECT_STREQ(xyfund::join(std::vector<std::string>{"A"}, " - ").c_str(), "A");
    EXPECT_STREQ(xyfund::join(std::vector<std::string>{"A", "B"}, " - ").c_str(), "A - B");
    EXPECT_STREQ(xyfund::join(std::vector<std::string>{"A", "B", "C"}, " - ").c_str(), "A - B - C");
}

TEST(ForEach, Tuple) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const std::tuple<int, double, std::string> original_data = {1, 1.23, "abc"};
    std::tuple<int, double, std::string>       data;

    xyfund::for_each(original_data, [&data](const auto& entry) {
        std::get<std::decay_t<decltype(entry)>>(data) = entry;
    });

    ASSERT_TRUE(data == original_data);
}

TEST(ForEachWithIndex, Tuple) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const std::tuple<int, double, std::string> original_data = {1, 1.23, "abc"};
    std::tuple<int, double, std::string>       data;

    xyfund::for_each_with_index(original_data, [&data](const auto index, const auto& entry) {
        std::get<decltype(index)::value>(data) = entry;
    });

    ASSERT_TRUE(data == original_data);
}

#ifdef _WIN32
TEST(Unicode, Utf8ToUtf16) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const auto utf16 = xyfund::utf8_to_utf16("");
    (void)utf16;
}

TEST(Unicode, Utf16ToUtf8) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const auto utf8 = xyfund::utf16_to_utf8(L"");
    (void)utf8;
}
#endif // _WIN32

TEST(RemoveDuplicates, General) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const std::vector<int> original = {5, 6, 12, 5, 48, 46, 6, 5, 9, 12};

    auto v = original;

    xyfund::remove_duplicates(v);

    for(const auto entry : original)
    {
        ASSERT_TRUE(std::count(v.begin(), v.end(), entry) == 1);
    }
}

TEST(RemoveDuplicates, GeneralWithPredicates) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const std::vector<int> original = {5, 6, 12, 5, 48, 46, 6, 5, 9, 12};

    auto v = original;

    xyfund::remove_duplicates(
        v, [](int a, int b) { return a < b; }, [](int a, int b) { return a == b; });

    for(const auto entry : original)
    {
        ASSERT_TRUE(std::count(v.begin(), v.end(), entry) == 1);
    }
}

TEST(RemoveDuplicates, Stable) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    std::vector<int>       v = {5, 6, 12, 5, 48, 46, 6, 5, 9, 12};
    const std::vector<int> e = {5, 6, 12, 48, 46, 9};

    xyfund::stable_remove_duplicates(v);

    ASSERT_TRUE(std::equal(v.begin(), v.end(), e.begin(), e.end()));
}

TEST(MakeTuple, Basic) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    auto       t   = std::tuple<int>(1);
    auto       t2  = std::tuple<int>(15);
    const auto ct  = t;
    const auto ct2 = t2;

    ASSERT_TRUE(xyfund::make_tuple(1) == ct);
    ASSERT_TRUE(xyfund::make_tuple(15) != ct);
    ASSERT_TRUE(xyfund::make_tuple(std::tuple<int>(1)) == ct);
    ASSERT_TRUE(xyfund::make_tuple(std::tuple<int>(15)) != ct);
    ASSERT_TRUE(xyfund::make_tuple(t) == ct);
    ASSERT_TRUE(xyfund::make_tuple(ct) == ct);
    ASSERT_TRUE(xyfund::make_tuple(t2) != ct);
    ASSERT_TRUE(xyfund::make_tuple(ct2) != ct);
}

TEST(Contains, Set) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const std::set<int> set = {1, 5, 8, 125};

    ASSERT_TRUE(xyfund::contains(set, 1));
    ASSERT_TRUE(xyfund::contains(set, 5));
    ASSERT_TRUE(xyfund::contains(set, 8));
    ASSERT_TRUE(xyfund::contains(set, 125));

    ASSERT_FALSE(xyfund::contains(set, 4));
    ASSERT_FALSE(xyfund::contains(set, -15));
}

TEST(Contains, Map) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const std::map<int, std::string> map = {{1, "a"}, {5, "b"}, {8, "c"}, {125, "d"}};

    ASSERT_TRUE(xyfund::contains(map, 1));
    ASSERT_TRUE(xyfund::contains(map, 5));
    ASSERT_TRUE(xyfund::contains(map, 8));
    ASSERT_TRUE(xyfund::contains(map, 125));

    ASSERT_FALSE(xyfund::contains(map, 4));
    ASSERT_FALSE(xyfund::contains(map, -15));
}

TEST(IsEven, Basic) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    ASSERT_TRUE(xyfund::is_even(0));
    ASSERT_FALSE(xyfund::is_even(1));
    ASSERT_TRUE(xyfund::is_even(2));
}

TEST(IsOdd, Basic) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    ASSERT_FALSE(xyfund::is_odd(0));
    ASSERT_TRUE(xyfund::is_odd(1));
    ASSERT_FALSE(xyfund::is_odd(2));
}

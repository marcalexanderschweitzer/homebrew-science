//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <gtest/gtest.h>

#include <xyfund/scope.hpp>

TEST(ScopeExit, Execute) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    std::ostringstream out;
    {
        auto guard = xyfund::make_scope_exit([&] { out << "done\n"; });
    }
    ASSERT_EQ("done\n", out.str());
}

TEST(ScopeExit, Release) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    std::ostringstream out;
    {
        auto guard = xyfund::make_scope_exit([&] { out << "done\n"; });
        guard.release();
    }
    ASSERT_EQ("", out.str());
}

TEST(ScopeExit, Move) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    std::ostringstream out;
    {
        auto guard  = xyfund::make_scope_exit([&] { out << "done\n"; });
        auto guard2 = std::move(guard);
    }
    ASSERT_EQ("done\n", out.str());
}

TEST(ScopeExit, MoveRelease) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    std::ostringstream out;
    {
        auto guard  = xyfund::make_scope_exit([&] { out << "done\n"; });
        auto guard2 = std::move(guard);
        guard2.release();
    }
    ASSERT_EQ("", out.str());
}
//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <gtest/gtest.h>

#include <mutex>

#include <xyfund/interprocess.hpp>

TEST(FileLock, Create) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const auto test_file_path = xyfund::filesystem::path("create.lock");
    if(xyfund::filesystem::exists(test_file_path))
    {
        xyfund::filesystem::remove(test_file_path);
    }
    {
        xyfund::filesystem::ofstream lock_file(test_file_path, std::iostream::out);
    }

    xyfund::interprocess::file_lock lock(test_file_path);
}

TEST(FileLock, LockAndUnlock) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const auto test_file_path = xyfund::filesystem::path("lock_and_unlock.lock");
    if(xyfund::filesystem::exists(test_file_path))
    {
        xyfund::filesystem::remove(test_file_path);
    }
    {
        xyfund::filesystem::ofstream lock_file(test_file_path, std::iostream::out);
    }

    xyfund::interprocess::file_lock lock(test_file_path);

    lock.lock();

    lock.unlock();
}

TEST(FileLock, Guard) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const auto test_file_path = xyfund::filesystem::path("lock_guard.lock");
    if(xyfund::filesystem::exists(test_file_path))
    {
        xyfund::filesystem::remove(test_file_path);
    }
    {
        xyfund::filesystem::ofstream lock_file(test_file_path, std::iostream::out);
    }

    xyfund::interprocess::file_lock lock(test_file_path);

    {
        std::lock_guard<xyfund::interprocess::file_lock> guard(lock);
    }
}

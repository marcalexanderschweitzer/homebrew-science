//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <chrono>
#include <numeric>
#include <thread>

#include <gtest/gtest.h>

#ifdef _WIN32
// Include Windows.h to test whether the code compiles with defines like `pascal` from `minwindef.h`
#   include <Windows.h>
#   undef pascal
#endif

#include <xyfund/units.hpp>

#include <xyfund/math/pow.hpp>

using namespace xyfund;
using namespace xyfund::units;
using namespace xyfund::units::si;

constexpr auto comparison_tolerance = 1e-8;

static_assert(equals(90.0_deg, 1.57079632679_rad));
static_assert(equals(40.0_deg + 50.0_deg, 1.57079632679_rad));

static_assert(equals(90_deg + 1.57079632679_rad, 180_deg, 1e-8));
static_assert(equals(90_deg - 1.57079632679_rad, 0_deg));

static_assert(equals(1000_m, 1_km));
static_assert(equals(0.5_km, 500_m));

static_assert(equals(0.5_km + 200_m, 0.7_km));
static_assert(equals(200_m + 0.5_km, 700_m));
static_assert(equals(0_cm + 0.5_km, 50000_cm));
static_assert(equals(0.5_km - 200_m, 0.3_km));

TEST(Units, Identity) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    transformation::identity id;

    EXPECT_TRUE(id.is_integral());

    constexpr auto is_correct_inverse = std::is_same_v<decltype(id.inverse()), transformation::identity>; // NOLINT(readability-static-accessed-through-instance)
    EXPECT_TRUE(is_correct_inverse);

    constexpr auto is_correct_type = std::is_same_v<decltype(transformation::identity::get()), transformation::identity>;

    EXPECT_TRUE(is_correct_type);

    const auto value = 1.34;

    const auto result = id.apply(value); // NOLINT(readability-static-accessed-through-instance)

    EXPECT_EQ(result, value);

    std::ostringstream out;

    out << id;

    EXPECT_EQ(out.str(), "id");
}

TEST(Units, Ratio) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    transformation::ratio<-8, 5>       ratio1;
    transformation::ratio<13, 4>       ratio2;
    transformation::ratio<4, 3, 1, 3>  ratio3;
    transformation::ratio<7, 8, -1, 1> ratio4;
    transformation::ratio<11, 4>       ratio5;
    transformation::ratio<3, 7>        ratio6;
    transformation::ratio<-5, 8>       ratio7;
    transformation::ratio<12, 4>       ratio8;
    transformation::ratio<-3, 7>       ratio9;

    EXPECT_FALSE(ratio1.is_integral());
    EXPECT_FALSE(ratio3.is_integral());
    EXPECT_TRUE(ratio8.is_integral());

    std::ostringstream out;

    out << ratio4;

    EXPECT_EQ(out.str(), "7 / 8 * 10^-1 * pi^1");

    {
        const transformation::ratio<-5, 8> expected_result;

        const auto result = ratio1.inverse(); // NOLINT(readability-static-accessed-through-instance)

        EXPECT_TRUE(equals(result, expected_result));
    }

    {
        const transformation::ratio<8, 7, 1, -1> expected_result;

        const auto result = ratio4.inverse(); // NOLINT(readability-static-accessed-through-instance)

        EXPECT_TRUE(equals(result, expected_result));
    }

    {
        const transformation::ratio<1, 1> expected_result;

        const auto inverse = ratio1.inverse(); // NOLINT(readability-static-accessed-through-instance)

        const auto product1 = inverse * ratio1;
        const auto product2 = ratio1 * inverse;

        EXPECT_TRUE(equals(product1, expected_result));
        EXPECT_TRUE(equals(product2, expected_result));
    }

    {
        const transformation::ratio<-26, 5> expected_result;

        const auto product1 = ratio1 * ratio2;
        const auto product2 = ratio2 * ratio1;

        EXPECT_TRUE(equals(product1, expected_result));
        EXPECT_TRUE(equals(product2, expected_result));
    }

    {
        const transformation::ratio<13, 3, 1, 3> expected_result;

        const auto product1 = ratio2 * ratio3;
        const auto product2 = ratio3 * ratio2;

        EXPECT_TRUE(equals(product1, expected_result));
        EXPECT_TRUE(equals(product2, expected_result));
    }

    {
        transformation::ratio<89, 28> expected_result;

        const auto result = ratio5 + ratio6;

        EXPECT_TRUE(equals(result, expected_result));
    }

    {
        transformation::ratio<-11, 56> expected_result;

        const auto result = ratio6 + ratio7;

        EXPECT_TRUE(equals(result, expected_result));
    }

    {
        transformation::ratio<0> expected_result;

        const auto result = ratio6 + ratio9;

        EXPECT_TRUE(equals(result, expected_result));
    }
}

TEST(Units, Affine) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    transformation::affine<transformation::ratio<3, 7>, transformation::ratio<11, 4>>  affine1;
    transformation::affine<transformation::ratio<-8, 5>, transformation::ratio<13, 8>> affine2;

    std::ostringstream out;

    out << affine2;

    EXPECT_EQ(out.str(), "-8 / 5 * 10^0 * pi^0 * x + 13 / 8 * 10^0 * pi^0");

    {
        const auto value           = 7;
        const auto expected_result = 5.75;

        const auto result = affine1.apply(value); // NOLINT(readability-static-accessed-through-instance)

        EXPECT_NEAR(result, expected_result, comparison_tolerance);

        const auto result2 = affine1.inverse().apply(result); // NOLINT(readability-static-accessed-through-instance)

        EXPECT_NEAR(result2, value, comparison_tolerance);
    }

    {
        const auto value           = 8;
        const auto expected_result = -11.175;

        const auto result = affine2.apply(value); // NOLINT(readability-static-accessed-through-instance)

        EXPECT_NEAR(result, expected_result, comparison_tolerance);

        const auto result2 = affine2.inverse().apply(result); // NOLINT(readability-static-accessed-through-instance)

        EXPECT_NEAR(result2, value, comparison_tolerance);
    }

    {
        transformation::affine<transformation::ratio<-24, 35>, transformation::ratio<-111, 40>> expected_result;

        const auto result = affine1 * affine2;

        EXPECT_TRUE(equals(result, expected_result));
    }

    {
        transformation::affine<transformation::ratio<-24, 35>, transformation::ratio<193, 56>> expected_result;

        const auto result = affine2 * affine1;

        EXPECT_TRUE(equals(result, expected_result));
    }

    {
        transformation::affine<transformation::ratio<1, 1>, transformation::ratio<0, 1>> expected_result;

        const auto temp     = affine1 * affine2;
        const auto temp_inv = temp.inverse(); // NOLINT(readability-static-accessed-through-instance)

        const auto result1 = temp * temp_inv;
        const auto result2 = temp_inv * temp;

        EXPECT_TRUE(equals(result1, expected_result));
        EXPECT_TRUE(equals(result2, expected_result));
    }
}

TEST(Units, TransformationPower) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const auto value = 12.35;

    {
        using power = transformation::power<transformation::identity, 2>;

        EXPECT_TRUE(power::is_integral());

        const auto result = power::apply(value);

        EXPECT_EQ(result, value);

        const auto inverse = power::inverse();
        EXPECT_TRUE(inverse.is_integral());

        const auto result2 = inverse.apply(value); // NOLINT(readability-static-accessed-through-instance)

        EXPECT_EQ(result2, value);
    }

    {
        using power = transformation::power<transformation::affine<transformation::ratio<-8, 5>, transformation::ratio<13, 3>>, 3>;

        const auto expected_result = -42.0922666666;
        const auto expected_result_inverse = -0.9415690104;

        EXPECT_FALSE(power::is_integral());

        const auto result = power::apply(value);

        EXPECT_NEAR(result, expected_result, comparison_tolerance);

        const auto inverse = power::inverse();
        EXPECT_FALSE(inverse.is_integral());

        const auto result2 = inverse.apply(value); // NOLINT(readability-static-accessed-through-instance)

        EXPECT_NEAR(result2, expected_result_inverse, comparison_tolerance);
    }

    {
        using power = transformation::power<transformation::ratio<4, 3, 1, 3>, -2>;

        const auto expected_result = 0.0000722587;
        const auto expected_result_inverse = 2110783.3850053350;

        EXPECT_FALSE(power::is_integral());

        const auto result = power::apply(value);

        EXPECT_NEAR(result, expected_result, comparison_tolerance);

        const auto inverse = power::inverse();
        EXPECT_FALSE(inverse.is_integral());

        const auto result2 = inverse.apply(value); // NOLINT(readability-static-accessed-through-instance)

        EXPECT_NEAR(result2, expected_result_inverse, comparison_tolerance);
    }
}

TEST(Units, TransformationProduct) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const auto value = 12.35;

    {
        using product = transformation::product<transformation::identity>;

        EXPECT_TRUE(product::is_integral());

        const auto result = product::apply(value);

        EXPECT_EQ(result, value);

        const auto inverse = product::inverse();
        EXPECT_TRUE(inverse.is_integral());

        const auto result2 = inverse.apply(value); // NOLINT(readability-static-accessed-through-instance)

        EXPECT_EQ(result2, value);
    }

    {
        using product = transformation::product<transformation::affine<transformation::ratio<-8, 5>, transformation::ratio<13, 3>>, transformation::identity, transformation::affine<transformation::ratio<-8, 5>, transformation::ratio<13, 3>>, transformation::affine<transformation::ratio<-8, 5>, transformation::ratio<13, 3>>>;

        const auto expected_result = -42.0922666666;
        const auto expected_result_inverse = -0.9415690104;

        EXPECT_FALSE(product::is_integral());

        const auto result = product::apply(value);

        EXPECT_NEAR(result, expected_result, comparison_tolerance);

        const auto inverse = product::inverse();
        EXPECT_FALSE(inverse.is_integral());

        const auto result2 = inverse.apply(value); // NOLINT(readability-static-accessed-through-instance)

        EXPECT_NEAR(result2, expected_result_inverse, comparison_tolerance);
    }

    {
        using product = transformation::product<transformation::ratio<4, 3, 1, 3>, transformation::affine<transformation::ratio<-8, 5>, transformation::ratio<13, 3>>>;

        const auto expected_result         = -8164.7870293696;
        const auto expected_result_inverse = -0.0121195219;

        EXPECT_FALSE(product::is_integral());

        const auto result = product::apply(value);

        EXPECT_NEAR(result, expected_result, comparison_tolerance);

        const auto inverse = product::inverse();
        EXPECT_FALSE(inverse.is_integral());

        const auto result2 = inverse.apply(value); // NOLINT(readability-static-accessed-through-instance)

        EXPECT_NEAR(result2, expected_result_inverse, comparison_tolerance);
    }
}

TEST(Units, TransformationChain) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    transformation::ratio<4, 100, 0, -1>                                               ratio1;
    transformation::ratio<2, 120, 1>                                                   ratio2;
    transformation::ratio<3, 7>                                                        ratio3;
    transformation::affine<transformation::ratio<-8, 5>, transformation::ratio<13, 3>> affine;

    transformation::identity ident;

    EXPECT_TRUE(ident.is_integral());
    EXPECT_TRUE(equals(ident.inverse(), ident)); // NOLINT(readability-static-accessed-through-instance)
    EXPECT_TRUE(equals(transformation::identity::get(), ident));

    {
        const transformation::ratio<1, 1500, 1, -1> expected_result;

        const auto result = make_chain(ratio1, ratio2);

        EXPECT_TRUE(equals(result, expected_result));
    }

    {
        const auto expected_result = ratio1;

        const auto result          = make_chain(ratio1, ident);
        const auto result_switched = make_chain(ident, ratio1);

        EXPECT_TRUE(equals(result, expected_result));
        EXPECT_TRUE(equals(result_switched, expected_result));
    }

    {
        const auto expected_result = ident;

        const auto result = make_chain(ident, ident);

        EXPECT_TRUE(equals(result, expected_result));
    }

    {
        const auto expected_result = affine;

        const auto result1 = make_chain(affine, ident);
        const auto result2 = make_chain(ident, affine);

        EXPECT_TRUE(equals(result1, expected_result));
        EXPECT_TRUE(equals(result2, expected_result));
    }

    {
        const transformation::affine<transformation::ratio<-24, 35>, transformation::ratio<13, 7>> expected_result;

        const auto result1 = make_chain(ratio3, affine);
        const auto result2 = make_chain(affine, ratio3);

        EXPECT_TRUE(equals(result1, expected_result));
        EXPECT_TRUE(equals(result2, expected_result));
    }
}

TEST(Units, Length) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    EXPECT_TRUE(dim_length::symbol() == "L");
    EXPECT_TRUE(kilometer::symbol() == "km");
    EXPECT_TRUE(meter::symbol() == "m");
    EXPECT_TRUE(decimeter::symbol() == "dm");
    EXPECT_TRUE(centimeter::symbol() == "cm");
    EXPECT_TRUE(millimeter::symbol() == "mm");
    EXPECT_TRUE(micrometer::symbol() == "um");
    EXPECT_TRUE(nanometer::symbol() == "nm");

    EXPECT_TRUE(equals(1000_m, 1_km));
    EXPECT_TRUE(equals(10_dm, 1_m));
    EXPECT_TRUE(equals(10_cm, 1_dm));
    EXPECT_TRUE(equals(10_mm, 1_cm));
    EXPECT_TRUE(equals(1000_um, 1_mm));
    EXPECT_TRUE(equals(1000_nm, 1_um));

    EXPECT_TRUE(equals(1500.0_m, 1.5_km));
    EXPECT_TRUE(equals(15.0_dm, 1.5_m));
    EXPECT_TRUE(equals(15.0_cm, 1.5_dm));
    EXPECT_TRUE(equals(15.0_mm, 1.5_cm));
    EXPECT_TRUE(equals(1500.0_um, 1.5_mm));
    EXPECT_TRUE(equals(1500.0_nm, 1.5_um));

    EXPECT_TRUE(equals(0.5_km + 200_m, 0.7_km));
    EXPECT_TRUE(equals(200_m + 0.5_km, 700_m));
    EXPECT_TRUE(equals(0_cm + 0.5_km, 50000_cm));
    EXPECT_TRUE(equals(0.5_km - 200_m, 0.3_km));

    const length<kilometer, std::int64_t> length_km(4);
    const length<meter, std::int64_t>     length_m(length_km);

    EXPECT_TRUE(equals(length_m, 4000_m));

    EXPECT_EQ(length_km.count(), 4);
    EXPECT_EQ(length_m.count(), 4000);

    EXPECT_TRUE(equals(1_m * 8, 8_m));
    EXPECT_TRUE(equals(8_m / 2, 4_m));

    const length<meter, std::int64_t> minus_one_meter(-1);

    EXPECT_TRUE(equals(-(1_m), minus_one_meter));
}

TEST(Units, Time) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    EXPECT_TRUE(dim_time::symbol() == "T");
    EXPECT_TRUE(day::symbol() == "d");
    EXPECT_TRUE(hour::symbol() == "h");
    EXPECT_TRUE(second::symbol() == "s");
    EXPECT_TRUE(millisecond::symbol() == "ms");
    EXPECT_TRUE(microsecond::symbol() == "us");
    EXPECT_TRUE(nanosecond::symbol() == "ns");

    EXPECT_TRUE(equals(1_d, 24_h));
    EXPECT_TRUE(equals(1_h, 60_min));
    EXPECT_TRUE(equals(1_min, 60_s));
    EXPECT_TRUE(equals(1_s, 1000_ms));
    EXPECT_TRUE(equals(1_ms, 1000_us));
    EXPECT_TRUE(equals(1_us, 1000_ns));

    EXPECT_TRUE(equals(1.5_d, 36_h));
    EXPECT_TRUE(equals(3.5_h, 210_min));
    EXPECT_TRUE(equals(1.5_min, 90_s));
    EXPECT_TRUE(equals(1.5_s, 1500_ms));
    EXPECT_TRUE(equals(1.5_ms, 1500_us));
    EXPECT_TRUE(equals(1.5_us, 1500_ns));
    EXPECT_TRUE(equals(1.5_ns, 0.0015_us));

    EXPECT_TRUE(equals(1_d, 1440_min));
    EXPECT_TRUE(equals(1_d, 86400_s));

    EXPECT_TRUE(equals(1.5_h, 90_min));

    EXPECT_TRUE(equals(0.3_s, 300_ms));

    EXPECT_TRUE(equals(1_s + 1_min, 61_s));
    EXPECT_TRUE(equals(0.5_s + 13_ms, 0.513_s));
}

TEST(Units, Mass) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    EXPECT_TRUE(dim_mass::symbol() == "M");
    EXPECT_TRUE(kilogram::symbol() == "kg");
    EXPECT_TRUE(gram::symbol() == "g");
    EXPECT_TRUE(decigram::symbol() == "dg");
    EXPECT_TRUE(centigram::symbol() == "cg");
    EXPECT_TRUE(milligram::symbol() == "mg");
    EXPECT_TRUE(microgram::symbol() == "ug");
    EXPECT_TRUE(nanogram::symbol() == "ng");

    EXPECT_TRUE(equals(1000_g, 1_kg));
    EXPECT_TRUE(equals(10_dg, 1_g));
    EXPECT_TRUE(equals(10_cg, 1_dg));
    EXPECT_TRUE(equals(10_mg, 1_cg));
    EXPECT_TRUE(equals(1000_ug, 1_mg));
    EXPECT_TRUE(equals(1000_ng, 1_ug));

    EXPECT_TRUE(equals(1.5_kg, 1500_g));
    EXPECT_TRUE(equals(1.5_g, 15_dg));
    EXPECT_TRUE(equals(1.5_dg, 15_cg));
    EXPECT_TRUE(equals(1.5_cg, 15_mg));
    EXPECT_TRUE(equals(1.5_mg, 1500_ug));
    EXPECT_TRUE(equals(1.5_ug, 1500_ng));
    EXPECT_TRUE(equals(1.5_ng, 0.0015_ug));

    EXPECT_TRUE(equals(1_g, 1000_mg));
    EXPECT_TRUE(equals(1_dg, 100000000_ng));

    EXPECT_TRUE(equals(1.5_kg, 1500_g));

    EXPECT_TRUE(equals(0.3_g, 300_mg));

    EXPECT_TRUE(equals(1_g + 1_kg, 10010_dg));
    EXPECT_TRUE(equals(0.5_g + 13_mg, 0.513_g));
}

TEST(Units, Temperature) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    EXPECT_TRUE(dim_temperature::symbol() == "O");
    EXPECT_TRUE(kelvin::symbol() == "K");
    EXPECT_TRUE(celsius::symbol() == "C");
    EXPECT_TRUE(fahrenheit::symbol() == "F");

    EXPECT_TRUE(equals(0_K, -273.15_C));
    EXPECT_TRUE(equals(300_K, 26.85_C));
    EXPECT_TRUE(equals(4.3_C, 277.45_K));

    EXPECT_TRUE(equals(0_K, -459.67_F));
    EXPECT_TRUE(equals(300_K, 80.33_F));
    // this conversions seems to be a pretty bad case for the floating point precision, it is only correct for 3 decimal places
    EXPECT_TRUE(equals(4.3_F, 257.761_K, 1e-3));

    EXPECT_TRUE(equals(0_C, 32_F));
    EXPECT_TRUE(equals(0_F, -17.77777777777777777778_C));
    EXPECT_TRUE(equals(104_F, 40_C));
}

TEST(Units, Current) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    EXPECT_TRUE(dim_current::symbol() == "I");
    EXPECT_TRUE(kiloampere::symbol() == "kA");
    EXPECT_TRUE(ampere::symbol() == "A");
    EXPECT_TRUE(deciampere::symbol() == "dA");
    EXPECT_TRUE(centiampere::symbol() == "cA");
    EXPECT_TRUE(milliampere::symbol() == "mA");
    EXPECT_TRUE(microampere::symbol() == "uA");
    EXPECT_TRUE(nanoampere::symbol() == "nA");

    EXPECT_TRUE(equals(1000_A, 1_kA));
    EXPECT_TRUE(equals(10_dA, 1_A));
    EXPECT_TRUE(equals(10_cA, 1_dA));
    EXPECT_TRUE(equals(10_mA, 1_cA));
    EXPECT_TRUE(equals(1000_uA, 1_mA));
    EXPECT_TRUE(equals(1000_nA, 1_uA));

    EXPECT_TRUE(equals(1.5_kA, 1500_A));
    EXPECT_TRUE(equals(1.5_A, 15_dA));
    EXPECT_TRUE(equals(1.5_dA, 15_cA));
    EXPECT_TRUE(equals(1.5_cA, 15_mA));
    EXPECT_TRUE(equals(1.5_mA, 1500_uA));
    EXPECT_TRUE(equals(1.5_uA, 1500_nA));
    EXPECT_TRUE(equals(1.5_nA, 0.0015_uA));

    EXPECT_TRUE(equals(1_A, 1000_mA));
    EXPECT_TRUE(equals(1_dA, 100000000_nA));

    EXPECT_TRUE(equals(1.5_kA, 1500_A));

    EXPECT_TRUE(equals(0.3_A, 300_mA));

    EXPECT_TRUE(equals(1_A + 1_kA, 10010_dA));
    EXPECT_TRUE(equals(0.5_A + 13_mA, 0.513_A));
}

TEST(Units, AmountOfSubstance) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    EXPECT_TRUE(dim_amount_of_substance::symbol() == "N");
    EXPECT_TRUE(kilomole::symbol() == "kmol");
    EXPECT_TRUE(mole::symbol() == "mol");
    EXPECT_TRUE(decimole::symbol() == "dmol");
    EXPECT_TRUE(centimole::symbol() == "cmol");
    EXPECT_TRUE(millimole::symbol() == "mmol");
    EXPECT_TRUE(micromole::symbol() == "umol");
    EXPECT_TRUE(nanomole::symbol() == "nmol");

    EXPECT_TRUE(equals(1000_mol, 1_kmol));
    EXPECT_TRUE(equals(10_dmol, 1_mol));
    EXPECT_TRUE(equals(10_cmol, 1_dmol));
    EXPECT_TRUE(equals(10_mmol, 1_cmol));
    EXPECT_TRUE(equals(1000_umol, 1_mmol));
    EXPECT_TRUE(equals(1000_nmol, 1_umol));

    EXPECT_TRUE(equals(1.5_kmol, 1500_mol));
    EXPECT_TRUE(equals(1.5_mol, 15_dmol));
    EXPECT_TRUE(equals(1.5_dmol, 15_cmol));
    EXPECT_TRUE(equals(1.5_cmol, 15_mmol));
    EXPECT_TRUE(equals(1.5_mmol, 1500_umol));
    EXPECT_TRUE(equals(1.5_umol, 1500_nmol));
    EXPECT_TRUE(equals(1.5_nmol, 0.0015_umol));

    EXPECT_TRUE(equals(1_mol, 1000_mmol));
    EXPECT_TRUE(equals(1_dmol, 100000000_nmol));

    EXPECT_TRUE(equals(1.5_kmol, 1500_mol));

    EXPECT_TRUE(equals(0.3_mol, 300_mmol));

    EXPECT_TRUE(equals(1_mol + 1_kmol, 10010_dmol));
    EXPECT_TRUE(equals(0.5_mol + 13_mmol, 0.513_mol));
}

TEST(Units, LuminousIntensity) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    EXPECT_TRUE(dim_luminous_intensity::symbol() == "J");
    EXPECT_TRUE(kilocandela::symbol() == "kcd");
    EXPECT_TRUE(candela::symbol() == "cd");
    EXPECT_TRUE(decicandela::symbol() == "dcd");
    EXPECT_TRUE(centicandela::symbol() == "ccd");
    EXPECT_TRUE(millicandela::symbol() == "mcd");
    EXPECT_TRUE(microcandela::symbol() == "ucd");
    EXPECT_TRUE(nanocandela::symbol() == "ncd");

    EXPECT_TRUE(equals(1000_cd, 1_kcd));
    EXPECT_TRUE(equals(10_dcd, 1_cd));
    EXPECT_TRUE(equals(10_ccd, 1_dcd));
    EXPECT_TRUE(equals(10_mcd, 1_ccd));
    EXPECT_TRUE(equals(1000_ucd, 1_mcd));
    EXPECT_TRUE(equals(1000_ncd, 1_ucd));

    EXPECT_TRUE(equals(1.5_kcd, 1500_cd));
    EXPECT_TRUE(equals(1.5_cd, 15_dcd));
    EXPECT_TRUE(equals(1.5_dcd, 15_ccd));
    EXPECT_TRUE(equals(1.5_ccd, 15_mcd));
    EXPECT_TRUE(equals(1.5_mcd, 1500_ucd));
    EXPECT_TRUE(equals(1.5_ucd, 1500_ncd));
    EXPECT_TRUE(equals(1.5_ncd, 0.0015_ucd));

    EXPECT_TRUE(equals(1_cd, 1000_mcd));
    EXPECT_TRUE(equals(1_dcd, 100000000_ncd));

    EXPECT_TRUE(equals(1.5_kcd, 1500_cd));

    EXPECT_TRUE(equals(0.3_cd, 300_mcd));

    EXPECT_TRUE(equals(1_cd + 1_kcd, 10010_dcd));
    EXPECT_TRUE(equals(0.5_cd + 13_mcd, 0.513_cd));
}

TEST(Units, Degree) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    EXPECT_TRUE(dim_angle::symbol() == "A");
    EXPECT_TRUE(radian::symbol() == "rad");
    EXPECT_TRUE(degree::symbol() == "deg");

    EXPECT_TRUE(equals(1_rad, 57.29577951308_deg));
    EXPECT_TRUE(equals(1_deg, 0.01745329252_rad));

    EXPECT_TRUE(equals(90.0_deg, 1.57079632679_rad));
    EXPECT_TRUE(equals(40.0_deg + 50.0_deg, 1.57079632679_rad));

    EXPECT_TRUE(equals(90_deg + 1.57079632679_rad, 180_deg));
    EXPECT_TRUE(equals(90_deg - 1.57079632679_rad, 0_deg));
}

TEST(Units, DimensionPowers) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    using time_to_the_fourth = dimension_power<dim_time, 4>;
    using length_to_the_minus_two = dimension_power<dim_length, -2>;

    EXPECT_TRUE(time_to_the_fourth::symbol() == dim_time::symbol() + make_fixed_string("^4"));
    EXPECT_TRUE(length_to_the_minus_two::symbol() == dim_length::symbol() + make_fixed_string("^-2"));

    using expected_time_unit = unit_power<traits::unit_t<dim_time>, 4>;
    using expected_length_unit = unit_power<traits::unit_t<dim_length>, -2>;

    constexpr auto is_correct_unit1 = std::is_same_v<traits::unit_t<time_to_the_fourth>, expected_time_unit>;
    constexpr auto is_correct_unit2 = traits::is_unit_of_v<expected_time_unit, time_to_the_fourth>;
    constexpr auto is_wrong_unit1 = !std::is_same_v<traits::unit_t<time_to_the_fourth>, expected_length_unit>;
    constexpr auto is_wrong_unit2 = !traits::is_unit_of_v<expected_length_unit, time_to_the_fourth>;
    EXPECT_TRUE(is_correct_unit1);
    EXPECT_TRUE(is_correct_unit2);
    EXPECT_TRUE(is_wrong_unit1);
    EXPECT_TRUE(is_wrong_unit2);

    constexpr auto is_correct_unit3 = std::is_same_v<traits::unit_t<length_to_the_minus_two>, expected_length_unit>;
    constexpr auto is_correct_unit4 = traits::is_unit_of_v<expected_length_unit, length_to_the_minus_two>;
    constexpr auto is_wrong_unit3 = !std::is_same_v<traits::unit_t<length_to_the_minus_two>, expected_time_unit>;
    constexpr auto is_wrong_unit4 = !traits::is_unit_of_v<expected_time_unit, length_to_the_minus_two>;
    EXPECT_TRUE(is_correct_unit3);
    EXPECT_TRUE(is_correct_unit4);
    EXPECT_TRUE(is_wrong_unit3);
    EXPECT_TRUE(is_wrong_unit4);
}

TEST(Units, UnitPowers) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    using mass_to_the_third = dimension_power<dim_mass, 3>;
    using kg_to_the_third = unit_power<kilogram, 3>;

    using time_to_the_minus_one = dimension_power<dim_time, -1>;
    using microsecond_to_the_minus_one = unit_power<microsecond, -1>;

    EXPECT_TRUE(kg_to_the_third::symbol() == make_fixed_string("kg^3"));
    EXPECT_TRUE(microsecond_to_the_minus_one::symbol() == make_fixed_string("us^-1"));

    constexpr auto is_correct_unit = traits::is_unit_of_v<kg_to_the_third, mass_to_the_third>;
    constexpr auto is_wrong_unit = !traits::is_unit_of_v<microsecond_to_the_minus_one, mass_to_the_third>;
    EXPECT_TRUE(is_correct_unit);
    EXPECT_TRUE(is_wrong_unit);

    constexpr auto is_correct_unit2 = traits::is_unit_of_v<microsecond_to_the_minus_one, time_to_the_minus_one>;
    constexpr auto is_wrong_unit2 = !traits::is_unit_of_v<kg_to_the_third, time_to_the_minus_one>;
    EXPECT_TRUE(is_correct_unit2);
    EXPECT_TRUE(is_wrong_unit2);
}

TEST(Units, DerivedDimensions) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    using time_to_the_fourth = dimension_power<dim_time, 4>;
    using length_to_the_minus_two = dimension_power<dim_length, -2>;

    using dim_product = dimension_product<time_to_the_fourth, length_to_the_minus_two>;

    EXPECT_TRUE(dim_product::symbol() == time_to_the_fourth::symbol() + length_to_the_minus_two::symbol());

    using expected_time_unit = unit_power<traits::unit_t<dim_time>, 4>;
    using expected_length_unit = unit_power<traits::unit_t<dim_length>, -2>;

    using expected_unit = unit_product<expected_time_unit, expected_length_unit>;

    constexpr auto is_correct_unit = std::is_same_v<traits::unit_t<dim_product>, expected_unit>;
    constexpr auto is_correct_unit2 = traits::is_unit_of_v<expected_unit, dim_product>;

    EXPECT_TRUE(is_correct_unit);
    EXPECT_TRUE(is_correct_unit2);

    using wrong_unit = unit_product<expected_time_unit>;

    constexpr auto is_wrong_unit = !std::is_same_v<traits::unit_t<dim_product>, wrong_unit>;
    constexpr auto is_wrong_unit2 = !traits::is_unit_of_v<wrong_unit, dim_product>;

    EXPECT_TRUE(is_wrong_unit);
    EXPECT_TRUE(is_wrong_unit2);
}

TEST(Units, DerivedUnits) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    using time_to_the_fourth = dimension_power<dim_time, 4>;
    using length_to_the_minus_two = dimension_power<dim_length, -2>;

    using dim_product = dimension_product<length_to_the_minus_two, time_to_the_fourth>;

    using minutes_to_the_fourth = unit_power<minute, 4>;
    using kilometer_to_the_minus_two = unit_power<kilometer, -2>;

    using unit_prod = unit_product<kilometer_to_the_minus_two, minutes_to_the_fourth>;
    using wrong_unit_prod = unit_product<minutes_to_the_fourth, kilometer_to_the_minus_two>;

    EXPECT_TRUE(unit_prod::symbol() == make_fixed_string("km^-2min^4"));

    constexpr auto is_correct_unit = traits::is_unit_of_v<unit_prod, dim_product>;
    constexpr auto is_wrong_unit = !traits::is_unit_of_v<wrong_unit_prod, dim_product>;
    EXPECT_TRUE(is_correct_unit);
    EXPECT_TRUE(is_wrong_unit);
}

TEST(Units, DerivedQuantities) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    using time_to_the_fourth = dimension_power<dim_time, 4>;
    using length_to_the_minus_two = dimension_power<dim_length, -2>;

    using dim_product = dimension_product<length_to_the_minus_two, time_to_the_fourth>;

    using minutes_to_the_fourth = unit_power<minute, 4>;
    using kilometer_to_the_minus_two = unit_power<kilometer, -2>;

    using milliseconds_to_the_fourth = unit_power<millisecond, 4>;
    using nanometer_to_the_minus_two = unit_power<nanometer, -2>;

    using day_to_the_fourth = unit_power<hour, 4>;
    using meter_to_the_minus_two = unit_power<meter, -2>;

    using unit_prod = unit_product<kilometer_to_the_minus_two, minutes_to_the_fourth>;
    using unit_prod2 = unit_product<nanometer_to_the_minus_two, milliseconds_to_the_fourth>;

    const auto value = quantity<dim_product, unit_prod, double>(12.34);
    const auto transformed_value = quantity<dim_product, unit_prod2, double>(value);

    EXPECT_NEAR(transformed_value.count(), 1.599264e-4, comparison_tolerance);
    EXPECT_TRUE(equals(value, transformed_value));

    using unit_prod3 = unit_product<meter_to_the_minus_two, day_to_the_fourth>;

    const auto transformed_value2 = quantity_cast<unit_prod3>(transformed_value);
    EXPECT_NEAR(static_cast<double>(transformed_value2.count()), 9.5216e-13, comparison_tolerance);
    EXPECT_TRUE(equals(transformed_value2, value));
    EXPECT_TRUE(equals(transformed_value2, transformed_value));

    const auto partial_replace_value = replace_base_unit<decimeter>(value);

    using result_quantity = decltype(partial_replace_value);
    using result_dimension = traits::dimension_t<result_quantity>;
    using result_unit = traits::unit_t<result_quantity>;

    using decimeter_to_the_minus_two = unit_power<decimeter, -2>;
    using expected_unit = unit_product<decimeter_to_the_minus_two, minutes_to_the_fourth>;

    constexpr auto is_correct_dimension = std::is_same_v<result_dimension, dim_product>;
    EXPECT_TRUE(is_correct_dimension);

    constexpr auto is_correct_unit = std::is_same_v<result_unit, expected_unit>;
    EXPECT_TRUE(is_correct_unit);

    EXPECT_NEAR(static_cast<double>(partial_replace_value.count()), 1.234e-7, comparison_tolerance);

    const auto partial_replace_value2 = replace_base_unit<second>(partial_replace_value);

    using result_quantity2 = decltype(partial_replace_value2);
    using result_dimension2 = traits::dimension_t<result_quantity2>;
    using result_unit2 = traits::unit_t<result_quantity2>;

    using seconds_to_the_fourth = unit_power<second, 4>;
    using expected_unit2 = unit_product<decimeter_to_the_minus_two, seconds_to_the_fourth>;

    constexpr auto is_correct_dimension2 = std::is_same_v<result_dimension2, dim_product>;
    EXPECT_TRUE(is_correct_dimension2);

    constexpr auto is_correct_unit2 = std::is_same_v<result_unit2, expected_unit2>;
    EXPECT_TRUE(is_correct_unit2);

    EXPECT_NEAR(static_cast<double>(partial_replace_value2.count()), 1.599264, comparison_tolerance);

    const auto partial_replace_value3 = replace_base_unit<second>(partial_replace_value2);

    using result_quantity3 = decltype(partial_replace_value3);
    using result_dimension3 = traits::dimension_t<result_quantity3>;
    using result_unit3 = traits::unit_t<result_quantity3>;

    constexpr auto is_correct_dimension3 = std::is_same_v<result_dimension3, dim_product>;
    EXPECT_TRUE(is_correct_dimension3);

    constexpr auto is_correct_unit3 = std::is_same_v<result_unit3, expected_unit2>;
    EXPECT_TRUE(is_correct_unit3);

    EXPECT_NEAR(static_cast<double>(partial_replace_value3.count()), 1.599264, comparison_tolerance);
}

TEST(Units, DerivedSIUnits) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    using one_over_s = quantity<dimension_power<dim_time, -1>, unit_power<second, -1>, double>;

    EXPECT_TRUE(herz::symbol() == "Hz");

    EXPECT_TRUE(equals(1_Hz, one_over_s(1)));
    EXPECT_TRUE(equals(1_kHz, one_over_s(1000)));

    EXPECT_TRUE(equals(1.3_Hz, one_over_s(1.3)));
    EXPECT_TRUE(equals(1.3_kHz, one_over_s(1300)));

//===========================================================================================================
    using kgm_over_ssquared = quantity<dimension_product<dim_mass, dim_length, dimension_power<dim_time, -2>>, unit_product<kilogram, meter, unit_power<second, -2>>, double>;

    using gcm_over_ssquared = quantity<dimension_product<dimension_power<dim_mass, 1>, dim_length, dimension_power<dim_time, -2>>, unit_product<gram, centimeter, unit_power<second, -2>>, double>;

    EXPECT_TRUE(newton::symbol() == "N");

    EXPECT_TRUE(equals(1_N, kgm_over_ssquared(1)));
    EXPECT_TRUE(equals(1_kN, kgm_over_ssquared(1000)));

    EXPECT_TRUE(equals(1.2_N, kgm_over_ssquared(1.2)));
    EXPECT_TRUE(equals(1.2_kN, kgm_over_ssquared(1200)));

    EXPECT_TRUE(equals(1_N, gcm_over_ssquared(100000)));

//===========================================================================================================
    using kgover_mssquared = quantity<dimension_product<dim_mass, dimension_power<dim_length, -1>, dimension_power<dim_time, -2>>, unit_product<kilogram, unit_power<meter, -1>, unit_power<second, -2>>, double>;

    using mgover_mmssquared = quantity<dimension_product<dim_mass, dimension_power<dim_length, -1>, dimension_power<dim_time, -2>>, unit_product<milligram, unit_power<millimeter, -1>, unit_power<second, -2>>, double>;

    EXPECT_TRUE(pascal::symbol() == "Pa");

    EXPECT_TRUE(equals(1_Pa, kgover_mssquared(1)));
    EXPECT_TRUE(equals(1_kPa, kgover_mssquared(1000)));

    EXPECT_TRUE(equals(1.6_Pa, kgover_mssquared(1.6)));
    EXPECT_TRUE(equals(1.6_kPa, kgover_mssquared(1600)));

    EXPECT_TRUE(equals(1_Pa, mgover_mmssquared(1000)));

//===========================================================================================================
    using kgmsquared_overssquared = quantity<dimension_product<dim_mass, dimension_power<dim_length, 2>, dimension_power<dim_time, -2>>, unit_product<kilogram, unit_power<meter, 2>, unit_power<second, -2>>, double>;

    using mgmmsquared_overssquared = quantity<dimension_product<dim_mass, dimension_power<dim_length, 2>, dimension_power<dim_time, -2>>, unit_product<milligram, unit_power<millimeter, 2>, unit_power<second, -2>>, double>;

    EXPECT_TRUE(joule::symbol() == "J");

    EXPECT_TRUE(equals(1_J, kgmsquared_overssquared(1)));
    EXPECT_TRUE(equals(1_kJ, kgmsquared_overssquared(1000)));

    EXPECT_TRUE(equals(1.42_J, kgmsquared_overssquared(1.42)));
    EXPECT_TRUE(equals(1.42_kJ, kgmsquared_overssquared(1420)));

    EXPECT_TRUE(equals(1.3_J, mgmmsquared_overssquared(1.3e12)));

//===========================================================================================================
    using kgmsquared_oversscubed = quantity<dimension_product<dim_mass, dimension_power<dim_length, 2>, dimension_power<dim_time, -3>>, unit_product<kilogram, unit_power<meter, 2>, unit_power<second, -3>>, double>;

    using mgmmsquared_overmscubed = quantity<dimension_product<dim_mass, dimension_power<dim_length, 2>, dimension_power<dim_time, -3>>, unit_product<milligram, unit_power<millimeter, 2>, unit_power<millisecond, -3>>, double>;

    EXPECT_TRUE(watt::symbol() == "W");

    EXPECT_TRUE(equals(1_W, kgmsquared_oversscubed(1)));
    EXPECT_TRUE(equals(1_kW, kgmsquared_oversscubed(1000)));

    EXPECT_TRUE(equals(1.12_W, kgmsquared_oversscubed(1.12)));
    EXPECT_TRUE(equals(1.12_kW, kgmsquared_oversscubed(1120)));

    EXPECT_TRUE(equals(1.34_W, mgmmsquared_overmscubed(1340)));
}
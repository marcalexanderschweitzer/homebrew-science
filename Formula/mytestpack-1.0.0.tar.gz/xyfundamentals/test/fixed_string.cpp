//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <gtest/gtest.h>

#include <xyfund/fixed_string.hpp>

using namespace xyfund;

TEST(FixedString, Basic) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const fixed_string<char, 1> m('M');
    const fixed_string<char, 2> nd("ND");
    const fixed_string<char, 2> md("MD");

    const fixed_string<char, 3> expected_result("MND");

    const auto result = m + nd;

    EXPECT_TRUE(result == expected_result);

    EXPECT_FALSE(m == nd);
    EXPECT_FALSE(md == nd);

    EXPECT_TRUE(md == "MD");
    EXPECT_FALSE(md == "X");
    EXPECT_FALSE(md == "ND");
}
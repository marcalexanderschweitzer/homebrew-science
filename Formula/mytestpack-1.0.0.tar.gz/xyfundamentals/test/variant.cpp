//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <gtest/gtest.h>

#include <xyfund/functional.hpp>
#include <xyfund/variant.hpp>

TEST(Variant, DefaultConstruct) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::variant<int, std::string> var;
    (void)var;
}

TEST(Variant, Initialize) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::variant<int, std::string> var = 5;
    (void)var;
}

TEST(Variant, GetIf) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::variant<int, float> var = 5;

    ASSERT_TRUE(xyfund::get_if<int>(&var) != nullptr);
    EXPECT_EQ(*xyfund::get_if<int>(&var), 5);

    EXPECT_TRUE(xyfund::get_if<float>(&var) == nullptr);
}

TEST(Variant, Visit) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::variant<int, std::string> var = 5;
    xyfund::visit([](const auto& /*value*/) {},
                  var);
}

TEST(Variant, VisitReturn) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::variant<int, std::string> var = 5;

    const auto result = xyfund::visit([](const auto& /*value*/) { return true; },
                                      var);

    EXPECT_TRUE(result);
}

TEST(Variant, VisitReturnRef) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    int                               a   = 0;
    xyfund::variant<int, std::string> var = 5;

    auto& result = xyfund::visit([&a](const auto & /*value*/) -> int& { return a; },
                                 var);

    result = 1;

    EXPECT_EQ(a, 1);
}

TEST(Variant, VisitOverload) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::variant<int, std::string> var = 5;

    const auto result = xyfund::visit(xyfund::overload(
                                          [](int /*value*/) { return true; },
                                          [](const std::string& /*value*/) { return false; }),
                                      var);

    EXPECT_TRUE(result);
}

TEST(Variant, VisitOverloadRef) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    int a = 0;
    int b = 0;

    xyfund::variant<int, std::string> var = 5;

    xyfund::visit(xyfund::overload(
                      [&a](int /*value*/) -> int& { return a; },
                      [&b](const std::string & /*value*/) -> int& { return b; }),
                  var) = 1;

    var = "str";

    xyfund::visit(xyfund::overload(
                      [&a](int /*value*/) -> int& { return a; },
                      [&b](const std::string & /*value*/) -> int& { return b; }),
                  var) = 2;

    EXPECT_EQ(a, 1);
    EXPECT_EQ(b, 2);
}

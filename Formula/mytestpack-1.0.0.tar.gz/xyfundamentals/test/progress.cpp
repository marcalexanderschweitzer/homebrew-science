//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <chrono>
#include <thread>
#include <numeric>

#include <gtest/gtest.h>

#include <xyfund/progress.hpp>

TEST(Progress, Increment) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const auto size = 3;

    std::stringstream out;

    {
        xyfund::progress_bar progress_bar(size, 80, out);

        for(xyfund::index_t i = 0; i < size; ++i)
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
            ++progress_bar;
        }
    }

    const auto result = out.str();

    const auto* expected_result =
        "\r[                                                                         ]   0%"
        "\r[========================                                                 ]  33%"
        "\r[================================================                         ]  66%"
        "\r[=========================================================================] 100%\n";

    EXPECT_EQ(result, expected_result);
}

TEST(Progress, IncrementNoClear) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const auto size = 3;

    std::stringstream out;

    {
        xyfund::progress_bar progress_bar(size, 80, out, false);

        for(xyfund::index_t i = 0; i < size; ++i)
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
            ++progress_bar;
        }
    }

    const auto result = out.str();

    const auto* expected_result =
        "[                                                                         ]   0%\n"
        "[========================                                                 ]  33%\n"
        "[================================================                         ]  66%\n"
        "[=========================================================================] 100%\n";

    EXPECT_EQ(result, expected_result);
}

TEST(Progress, IncrementExplicitFinish) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const auto size = 3;

    std::stringstream out;

    xyfund::progress_bar progress_bar(size, 80, out);

    for(xyfund::index_t i = 0; i < size; ++i)
    {
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
        ++progress_bar;
    }

    progress_bar.finish();

    const auto result = out.str();

    const auto* expected_result =
        "\r[                                                                         ]   0%"
        "\r[========================                                                 ]  33%"
        "\r[================================================                         ]  66%"
        "\r[=========================================================================] 100%\n";

    EXPECT_EQ(result, expected_result);
}

TEST(Progress, IncrementFast) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const auto size      = 10;
    const auto increment = 2;

    std::stringstream out;

    {
        xyfund::progress_bar progress_bar(size, 80, out);

        for(xyfund::index_t i = 0; i < size; i += increment)
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
            progress_bar += increment;
        }
    }

    const auto result = out.str();

    const auto* expected_result =
        "\r[                                                                         ]   0%"
        "\r[==============                                                           ]  20%"
        "\r[=============================                                            ]  40%"
        "\r[===========================================                              ]  60%"
        "\r[==========================================================               ]  80%"
        "\r[=========================================================================] 100%\n";

    EXPECT_EQ(result, expected_result);
}

TEST(Progress, IncrementOverflow) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const auto size = 3;

    std::stringstream out;

    {
        xyfund::progress_bar progress_bar(size, 80, out);

        for(xyfund::index_t i = 0; i < size * 2; ++i)
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
            ++progress_bar;
        }
    }

    const auto result = out.str();

    const auto* expected_result =
        "\r[                                                                         ]   0%"
        "\r[========================                                                 ]  33%"
        "\r[================================================                         ]  66%"
        "\r[=========================================================================] 100%"
        "\r[=========================================================================] 133%"
        "\r[=========================================================================] 166%"
        "\r[=========================================================================] 200%\n";

    EXPECT_EQ(result, expected_result);
}

TEST(Progress, ZeroCount) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const auto size = 0;

    std::stringstream out;

    {
        xyfund::progress_bar progress_bar(size, 80, out);
    }

    const auto result = out.str();

    const auto* expected_result =
        "\r[=========================================================================] 100%\n";

    EXPECT_EQ(result, expected_result);
}

TEST(Progress, VectorRangeView) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    std::stringstream out;

    const auto elements = std::vector<int>{1, 2, 3};
    std::vector<int> iterated_elements;

    {
        xyfund::progress_bar progress_bar(80, out);
        for(const auto entry : xyfund::progress_range_view(elements, progress_bar))
        {
            iterated_elements.push_back(entry);
        }
    }

    const auto result = out.str();

    const auto* expected_result =
        "\r[                                                                         ]   0%"
        "\r[========================                                                 ]  33%"
        "\r[================================================                         ]  66%"
        "\r[=========================================================================] 100%\n";

    EXPECT_EQ(result, expected_result);
    EXPECT_EQ(iterated_elements, elements);
}

TEST(Progress, TemporaryVectorRangeView) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    std::stringstream out;

    const auto elements = std::vector<int>{1, 2, 3};
    std::vector<int> iterated_elements;

    {
        xyfund::progress_bar progress_bar(80, out);
        for(const auto entry : xyfund::progress_range_view(std::vector<int>(elements), progress_bar))
        {
            iterated_elements.push_back(entry);
        }
    }

    const auto result = out.str();

    const auto* expected_result =
        "\r[                                                                         ]   0%"
        "\r[========================                                                 ]  33%"
        "\r[================================================                         ]  66%"
        "\r[=========================================================================] 100%\n";

    EXPECT_EQ(result, expected_result);
    EXPECT_EQ(iterated_elements, elements);
}

TEST(Progress, VectorNoRangeView) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const auto elements = std::vector<int>{1, 2, 3};
    std::vector<int> iterated_elements;

    {
        for(const auto entry : xyfund::progress_range_view(elements, xyfund::nullopt))
        {
            iterated_elements.push_back(entry);
        }
    }
    EXPECT_EQ(iterated_elements, elements);
}

template<typename T>
class custom_vector
{
public:
    custom_vector(std::vector<T> data) :
        data_(std::move(data))
    {}

    auto begin()
    {
        return data_.begin();
    }
    auto begin() const
    {
        return data_.begin();
    }
    auto end()
    {
        return data_.end();
    }
    auto end() const
    {
        return data_.end();
    }

    const std::vector<T>& data() const
    {
        return data_;
    }

private:
    std::vector<T> data_;
};

namespace xyfund {

template<typename T>
struct progress_range_traits<custom_vector<T>>
{
    static std::ptrdiff_t estimate_total_progress(const custom_vector<T>& range)
    {
        return std::accumulate(range.begin(), range.end(), 0) + 4;
    }
    static std::pair<xyfund::ranges::iterator_t<custom_vector<T>>, std::ptrdiff_t> begin(custom_vector<T>& range)
    {
        return {std::begin(range), 4};
    }
    static std::pair<xyfund::ranges::iterator_t<const custom_vector<T>>, std::ptrdiff_t> begin(const custom_vector<T>& range)
    {
        return {std::begin(range), 4};
    }
    template<typename Iter>
    static std::ptrdiff_t increment(Iter& iter)
    {
        const auto value = *iter;
        ++iter;
        return static_cast<std::ptrdiff_t>(value);
    }
};

} // namespace xyfund

TEST(Progress, CustomRangeView) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    std::stringstream out;

    const auto       elements = custom_vector<int>(std::vector<int>{1, 2, 3});
    std::vector<int> iterated_elements;

    {
        xyfund::progress_bar progress_bar(80, out);
        for(const auto entry : xyfund::progress_range_view(elements, progress_bar))
        {
            iterated_elements.push_back(entry);
        }
    }

    const auto result = out.str();

    const auto* expected_result =
        "\r[                                                                         ]   0%"
        "\r[=============================                                            ]  40%"
        "\r[====================================                                     ]  50%"
        "\r[===================================================                      ]  70%"
        "\r[=========================================================================] 100%\n";

    EXPECT_EQ(result, expected_result);
    EXPECT_EQ(iterated_elements, elements.data());
}
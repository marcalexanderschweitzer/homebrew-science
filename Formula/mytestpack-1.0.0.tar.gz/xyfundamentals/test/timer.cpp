//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <gtest/gtest.h>

#include <thread>

#include <xyfund/timer.hpp>

TEST(Timer, Basic) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::timer<> t;
    std::this_thread::sleep_for(std::chrono::milliseconds(200));
    const auto e = t.elapsed<std::chrono::milliseconds>();
    EXPECT_TRUE(e >= std::chrono::milliseconds(100));
    t.restart();
    std::this_thread::sleep_for(std::chrono::milliseconds(50));
    const auto e2 = t.elapsed<std::chrono::milliseconds>();
    EXPECT_TRUE(e2 >= std::chrono::milliseconds(50));
    EXPECT_TRUE(e2 < std::chrono::milliseconds(250));
}
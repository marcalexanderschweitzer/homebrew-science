//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <functional>

#include <gtest/gtest.h>

#include <xyfund/utility/semantic_version.hpp>

TEST(Version, ToString) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    std::stringstream str;
    str << xyfund::semantic_version<3>(1, 2, 3);
    EXPECT_STREQ(str.str().c_str(), "1.2.3");
}

TEST(Version, ToNumber) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    EXPECT_EQ(xyfund::semantic_version<3>(1, 2, 3).to_number(1), 123);
    EXPECT_EQ(xyfund::semantic_version<3>(1, 2, 3).to_number(2), 10203);
    EXPECT_EQ(xyfund::semantic_version<3>(1, 2, 3).to_number(3), 1002003);
}

TEST(Version, FromNumber) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    EXPECT_EQ(xyfund::semantic_version<3>::from_number(123, 1), xyfund::semantic_version<3>(1, 2, 3));
    EXPECT_EQ(xyfund::semantic_version<3>::from_number(10203, 2), xyfund::semantic_version<3>(1, 2, 3));
    EXPECT_EQ(xyfund::semantic_version<3>::from_number(1002003, 3), xyfund::semantic_version<3>(1, 2, 3));
}

TEST(Version, Compare) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    EXPECT_FALSE(xyfund::semantic_version<3>(0, 0, 0) < xyfund::semantic_version<3>(0, 0, 0));
    EXPECT_TRUE(xyfund::semantic_version<3>(0, 0, 0) < xyfund::semantic_version<3>(0, 0, 1));
    EXPECT_FALSE(xyfund::semantic_version<3>(0, 0, 1) < xyfund::semantic_version<3>(0, 0, 1));
    EXPECT_FALSE(xyfund::semantic_version<3>(0, 0, 1) < xyfund::semantic_version<3>(0, 0, 0));
    EXPECT_FALSE(xyfund::semantic_version<3>(0, 1, 0) < xyfund::semantic_version<3>(0, 0, 0));
    EXPECT_TRUE(xyfund::semantic_version<3>(0, 0, 0) < xyfund::semantic_version<3>(0, 1, 0));
    EXPECT_FALSE(xyfund::semantic_version<3>(1, 0, 0) < xyfund::semantic_version<3>(0, 1, 0));
    EXPECT_FALSE(xyfund::semantic_version<3>(1, 0, 0) < xyfund::semantic_version<3>(0, 1, 1));
    EXPECT_TRUE(xyfund::semantic_version<3>(1, 0, 0) < xyfund::semantic_version<3>(1, 1, 1));
    EXPECT_TRUE(xyfund::semantic_version<3>(1, 1, 0) < xyfund::semantic_version<3>(1, 1, 1));
    EXPECT_FALSE(xyfund::semantic_version<3>(1, 1, 1) < xyfund::semantic_version<3>(1, 1, 1));
    EXPECT_FALSE(xyfund::semantic_version<3>(1, 1, 2) < xyfund::semantic_version<3>(1, 1, 1));

    EXPECT_TRUE(xyfund::semantic_version<3>(0, 0, 0) <= xyfund::semantic_version<3>(0, 0, 0));
    EXPECT_TRUE(xyfund::semantic_version<3>(0, 0, 0) <= xyfund::semantic_version<3>(0, 0, 1));
    EXPECT_TRUE(xyfund::semantic_version<3>(0, 0, 1) <= xyfund::semantic_version<3>(0, 0, 1));
    EXPECT_FALSE(xyfund::semantic_version<3>(0, 0, 1) <= xyfund::semantic_version<3>(0, 0, 0));
    EXPECT_FALSE(xyfund::semantic_version<3>(0, 1, 0) <= xyfund::semantic_version<3>(0, 0, 0));
    EXPECT_TRUE(xyfund::semantic_version<3>(0, 0, 0) <= xyfund::semantic_version<3>(0, 1, 0));
    EXPECT_FALSE(xyfund::semantic_version<3>(1, 0, 0) <= xyfund::semantic_version<3>(0, 1, 0));
    EXPECT_FALSE(xyfund::semantic_version<3>(1, 0, 0) <= xyfund::semantic_version<3>(0, 1, 1));
    EXPECT_TRUE(xyfund::semantic_version<3>(1, 0, 0) <= xyfund::semantic_version<3>(1, 1, 1));
    EXPECT_TRUE(xyfund::semantic_version<3>(1, 1, 0) <= xyfund::semantic_version<3>(1, 1, 1));
    EXPECT_TRUE(xyfund::semantic_version<3>(1, 1, 1) <= xyfund::semantic_version<3>(1, 1, 1));
    EXPECT_FALSE(xyfund::semantic_version<3>(1, 1, 2) <= xyfund::semantic_version<3>(1, 1, 1));

    EXPECT_FALSE(xyfund::semantic_version<3>(0, 0, 0) > xyfund::semantic_version<3>(0, 0, 0));
    EXPECT_FALSE(xyfund::semantic_version<3>(0, 0, 0) > xyfund::semantic_version<3>(0, 0, 1));
    EXPECT_FALSE(xyfund::semantic_version<3>(0, 0, 1) > xyfund::semantic_version<3>(0, 0, 1));
    EXPECT_TRUE(xyfund::semantic_version<3>(0, 0, 1) > xyfund::semantic_version<3>(0, 0, 0));
    EXPECT_TRUE(xyfund::semantic_version<3>(0, 1, 0) > xyfund::semantic_version<3>(0, 0, 0));
    EXPECT_FALSE(xyfund::semantic_version<3>(0, 0, 0) > xyfund::semantic_version<3>(0, 1, 0));
    EXPECT_TRUE(xyfund::semantic_version<3>(1, 0, 0) > xyfund::semantic_version<3>(0, 1, 0));
    EXPECT_TRUE(xyfund::semantic_version<3>(1, 0, 0) > xyfund::semantic_version<3>(0, 1, 1));
    EXPECT_FALSE(xyfund::semantic_version<3>(1, 0, 0) > xyfund::semantic_version<3>(1, 1, 1));
    EXPECT_FALSE(xyfund::semantic_version<3>(1, 1, 0) > xyfund::semantic_version<3>(1, 1, 1));
    EXPECT_FALSE(xyfund::semantic_version<3>(1, 1, 1) > xyfund::semantic_version<3>(1, 1, 1));
    EXPECT_TRUE(xyfund::semantic_version<3>(1, 1, 2) > xyfund::semantic_version<3>(1, 1, 1));

    EXPECT_TRUE(xyfund::semantic_version<3>(0, 0, 0) >= xyfund::semantic_version<3>(0, 0, 0));
    EXPECT_FALSE(xyfund::semantic_version<3>(0, 0, 0) >= xyfund::semantic_version<3>(0, 0, 1));
    EXPECT_TRUE(xyfund::semantic_version<3>(0, 0, 1) >= xyfund::semantic_version<3>(0, 0, 1));
    EXPECT_TRUE(xyfund::semantic_version<3>(0, 0, 1) >= xyfund::semantic_version<3>(0, 0, 0));
    EXPECT_TRUE(xyfund::semantic_version<3>(0, 1, 0) >= xyfund::semantic_version<3>(0, 0, 0));
    EXPECT_FALSE(xyfund::semantic_version<3>(0, 0, 0) >= xyfund::semantic_version<3>(0, 1, 0));
    EXPECT_TRUE(xyfund::semantic_version<3>(1, 0, 0) >= xyfund::semantic_version<3>(0, 1, 0));
    EXPECT_TRUE(xyfund::semantic_version<3>(1, 0, 0) >= xyfund::semantic_version<3>(0, 1, 1));
    EXPECT_FALSE(xyfund::semantic_version<3>(1, 0, 0) >= xyfund::semantic_version<3>(1, 1, 1));
    EXPECT_FALSE(xyfund::semantic_version<3>(1, 1, 0) >= xyfund::semantic_version<3>(1, 1, 1));
    EXPECT_TRUE(xyfund::semantic_version<3>(1, 1, 1) >= xyfund::semantic_version<3>(1, 1, 1));
    EXPECT_TRUE(xyfund::semantic_version<3>(1, 1, 2) >= xyfund::semantic_version<3>(1, 1, 1));

    EXPECT_TRUE(xyfund::semantic_version<3>(0, 0, 0) == xyfund::semantic_version<3>(0, 0, 0));
    EXPECT_FALSE(xyfund::semantic_version<3>(0, 0, 0) == xyfund::semantic_version<3>(0, 0, 1));
    EXPECT_TRUE(xyfund::semantic_version<3>(0, 0, 1) == xyfund::semantic_version<3>(0, 0, 1));
    EXPECT_FALSE(xyfund::semantic_version<3>(0, 0, 1) == xyfund::semantic_version<3>(0, 0, 0));
    EXPECT_FALSE(xyfund::semantic_version<3>(0, 1, 0) == xyfund::semantic_version<3>(0, 0, 0));
    EXPECT_FALSE(xyfund::semantic_version<3>(0, 0, 0) == xyfund::semantic_version<3>(0, 1, 0));
    EXPECT_FALSE(xyfund::semantic_version<3>(1, 0, 0) == xyfund::semantic_version<3>(0, 1, 0));
    EXPECT_FALSE(xyfund::semantic_version<3>(1, 0, 0) == xyfund::semantic_version<3>(0, 1, 1));
    EXPECT_FALSE(xyfund::semantic_version<3>(1, 0, 0) == xyfund::semantic_version<3>(1, 1, 1));
    EXPECT_FALSE(xyfund::semantic_version<3>(1, 1, 0) == xyfund::semantic_version<3>(1, 1, 1));
    EXPECT_TRUE(xyfund::semantic_version<3>(1, 1, 1) == xyfund::semantic_version<3>(1, 1, 1));
    EXPECT_FALSE(xyfund::semantic_version<3>(1, 1, 2) == xyfund::semantic_version<3>(1, 1, 1));

    EXPECT_FALSE(xyfund::semantic_version<3>(0, 0, 0) != xyfund::semantic_version<3>(0, 0, 0));
    EXPECT_TRUE(xyfund::semantic_version<3>(0, 0, 0) != xyfund::semantic_version<3>(0, 0, 1));
    EXPECT_FALSE(xyfund::semantic_version<3>(0, 0, 1) != xyfund::semantic_version<3>(0, 0, 1));
    EXPECT_TRUE(xyfund::semantic_version<3>(0, 0, 1) != xyfund::semantic_version<3>(0, 0, 0));
    EXPECT_TRUE(xyfund::semantic_version<3>(0, 1, 0) != xyfund::semantic_version<3>(0, 0, 0));
    EXPECT_TRUE(xyfund::semantic_version<3>(0, 0, 0) != xyfund::semantic_version<3>(0, 1, 0));
    EXPECT_TRUE(xyfund::semantic_version<3>(1, 0, 0) != xyfund::semantic_version<3>(0, 1, 0));
    EXPECT_TRUE(xyfund::semantic_version<3>(1, 0, 0) != xyfund::semantic_version<3>(0, 1, 1));
    EXPECT_TRUE(xyfund::semantic_version<3>(1, 0, 0) != xyfund::semantic_version<3>(1, 1, 1));
    EXPECT_TRUE(xyfund::semantic_version<3>(1, 1, 0) != xyfund::semantic_version<3>(1, 1, 1));
    EXPECT_FALSE(xyfund::semantic_version<3>(1, 1, 1) != xyfund::semantic_version<3>(1, 1, 1));
    EXPECT_TRUE(xyfund::semantic_version<3>(1, 1, 2) != xyfund::semantic_version<3>(1, 1, 1));
}

TEST(Version, Constexpr) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    constexpr xyfund::semantic_version<3> v0(1, 0, 0);
    constexpr xyfund::semantic_version<3> v0_copy(1, 0, 0);
    constexpr xyfund::semantic_version<3> v1(1, 1, 0);

    static_assert(v0 == v0_copy, "Same: equal");
    static_assert(!(v0 != v0_copy), "Same: not equal");
    static_assert(!(v0 < v0_copy), "Same: less");
    static_assert(v0 <= v0_copy, "Same: less equal");
    static_assert(!(v0 > v0_copy), "Same: greater");
    static_assert(v0 >= v0_copy, "Same: greater equal");

    static_assert(!(v0 == v1), "Other: equal");
    static_assert(v0 != v1, "Other: not equal");
    static_assert(v0 < v1, "Other: less");
    static_assert(v0 <= v1, "Other: less equal");
    static_assert(!(v0 > v1), "Other: greater");
    static_assert(!(v0 >= v1), "Other: greater equal");

    static_assert(xyfund::semantic_version<3>(1, 2, 3).to_number(1) == 123, "semantic_version.to_number(1)");
    static_assert(xyfund::semantic_version<3>(1, 2, 3).to_number(2) == 10203, "semantic_version.to_number(2)");
    static_assert(xyfund::semantic_version<3>(1, 2, 3).to_number(3) == 1002003, "semantic_version.to_number(3)");

    EXPECT_TRUE(xyfund::semantic_version<3>::from_number(123, 1) == xyfund::semantic_version<3>(1, 2, 3));
    EXPECT_TRUE(xyfund::semantic_version<3>::from_number(10203, 2) == xyfund::semantic_version<3>(1, 2, 3));
    EXPECT_TRUE(xyfund::semantic_version<3>::from_number(1002003, 3) == xyfund::semantic_version<3>(1, 2, 3));
}

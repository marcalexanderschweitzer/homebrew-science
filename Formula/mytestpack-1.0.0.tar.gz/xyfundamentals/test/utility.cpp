//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#ifdef XYFUND_NO_ASSERT
#    undef XYFUND_NO_ASSERT
#endif

#include <array>
#include <vector>

#include <gtest/gtest.h>

#include <xyfund/utility.hpp>
#include <xyfund/narrow.hpp>

TEST(Ssize, CArray) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    int       arr[4]  = {1, 2, 3, 4}; //NOLINT(cppcoreguidelines-avoid-c-arrays, modernize-avoid-c-arrays)
    const int carr[4] = {1, 2, 3, 4}; //NOLINT(cppcoreguidelines-avoid-c-arrays, modernize-avoid-c-arrays)

    EXPECT_EQ(xyfund::ssize(arr), std::ptrdiff_t(4));
    EXPECT_EQ(xyfund::ssize(carr), std::ptrdiff_t(4));
}

TEST(Ssize, StdArray) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    std::array<int, 4>       arr  = {1, 2, 3, 4};
    const std::array<int, 4> carr = {1, 2, 3, 4};

    EXPECT_EQ(xyfund::ssize(arr), std::ptrdiff_t(4));
    EXPECT_EQ(xyfund::ssize(carr), std::ptrdiff_t(4));
}

TEST(Ssize, StdVector) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    std::vector<int>       arr  = {1, 2, 3, 4};
    const std::vector<int> carr = {1, 2, 3, 4};

    EXPECT_EQ(xyfund::ssize(arr), std::ptrdiff_t(4));
    EXPECT_EQ(xyfund::ssize(carr), std::ptrdiff_t(4));
}

TEST(Ssize, StdInitializerList) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const std::initializer_list<int> init = {1, 2, 3, 4};

    EXPECT_EQ(xyfund::ssize(init), std::ptrdiff_t(4));
}

TEST(At, CArray) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    int arr[4]          = {1, 2, 3, 4}; //NOLINT(cppcoreguidelines-avoid-c-arrays, modernize-avoid-c-arrays)
    const int(&carr)[4] = arr;          //NOLINT(cppcoreguidelines-avoid-c-arrays, modernize-avoid-c-arrays)

    for(xyfund::index_t i = 0; i < 4; ++i)
    {
        EXPECT_EQ(&xyfund::at(arr, i), &arr[static_cast<std::size_t>(i)]);  // NOLINT(cppcoreguidelines-pro-bounds-constant-array-index)
        EXPECT_EQ(&xyfund::at(carr, i), &arr[static_cast<std::size_t>(i)]); // NOLINT(cppcoreguidelines-pro-bounds-constant-array-index)
    }

    EXPECT_DEATH(xyfund::at(arr, -1), "assertion .*");  // NOLINT(cppcoreguidelines-avoid-goto, cppcoreguidelines-pro-type-vararg)
    EXPECT_DEATH(xyfund::at(arr, 4), "assertion .*");   // NOLINT(cppcoreguidelines-avoid-goto, cppcoreguidelines-pro-type-vararg)
    EXPECT_DEATH(xyfund::at(carr, -1), "assertion .*"); // NOLINT(cppcoreguidelines-avoid-goto, cppcoreguidelines-pro-type-vararg)
    EXPECT_DEATH(xyfund::at(carr, 4), "assertion .*");  // NOLINT(cppcoreguidelines-avoid-goto, cppcoreguidelines-pro-type-vararg)
}

TEST(At, StdArray) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    std::array<int, 4>        arr  = {1, 2, 3, 4};
    const std::array<int, 4>& carr = arr;

    for(xyfund::index_t i = 0; i < 4; ++i)
    {
        EXPECT_EQ(&xyfund::at(arr, i), &arr[static_cast<std::size_t>(i)]);  // NOLINT(cppcoreguidelines-pro-bounds-constant-array-index)
        EXPECT_EQ(&xyfund::at(carr, i), &arr[static_cast<std::size_t>(i)]); // NOLINT(cppcoreguidelines-pro-bounds-constant-array-index)
    }

    EXPECT_DEATH(xyfund::at(arr, -1), "assertion .*");  // NOLINT(cppcoreguidelines-avoid-goto, cppcoreguidelines-pro-type-vararg)
    EXPECT_DEATH(xyfund::at(arr, 4), "assertion .*");   // NOLINT(cppcoreguidelines-avoid-goto, cppcoreguidelines-pro-type-vararg)
    EXPECT_DEATH(xyfund::at(carr, -1), "assertion .*"); // NOLINT(cppcoreguidelines-avoid-goto, cppcoreguidelines-pro-type-vararg)
    EXPECT_DEATH(xyfund::at(carr, 4), "assertion .*");  // NOLINT(cppcoreguidelines-avoid-goto, cppcoreguidelines-pro-type-vararg)
}

TEST(At, StdVector) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    std::vector<int>        arr  = {1, 2, 3, 4};
    const std::vector<int>& carr = arr;

    for(xyfund::index_t i = 0; i < 4; ++i)
    {
        EXPECT_EQ(&xyfund::at(arr, i), &arr[static_cast<std::size_t>(i)]);
        EXPECT_EQ(&xyfund::at(carr, i), &arr[static_cast<std::size_t>(i)]);
    }

    EXPECT_DEATH(xyfund::at(arr, -1), "assertion .*");  // NOLINT(cppcoreguidelines-avoid-goto, cppcoreguidelines-pro-type-vararg)
    EXPECT_DEATH(xyfund::at(arr, 4), "assertion .*");   // NOLINT(cppcoreguidelines-avoid-goto, cppcoreguidelines-pro-type-vararg)
    EXPECT_DEATH(xyfund::at(carr, -1), "assertion .*"); // NOLINT(cppcoreguidelines-avoid-goto, cppcoreguidelines-pro-type-vararg)
    EXPECT_DEATH(xyfund::at(carr, 4), "assertion .*");  // NOLINT(cppcoreguidelines-avoid-goto, cppcoreguidelines-pro-type-vararg)
}

TEST(At, StdInitializerList) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const std::initializer_list<int> init = {1, 2, 3, 4};

    for(int i = 0; i < 4; ++i)
    {
        EXPECT_EQ(xyfund::at(init, i), i + 1);
    }

    EXPECT_DEATH(xyfund::at(init, -1), "assertion .*"); // NOLINT(cppcoreguidelines-avoid-goto, cppcoreguidelines-pro-type-vararg)
    EXPECT_DEATH(xyfund::at(init, 4), "assertion .*");  // NOLINT(cppcoreguidelines-avoid-goto, cppcoreguidelines-pro-type-vararg)
}

TEST(NarrowCast, IntToChar) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    EXPECT_EQ(xyfund::narrow_cast<char>(int{120}), char{120});
    EXPECT_EQ(xyfund::narrow_cast<unsigned char>(int{300}), (unsigned char)44);
}

TEST(Narrow, IntToChar) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    EXPECT_EQ(xyfund::narrow<char>(int{120}), char{120});
    EXPECT_THROW(xyfund::narrow<unsigned char>(int{300}), xyfund::narrowing_error); // NOLINT(cppcoreguidelines-avoid-goto)

    EXPECT_THROW(xyfund::narrow<unsigned int>(int{-123}), xyfund::narrowing_error); // NOLINT(cppcoreguidelines-avoid-goto)
}

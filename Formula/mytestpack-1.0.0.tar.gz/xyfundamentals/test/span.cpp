//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#ifdef XYFUND_NO_ASSERT
#    undef XYFUND_NO_ASSERT
#endif

#include <gtest/gtest.h>

#include <xyfund/span.hpp>
#include <xyfund/utility.hpp>

TEST(Span, DynamicIntDefaultConstruct) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::span<int> s;
    EXPECT_TRUE(s.empty());
    EXPECT_TRUE(s.data() == nullptr);

    xyfund::span<const int> cs;
    EXPECT_TRUE(cs.empty());
    EXPECT_TRUE(cs.data() == nullptr);

    xyfund::span<int> s2{};
    EXPECT_TRUE(s2.empty());
    EXPECT_TRUE(s2.data() == nullptr);

    xyfund::span<const int> cs2{};
    EXPECT_TRUE(cs2.empty());
    EXPECT_TRUE(cs2.data() == nullptr);
}

TEST(Span, Size) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::span<int> s;
    EXPECT_TRUE(sizeof(s) == sizeof(int*) + sizeof(ptrdiff_t));

    xyfund::span<int, 0> s2;
    EXPECT_TRUE(sizeof(s2) == sizeof(int*));
}

TEST(Span, FixedIntDefaultConstruct) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::span<int, 0> s;
    EXPECT_TRUE(s.empty());
    EXPECT_TRUE(s.data() == nullptr);

    xyfund::span<const int, 0> cs;
    EXPECT_TRUE(cs.empty());
    EXPECT_TRUE(cs.data() == nullptr);
}

TEST(Span, DynamicIntNull) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::span<int> s(nullptr, static_cast<xyfund::span<int>::index_type>(0));
    EXPECT_TRUE(s.empty());
    EXPECT_TRUE(s.data() == nullptr);

    xyfund::span<const int> cs(nullptr, static_cast<xyfund::span<const int>::index_type>(0));
    EXPECT_TRUE(cs.empty());
    EXPECT_TRUE(cs.data() == nullptr);
}

TEST(Span, DynamicIntPtrNull) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::span<int*> s(nullptr, static_cast<xyfund::span<int>::index_type>(0));
    EXPECT_TRUE(s.empty());
    EXPECT_TRUE(s.data() == nullptr);

    xyfund::span<const int*> cs(nullptr, static_cast<xyfund::span<const int>::index_type>(0));
    EXPECT_TRUE(cs.empty());
    EXPECT_TRUE(cs.data() == nullptr);
}

TEST(Span, FixedIntNull) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::span<int, 0> s(nullptr, static_cast<xyfund::span<int>::index_type>(0));
    EXPECT_TRUE(s.empty());
    EXPECT_TRUE(s.data() == nullptr);

    xyfund::span<const int, 0> cs(nullptr, static_cast<xyfund::span<const int>::index_type>(0));
    EXPECT_TRUE(cs.empty());
    EXPECT_TRUE(cs.data() == nullptr);
}

TEST(Span, FixedMismatch) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    EXPECT_DEATH((xyfund::span<int, 1>(nullptr, static_cast<xyfund::span<int>::index_type>(0))), "assertion .*");             // NOLINT(cppcoreguidelines-avoid-goto, cppcoreguidelines-pro-type-vararg)
    EXPECT_DEATH((xyfund::span<const int, 1>(nullptr, static_cast<xyfund::span<const int>::index_type>(0))), "assertion .*"); // NOLINT(cppcoreguidelines-avoid-goto, cppcoreguidelines-pro-type-vararg)

    EXPECT_DEATH((xyfund::span<int, 0>(nullptr, static_cast<xyfund::span<int>::index_type>(1))), "assertion .*");             // NOLINT(cppcoreguidelines-avoid-goto, cppcoreguidelines-pro-type-vararg)
    EXPECT_DEATH((xyfund::span<const int, 0>(nullptr, static_cast<xyfund::span<const int>::index_type>(1))), "assertion .*"); // NOLINT(cppcoreguidelines-avoid-goto, cppcoreguidelines-pro-type-vararg)
}

TEST(Span, DynamicMismatch) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    EXPECT_DEATH((xyfund::span<int>(nullptr, static_cast<xyfund::span<int>::index_type>(1))), "assertion .*");             // NOLINT(cppcoreguidelines-avoid-goto, cppcoreguidelines-pro-type-vararg)
    EXPECT_DEATH((xyfund::span<const int>(nullptr, static_cast<xyfund::span<const int>::index_type>(1))), "assertion .*"); // NOLINT(cppcoreguidelines-avoid-goto, cppcoreguidelines-pro-type-vararg)
}

TEST(Span, PtrAndSize) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    int arr[4] = {1, 2, 3, 4}; //NOLINT(cppcoreguidelines-avoid-c-arrays, modernize-avoid-c-arrays)

    {
        for(int i = 0; i < 4; ++i)
        {
            {
                xyfund::span<int> s = {&xyfund::at(arr, 0), i};
                EXPECT_TRUE(s.size() == i);
                EXPECT_TRUE(s.data() == &xyfund::at(arr, 0));
                EXPECT_TRUE(s.empty() == (i == 0));
                for(int j = 0; j < i; ++j)
                {
                    EXPECT_TRUE(xyfund::at(arr, j) == s[j]);
                    EXPECT_TRUE(xyfund::at(arr, j) == s.at(j));
                    EXPECT_TRUE(xyfund::at(arr, j) == s(j));
                }
            }
            {
                xyfund::span<int> s = {&xyfund::at(arr, i), 4 - static_cast<ptrdiff_t>(i)};
                EXPECT_TRUE(s.size() == 4 - i);
                EXPECT_TRUE(s.data() == &xyfund::at(arr, i));
                EXPECT_TRUE(s.empty() == (4 - i == 0));
                for(int j = 0; j < 4 - i; ++j)
                {
                    EXPECT_TRUE(xyfund::at(arr, j + i) == s[j]);
                    EXPECT_TRUE(xyfund::at(arr, j + i) == s.at(j));
                    EXPECT_TRUE(xyfund::at(arr, j + i) == s(j));
                }
            }
        }
    }

    {
        xyfund::span<int, 2> s{&xyfund::at(arr, 0), 2};
        EXPECT_TRUE((s.size() == 2 && s.data() == &xyfund::at(arr, 0)));
        EXPECT_TRUE((s[0] == 1 && s[1] == 2));
    }

    {
        int*              p = nullptr;
        xyfund::span<int> s{p, static_cast<xyfund::span<int>::index_type>(0)};
        EXPECT_TRUE((s.empty() && s.data() == nullptr));
    }

    //{
    //    int* p = nullptr;
    //    auto workaround_macro = [=]() { const xyfund::span<int> s{ p, 2 }; };
    //    EXPECT_TRUE_THROWS_AS(workaround_macro(), fail_fast);
    //}

    {
        auto s = xyfund::make_span(&xyfund::at(arr, 0), 2);
        EXPECT_TRUE((s.size() == 2 && s.data() == &xyfund::at(arr, 0)));
        EXPECT_TRUE((s[0] == 1 && s[1] == 2));
    }

    {
        int* p = nullptr;
        auto s = xyfund::make_span(p, static_cast<xyfund::span<int>::index_type>(0));
        EXPECT_TRUE((s.empty() && s.data() == nullptr));
    }

    //{
    //    int* p = nullptr;
    //    auto workaround_macro = [=]() { make_span(p, 2); };
    //    EXPECT_TRUE_THROWS_AS(workaround_macro(), fail_fast);
    //}
}

// TODO: write more tests (aka. take them from gsl::span at github)

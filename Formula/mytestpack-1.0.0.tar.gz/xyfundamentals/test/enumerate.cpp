//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <vector>
#include <list>
#include <forward_list>

#include <gtest/gtest.h>

#include <xyfund/ranges/enumerate.hpp>

TEST(Enumerate, Vector) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    std::vector<int> vec = {1,2,3,4};
    int index = 0;
    for(auto&& [i, v] : xyfund::views::enumerate(vec))
    {
        EXPECT_EQ(index, i);
        EXPECT_EQ(v, index + 1);
        v = index;
        ++index;
    }
    EXPECT_EQ(index, 4);
    EXPECT_EQ(vec, (std::vector<int>{0,1,2,3}));
}

TEST(Enumerate, ConstVector) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const std::vector<int> vec = {1,2,3,4};
    int index = 0;
    for(const auto& [i, v] : xyfund::views::enumerate(vec))
    {
        EXPECT_EQ(index, i);
        EXPECT_EQ(v, index + 1);
        ++index;
    }
    EXPECT_EQ(index, 4);
}

TEST(Enumerate, ConstReverseVector) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const std::vector<int> vec = {1,2,3,4};
    int index = 0;
    for(const auto& [i, v] : vec | xyfund::views::reverse | xyfund::views::enumerate)
    {
        EXPECT_EQ(index, i);
        EXPECT_EQ(v, 4 - index);
        ++index;
    }
    EXPECT_EQ(index, 4);
}

TEST(Enumerate, List) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    std::list<int> vec = {1,2,3,4};
    int index = 0;
    for(auto&& [i, v] : xyfund::views::enumerate(vec))
    {
        EXPECT_EQ(index, i);
        EXPECT_EQ(v, index + 1);
        v = index;
        ++index;
    }
    EXPECT_EQ(index, 4);
    EXPECT_EQ(vec, (std::list<int>{0,1,2,3}));
}

TEST(Enumerate, ConstList) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const std::list<int> vec = {1,2,3,4};
    int index = 0;
    for(const auto& [i, v] : xyfund::views::enumerate(vec))
    {
        EXPECT_EQ(index, i);
        EXPECT_EQ(v, index + 1);
        ++index;
    }
    EXPECT_EQ(index, 4);
}

TEST(Enumerate, ForwardList) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    std::forward_list<int> vec = {1,2,3,4};
    int index = 0;
    for(auto&& [i, v] : xyfund::views::enumerate(vec))
    {
        EXPECT_EQ(index, i);
        EXPECT_EQ(v, index + 1);
        v = index;
        ++index;
    }
    EXPECT_EQ(index, 4);
    EXPECT_EQ(vec, (std::forward_list<int>{0,1,2,3}));
}

TEST(Enumerate, ConstForwardList) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const std::forward_list<int> vec = {1,2,3,4};
    int index = 0;
    for(const auto& [i, v] : xyfund::views::enumerate(vec))
    {
        EXPECT_EQ(index, i);
        EXPECT_EQ(v, index + 1);
        ++index;
    }
    EXPECT_EQ(index, 4);
}

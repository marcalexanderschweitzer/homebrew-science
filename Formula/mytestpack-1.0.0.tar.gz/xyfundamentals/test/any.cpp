//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <gtest/gtest.h>

#include <xyfund/any.hpp>

TEST(Any, VisitConst) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    int                 x = 15;
    const xyfund::any   a = x;
    xyfund::any_visitor v;

    int result = 0;
    v.insert([&result](int x) {
        result = x;
    });
    v.insert([&result](std::string /*unused*/) //NOLINT(performance-unnecessary-value-param)
             {
                 result = -1;
             });

    const auto visited = v(a);
    EXPECT_TRUE(visited);
    EXPECT_EQ(result, 15);
    EXPECT_EQ(xyfund::any_cast<int>(a), 15);
}

TEST(Any, VisitConstReference) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    int                 x = 15;
    const xyfund::any   a = x;
    xyfund::any_visitor v;

    int result = 0;
    v.insert([&result](const int& x) {
        result = x;
    });
    v.insert([&result](const std::string& /*unused*/) {
        result = -1;
    });

    const auto visited = v(a);
    EXPECT_TRUE(visited);
    EXPECT_EQ(result, 15);
    EXPECT_EQ(xyfund::any_cast<int>(a), 15);
}

TEST(Any, VisitMutable) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    std::string         x = "a";
    xyfund::any         a = x;
    xyfund::any_visitor v;

    std::string result;
    v.insert([&result](int& /*unused*/) {
        result = "";
    });
    v.insert([&result](std::string& x) {
        result = x;
        x      = "b";
    });

    const auto visited = v(a);
    EXPECT_TRUE(visited);
    EXPECT_EQ(result, "a");
    EXPECT_EQ(xyfund::any_cast<std::string>(a), "b");
}

TEST(Any, VisitMissing) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    bool                x = false;
    xyfund::any         a = x;
    xyfund::any_visitor v;

    int result = 0;
    v.insert([&result](int& /*unused*/) {
        result = 1;
    });
    v.insert([&result](std::string& /*unused*/) {
        result = 2;
    });

    const auto visited = v(a);
    EXPECT_FALSE(visited);
    EXPECT_EQ(result, 0);
}

TEST(Any, VisitViolateConst) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    int                 x = 15;
    const xyfund::any   a = x;
    xyfund::any_visitor v;

    v.insert([&](int& x) {
        x = 10;
    });

    EXPECT_THROW(v(a), xyfund::bad_any_cast); // NOLINT(cppcoreguidelines-avoid-goto)
}
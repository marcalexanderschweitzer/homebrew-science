//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <gtest/gtest.h>

#include <xyfund/stable_unique_container.hpp>

struct point
{
    double x; // NOLINT(misc-non-private-member-variables-in-classes)
    double y; // NOLINT(misc-non-private-member-variables-in-classes)

    bool operator==(const point& other) const
    {
        return x == other.x && y == other.y;
    }
};

std::ostream& operator<<(std::ostream& os, const point& point)
{
    os << "(" << point.x << "," << point.y << ")";
    return os;
}

struct point_compare
{
    bool operator()(const point& lhs, const point& rhs) const
    {
        return std::make_pair(lhs.x, lhs.y) < std::make_pair(rhs.x, rhs.y);
    }
};

TEST(StableUniqueContainer, DefaultConstruct) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::stable_unique_container<point, point_compare> list;
    EXPECT_TRUE(list.data().empty());
    EXPECT_EQ(list.data().size(), 0);
    (void)list;
}

TEST(StableUniqueContainer, Insert) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::stable_unique_container<point, point_compare> list;

    {
        const auto [index, inserted] = list.insert(point{0.0, 0.0});
        EXPECT_EQ(index, 0);
        EXPECT_TRUE(inserted);
        EXPECT_EQ(list.data(), (std::vector<point>{point{0.0, 0.0}}));
    }
    {
        const auto [index, inserted] = list.insert(point{2.0, 0.0});
        EXPECT_EQ(index, 1);
        EXPECT_TRUE(inserted);
        EXPECT_EQ(list.data(), (std::vector<point>{point{0.0, 0.0}, point{2.0, 0.0}}));
    }
    {
        const auto [index, inserted] = list.insert(point{1.0, 0.0});
        EXPECT_EQ(index, 2);
        EXPECT_TRUE(inserted);
        EXPECT_EQ(list.data(), (std::vector<point>{point{0.0, 0.0}, point{2.0, 0.0}, point{1.0, 0.0}}));
    }
    {
        const auto [index, inserted] = list.insert(point{2.0, 0.0});
        EXPECT_EQ(index, 1);
        EXPECT_FALSE(inserted);
        EXPECT_EQ(list.data(), (std::vector<point>{point{0.0, 0.0}, point{2.0, 0.0}, point{1.0, 0.0}}));
    }
}

TEST(StableUniqueContainer, CopyConstructAndInsert) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    auto list = std::make_unique<xyfund::stable_unique_container<point, point_compare>>();
    list->insert(point{0.0, 0.0});
    list->insert(point{2.0, 0.0});
    list->insert(point{1.0, 0.0});
    EXPECT_EQ(list->data(), (std::vector<point>{point{0.0, 0.0}, point{2.0, 0.0}, point{1.0, 0.0}}));

    xyfund::stable_unique_container<point, point_compare> list2(*list);
    list = nullptr;

    EXPECT_EQ(list2.data(), (std::vector<point>{point{0.0, 0.0}, point{2.0, 0.0}, point{1.0, 0.0}}));

    {
        const auto [index, inserted] = list2.insert(point{2.0, 0.0});
        EXPECT_EQ(index, 1);
        EXPECT_FALSE(inserted);
        EXPECT_EQ(list2.data(), (std::vector<point>{point{0.0, 0.0}, point{2.0, 0.0}, point{1.0, 0.0}}));
    }
    {
        const auto [index, inserted] = list2.insert(point{1.0, 3.0});
        EXPECT_EQ(index, 3);
        EXPECT_TRUE(inserted);
        EXPECT_EQ(list2.data(), (std::vector<point>{point{0.0, 0.0}, point{2.0, 0.0}, point{1.0, 0.0}, point{1.0, 3.0}}));
    }
}

TEST(StableUniqueContainer, MoveConstructAndInsert) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    auto list = std::make_unique<xyfund::stable_unique_container<point, point_compare>>();
    list->insert(point{0.0, 0.0});
    list->insert(point{2.0, 0.0});
    list->insert(point{1.0, 0.0});
    EXPECT_EQ(list->data(), (std::vector<point>{point{0.0, 0.0}, point{2.0, 0.0}, point{1.0, 0.0}}));

    xyfund::stable_unique_container<point, point_compare> list2(std::move(*list));
    list = nullptr;

    EXPECT_EQ(list2.data(), (std::vector<point>{point{0.0, 0.0}, point{2.0, 0.0}, point{1.0, 0.0}}));

    {
        const auto [index, inserted] = list2.insert(point{2.0, 0.0});
        EXPECT_EQ(index, 1);
        EXPECT_FALSE(inserted);
        EXPECT_EQ(list2.data(), (std::vector<point>{point{0.0, 0.0}, point{2.0, 0.0}, point{1.0, 0.0}}));
    }
    {
        const auto [index, inserted] = list2.insert(point{1.0, 3.0});
        EXPECT_EQ(index, 3);
        EXPECT_TRUE(inserted);
        EXPECT_EQ(list2.data(), (std::vector<point>{point{0.0, 0.0}, point{2.0, 0.0}, point{1.0, 0.0}, point{1.0, 3.0}}));
    }
}

TEST(StableUniqueContainer, CopyAssignAndInsert) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    auto list = std::make_unique<xyfund::stable_unique_container<point, point_compare>>();
    list->insert(point{0.0, 0.0});
    list->insert(point{2.0, 0.0});
    list->insert(point{1.0, 0.0});
    EXPECT_EQ(list->data(), (std::vector<point>{point{0.0, 0.0}, point{2.0, 0.0}, point{1.0, 0.0}}));

    xyfund::stable_unique_container<point, point_compare> list2;
    list2 = *list;
    list  = nullptr;

    EXPECT_EQ(list2.data(), (std::vector<point>{point{0.0, 0.0}, point{2.0, 0.0}, point{1.0, 0.0}}));

    {
        const auto [index, inserted] = list2.insert(point{2.0, 0.0});
        EXPECT_EQ(index, 1);
        EXPECT_FALSE(inserted);
        EXPECT_EQ(list2.data(), (std::vector<point>{point{0.0, 0.0}, point{2.0, 0.0}, point{1.0, 0.0}}));
    }
    {
        const auto [index, inserted] = list2.insert(point{1.0, 3.0});
        EXPECT_EQ(index, 3);
        EXPECT_TRUE(inserted);
        EXPECT_EQ(list2.data(), (std::vector<point>{point{0.0, 0.0}, point{2.0, 0.0}, point{1.0, 0.0}, point{1.0, 3.0}}));
    }
}

TEST(StableUniqueContainer, MoveAssignAndInsert) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    auto list = std::make_unique<xyfund::stable_unique_container<point, point_compare>>();
    list->insert(point{0.0, 0.0});
    list->insert(point{2.0, 0.0});
    list->insert(point{1.0, 0.0});
    EXPECT_EQ(list->data(), (std::vector<point>{point{0.0, 0.0}, point{2.0, 0.0}, point{1.0, 0.0}}));

    xyfund::stable_unique_container<point, point_compare> list2;
    list2 = std::move(*list);
    list  = nullptr;

    EXPECT_EQ(list2.data(), (std::vector<point>{point{0.0, 0.0}, point{2.0, 0.0}, point{1.0, 0.0}}));

    {
        const auto [index, inserted] = list2.insert(point{2.0, 0.0});
        EXPECT_EQ(index, 1);
        EXPECT_FALSE(inserted);
        EXPECT_EQ(list2.data(), (std::vector<point>{point{0.0, 0.0}, point{2.0, 0.0}, point{1.0, 0.0}}));
    }
    {
        const auto [index, inserted] = list2.insert(point{1.0, 3.0});
        EXPECT_EQ(index, 3);
        EXPECT_TRUE(inserted);
        EXPECT_EQ(list2.data(), (std::vector<point>{point{0.0, 0.0}, point{2.0, 0.0}, point{1.0, 0.0}, point{1.0, 3.0}}));
    }
}


TEST(StableUniqueContainer, Release) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{   
    xyfund::stable_unique_container<point, point_compare> list;
    list.insert(point{0.0, 0.0});
    list.insert(point{2.0, 0.0});
    list.insert(point{1.0, 0.0});

    auto data = list.release();
    EXPECT_EQ(data, (std::vector<point>{point{0.0, 0.0}, point{2.0, 0.0}, point{1.0, 0.0}}));
    EXPECT_EQ(list.data(), (std::vector<point>{}));
}

//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <gtest/gtest.h>

#include <xyfund/functional.hpp>

TEST(Functional, Overload) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    int result = 0;

    const auto overloaded = xyfund::overload([&](int /*value*/) { result = 1; },
                                             [&](const std::string& /*value*/) { result = 2; });

    overloaded(5);
    EXPECT_EQ(result, 1);
    overloaded("ABC");
    EXPECT_EQ(result, 2);
}

TEST(Functional, OverloadReturn) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const auto overloaded = xyfund::overload([](int /*value*/) { return 1; },
                                             [](const std::string& /*value*/) { return 2; });

    EXPECT_EQ(overloaded(5), 1);
    EXPECT_EQ(overloaded("ABC"), 2);
}

TEST(Functional, OverloadReturnReference) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    int a = 0;
    int b = 0;

    const auto overloaded = xyfund::overload([&a](int /*value*/) -> int& { return a; },
                                             [&b](const std::string& /*value*/) -> int& { return b; });

    overloaded(5)     = 1;
    overloaded("ABC") = 2;

    EXPECT_EQ(a, 1);
    EXPECT_EQ(b, 2);
}

TEST(Functional, OverloadDifferentReturn) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const auto overloaded = xyfund::overload([](int /*value*/) { return 1; },
                                             [](const std::string& /*value*/) { return "B"; });

    EXPECT_EQ(overloaded(5), 1);
    EXPECT_STREQ(overloaded("ABC"), "B");
}

//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <gtest/gtest.h>

#include <xyfund/atomic.hpp>

TEST(Atomic, FetchMax) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    std::atomic<int> obj = 5;

    {
        const auto prev = xyfund::atomic_fetch_max(&obj, 10);
        EXPECT_EQ(prev, 5);
        EXPECT_EQ(obj.load(), 10);
    }

    {
        const auto prev = xyfund::atomic_fetch_max(&obj, 5);
        EXPECT_EQ(prev, 10);
        EXPECT_EQ(obj.load(), 10);
    }
}

TEST(Atomic, FetchMin) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    std::atomic<int> obj = 10;

    {
        const auto prev = xyfund::atomic_fetch_min(&obj, 5);
        EXPECT_EQ(prev, 10);
        EXPECT_EQ(obj.load(), 5);
    }

    {
        const auto prev = xyfund::atomic_fetch_min(&obj, 10);
        EXPECT_EQ(prev, 5);
        EXPECT_EQ(obj.load(), 5);
    }
}

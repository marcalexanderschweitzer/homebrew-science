//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <complex>

#include <gtest/gtest.h>

#include <xyfund/optional.hpp>

TEST(Optional, CompareOptValue) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    {
        const xyfund::optional<int> opt = xyfund::nullopt;
        const int value = 5;

        EXPECT_FALSE(opt == value);
        EXPECT_FALSE(value == opt);

        EXPECT_TRUE(opt != value);
        EXPECT_TRUE(value != opt);
        
        EXPECT_TRUE(opt < value);
        EXPECT_FALSE(value < opt);

        EXPECT_TRUE(opt <= value);
        EXPECT_FALSE(value <= opt);
        
        EXPECT_FALSE(opt > value);
        EXPECT_TRUE(value > opt);

        EXPECT_FALSE(opt >= value);
        EXPECT_TRUE(value >= opt);
    }
    {
        const xyfund::optional<int> opt = 5;
        const int value = 5;

        EXPECT_TRUE(opt == value);
        EXPECT_TRUE(value == opt);

        EXPECT_FALSE(opt != value);
        EXPECT_FALSE(value != opt);
        
        EXPECT_FALSE(opt < value);
        EXPECT_FALSE(value < opt);

        EXPECT_TRUE(opt <= value);
        EXPECT_TRUE(value <= opt);
        
        EXPECT_FALSE(opt > value);
        EXPECT_FALSE(value > opt);

        EXPECT_TRUE(opt >= value);
        EXPECT_TRUE(value >= opt);
    }
    {
        const xyfund::optional<int> opt = 2;
        const int value = 5;

        EXPECT_FALSE(opt == value);
        EXPECT_FALSE(value == opt);

        EXPECT_TRUE(opt != value);
        EXPECT_TRUE(value != opt);
        
        EXPECT_TRUE(opt < value);
        EXPECT_FALSE(value < opt);

        EXPECT_TRUE(opt <= value);
        EXPECT_FALSE(value <= opt);
        
        EXPECT_FALSE(opt > value);
        EXPECT_TRUE(value > opt);

        EXPECT_FALSE(opt >= value);
        EXPECT_TRUE(value >= opt);
    }
    {
        const xyfund::optional<int> opt = 8;
        const int value = 5;

        EXPECT_FALSE(opt == value);
        EXPECT_FALSE(value == opt);

        EXPECT_TRUE(opt != value);
        EXPECT_TRUE(value != opt);
        
        EXPECT_FALSE(opt < value);
        EXPECT_TRUE(value < opt);

        EXPECT_FALSE(opt <= value);
        EXPECT_TRUE(value <= opt);
        
        EXPECT_TRUE(opt > value);
        EXPECT_FALSE(value > opt);

        EXPECT_TRUE(opt >= value);
        EXPECT_FALSE(value >= opt);
    }
}

TEST(Optional, MakeConditional) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    {
        const auto opt = xyfund::make_optional_if<std::complex<double>>(false, 1.0, 2.0);
        EXPECT_FALSE(opt);
    }

    {
        const auto opt = xyfund::make_optional_if<std::complex<double>>(true, 1.0, 2.0);
        EXPECT_TRUE(opt);
        EXPECT_EQ(*opt, std::complex<double>(1.0, 2.0));
    }
}

TEST(OptionalRef, DefaultConstruct) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const xyfund::optional_ref<int> ref;

    EXPECT_FALSE(ref);
    EXPECT_FALSE(ref.has_value());

    EXPECT_TRUE(ref == xyfund::nullopt);
    EXPECT_TRUE(xyfund::nullopt == ref);
    EXPECT_FALSE(ref != xyfund::nullopt);
    EXPECT_FALSE(xyfund::nullopt != ref);

    ASSERT_THROW(ref.value(), xyfund::bad_optional_access); //NOLINT(cppcoreguidelines-avoid-goto)
}

TEST(OptionalRef, NulloptConstruct) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const xyfund::optional_ref<int> ref(xyfund::nullopt);

    EXPECT_FALSE(ref);
    EXPECT_FALSE(ref.has_value());

    EXPECT_TRUE(ref == xyfund::nullopt);
    EXPECT_TRUE(xyfund::nullopt == ref);
    EXPECT_FALSE(ref != xyfund::nullopt);
    EXPECT_FALSE(xyfund::nullopt != ref);

    ASSERT_THROW(ref.value(), xyfund::bad_optional_access); //NOLINT(cppcoreguidelines-avoid-goto)
}

TEST(OptionalRef, NulloptAssignConstruct) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const xyfund::optional_ref<int> ref = xyfund::nullopt;

    EXPECT_FALSE(ref);
    EXPECT_FALSE(ref.has_value());

    EXPECT_TRUE(ref == xyfund::nullopt);
    EXPECT_TRUE(xyfund::nullopt == ref);
    EXPECT_FALSE(ref != xyfund::nullopt);
    EXPECT_FALSE(xyfund::nullopt != ref);

    ASSERT_THROW(ref.value(), xyfund::bad_optional_access); //NOLINT(cppcoreguidelines-avoid-goto)
}

TEST(OptionalRef, IntRef) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    int x = 15;
    (void)x;
    const xyfund::optional_ref<int> ref(x);

    EXPECT_TRUE(ref);
    EXPECT_TRUE(ref.has_value());

    EXPECT_FALSE(ref == xyfund::nullopt);
    EXPECT_FALSE(xyfund::nullopt == ref);
    EXPECT_TRUE(ref != xyfund::nullopt);
    EXPECT_TRUE(xyfund::nullopt != ref);

    EXPECT_EQ(*ref, 15);
    EXPECT_EQ(ref.value(), 15);

    EXPECT_TRUE(ref == 15);
    EXPECT_TRUE(15 == ref);
    EXPECT_FALSE(ref == 10);
    EXPECT_FALSE(10 == ref);

    EXPECT_FALSE(ref != 15);
    EXPECT_FALSE(15 != ref);
    EXPECT_TRUE(ref != 10);
    EXPECT_TRUE(10 != ref);

    x = 5;
    EXPECT_EQ(*ref, 5);
    EXPECT_EQ(ref.value(), 5);

    ref.value() = 10;
    EXPECT_EQ(*ref, 10);
    EXPECT_EQ(ref.value(), 10);
    EXPECT_EQ(x, 10);

    *ref = 20;
    EXPECT_EQ(*ref, 20);
    EXPECT_EQ(ref.value(), 20);
    EXPECT_EQ(x, 20);
}

TEST(OptionalRef, ConstIntRef) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    int x = 15;
    (void)x;
    const xyfund::optional_ref<const int> ref(x);

    EXPECT_TRUE(ref);
    EXPECT_TRUE(ref.has_value());

    EXPECT_FALSE(ref == xyfund::nullopt);
    EXPECT_FALSE(xyfund::nullopt == ref);
    EXPECT_TRUE(ref != xyfund::nullopt);
    EXPECT_TRUE(xyfund::nullopt != ref);

    EXPECT_EQ(*ref, 15);
    EXPECT_EQ(ref.value(), 15);

    EXPECT_TRUE(ref == 15);
    EXPECT_TRUE(15 == ref);
    EXPECT_FALSE(ref == 10);
    EXPECT_FALSE(10 == ref);

    EXPECT_FALSE(ref != 15);
    EXPECT_FALSE(15 != ref);
    EXPECT_TRUE(ref != 10);
    EXPECT_TRUE(10 != ref);

    x = 5;
    (void)x;
    EXPECT_EQ(*ref, 5);
    EXPECT_EQ(ref.value(), 5);
}

TEST(OptionalRef, OptionalIntRef) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::optional<int> x = 15;
    (void)x;
    const xyfund::optional_ref<int> ref(x);

    EXPECT_TRUE(ref);
    EXPECT_TRUE(ref.has_value());

    EXPECT_FALSE(ref == xyfund::nullopt);
    EXPECT_FALSE(xyfund::nullopt == ref);
    EXPECT_TRUE(ref != xyfund::nullopt);
    EXPECT_TRUE(xyfund::nullopt != ref);

    EXPECT_EQ(*ref, 15);
    EXPECT_EQ(ref.value(), 15);

    EXPECT_TRUE(ref == 15);
    EXPECT_TRUE(15 == ref);
    EXPECT_FALSE(ref == 10);
    EXPECT_FALSE(10 == ref);

    EXPECT_FALSE(ref != 15);
    EXPECT_FALSE(15 != ref);
    EXPECT_TRUE(ref != 10);
    EXPECT_TRUE(10 != ref);

    x = 5;
    EXPECT_EQ(*ref, 5);
    EXPECT_EQ(ref.value(), 5);

    ref.value() = 10;
    EXPECT_EQ(*ref, 10);
    EXPECT_EQ(ref.value(), 10);
    EXPECT_EQ(x, 10);

    *ref = 20;
    EXPECT_EQ(*ref, 20);
    EXPECT_EQ(ref.value(), 20);
    EXPECT_EQ(x, 20);
}

TEST(OptionalRef, OptionalIntEmpty) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::optional<int> x;
    (void)x;
    const xyfund::optional_ref<int> ref(x);

    EXPECT_FALSE(ref);
    EXPECT_FALSE(ref.has_value());

    EXPECT_TRUE(ref == xyfund::nullopt);
    EXPECT_TRUE(xyfund::nullopt == ref);
    EXPECT_FALSE(ref != xyfund::nullopt);
    EXPECT_FALSE(xyfund::nullopt != ref);
}

TEST(OptionalRef, OptionalConstIntRef) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::optional<int> x = 15;
    (void)x;
    const xyfund::optional_ref<const int> ref(x);

    EXPECT_TRUE(ref);
    EXPECT_TRUE(ref.has_value());

    EXPECT_FALSE(ref == xyfund::nullopt);
    EXPECT_FALSE(xyfund::nullopt == ref);
    EXPECT_TRUE(ref != xyfund::nullopt);
    EXPECT_TRUE(xyfund::nullopt != ref);

    EXPECT_EQ(*ref, 15);
    EXPECT_EQ(ref.value(), 15);

    EXPECT_TRUE(ref == 15);
    EXPECT_TRUE(15 == ref);
    EXPECT_FALSE(ref == 10);
    EXPECT_FALSE(10 == ref);

    EXPECT_FALSE(ref != 15);
    EXPECT_FALSE(15 != ref);
    EXPECT_TRUE(ref != 10);
    EXPECT_TRUE(10 != ref);

    x = 5;
    (void)x;
    EXPECT_EQ(*ref, 5);
    EXPECT_EQ(ref.value(), 5);
}
TEST(OptionalRef, ConstOptionalConstIntRef) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const xyfund::optional<int> x = 15;
    (void)x;
    const xyfund::optional_ref<const int> ref(x);

    EXPECT_TRUE(ref);
    EXPECT_TRUE(ref.has_value());

    EXPECT_FALSE(ref == xyfund::nullopt);
    EXPECT_FALSE(xyfund::nullopt == ref);
    EXPECT_TRUE(ref != xyfund::nullopt);
    EXPECT_TRUE(xyfund::nullopt != ref);

    EXPECT_EQ(*ref, 15);
    EXPECT_EQ(ref.value(), 15);

    EXPECT_TRUE(ref == 15);
    EXPECT_TRUE(15 == ref);
    EXPECT_FALSE(ref == 10);
    EXPECT_FALSE(10 == ref);

    EXPECT_FALSE(ref != 15);
    EXPECT_FALSE(15 != ref);
    EXPECT_TRUE(ref != 10);
    EXPECT_TRUE(10 != ref);
}

TEST(OptionalRef, OptionalConstIntEmpty) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::optional<int> x;
    (void)x;
    const xyfund::optional_ref<const int> ref(x);

    EXPECT_FALSE(ref);
    EXPECT_FALSE(ref.has_value());

    EXPECT_TRUE(ref == xyfund::nullopt);
    EXPECT_TRUE(xyfund::nullopt == ref);
    EXPECT_FALSE(ref != xyfund::nullopt);
    EXPECT_FALSE(xyfund::nullopt != ref);
}

TEST(OptionalRef, StringRef) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    std::string x = "a";
    (void)x;
    const xyfund::optional_ref<std::string> ref(x);

    std::string y = "a";
    (void)y;
    const xyfund::optional_ref<std::string> ref_b(y);

    std::string z = "b";
    (void)z;
    const xyfund::optional_ref<std::string> ref_c(z);

    EXPECT_TRUE(ref);
    EXPECT_TRUE(ref.has_value());

    EXPECT_FALSE(ref == xyfund::nullopt);
    EXPECT_FALSE(xyfund::nullopt == ref);
    EXPECT_TRUE(ref != xyfund::nullopt);
    EXPECT_TRUE(xyfund::nullopt != ref);

    EXPECT_EQ(*ref, "a");
    EXPECT_EQ(ref.value(), "a");

    EXPECT_TRUE(ref == "a");
    EXPECT_TRUE("a" == ref);
    EXPECT_FALSE(ref == "b");
    EXPECT_FALSE("b" == ref);

    EXPECT_FALSE(ref != "a");
    EXPECT_FALSE("a" != ref);
    EXPECT_TRUE(ref != "b");
    EXPECT_TRUE("b" != ref);

    EXPECT_TRUE(ref == ref_b);
    EXPECT_TRUE(ref_b == ref);
    EXPECT_FALSE(ref == ref_c);
    EXPECT_FALSE(ref_c == ref);

    EXPECT_FALSE(ref != ref_b);
    EXPECT_FALSE(ref_b != ref);
    EXPECT_TRUE(ref != ref_c);
    EXPECT_TRUE(ref_c != ref);

    x = "b";
    EXPECT_EQ(*ref, "b");
    EXPECT_EQ(ref.value(), "b");

    ref.value() = "c";
    EXPECT_EQ(*ref, "c");
    EXPECT_EQ(ref.value(), "c");
    EXPECT_EQ(x, "c");

    *ref = "d";
    EXPECT_EQ(*ref, "d");
    EXPECT_EQ(ref.value(), "d");
    EXPECT_EQ(x, "d");

    EXPECT_EQ(ref->size(), 1);

    ref->assign("e");
    EXPECT_EQ(*ref, "e");
    EXPECT_EQ(ref.value(), "e");
    EXPECT_EQ(x, "e");
}

TEST(OptionalRef, ConstStringRef) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    std::string x = "a";
    (void)x;
    const xyfund::optional_ref<const std::string> ref(x);

    EXPECT_TRUE(ref);
    EXPECT_TRUE(ref.has_value());

    EXPECT_FALSE(ref == xyfund::nullopt);
    EXPECT_FALSE(xyfund::nullopt == ref);
    EXPECT_TRUE(ref != xyfund::nullopt);
    EXPECT_TRUE(xyfund::nullopt != ref);

    EXPECT_EQ(*ref, "a");
    EXPECT_EQ(ref.value(), "a");

    x = "b";
    EXPECT_EQ(*ref, "b");
    EXPECT_EQ(ref.value(), "b");

    EXPECT_EQ(ref->size(), 1);
}

struct string_holder
{
    std::string x_; // NOLINT(misc-non-private-member-variables-in-classes)

    xyfund::optional_ref<std::string>       get() { return x_; }
    xyfund::optional_ref<const std::string> get() const { return x_; }

    xyfund::optional_ref<std::string>       get_if(bool b) { return b ? xyfund::make_optional_ref(x_) : xyfund::nullopt; }
    xyfund::optional_ref<const std::string> get_if(bool b) const { return b ? xyfund::make_optional_ref(x_) : xyfund::nullopt; }
};

TEST(OptionalRef, GetFromClass) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    string_holder a{"a"};

    const auto ref = a.get();
    EXPECT_TRUE(ref);
    EXPECT_EQ(*ref, "a");

    ref->assign("b");

    const auto const_ref = ((const string_holder&)a).get();
    EXPECT_TRUE(const_ref);
    EXPECT_EQ(*const_ref, "b");

    const auto ref2 = a.get_if(true);
    EXPECT_TRUE(ref2);
    EXPECT_EQ(*ref2, "b");

    ref->assign("c");

    const auto const_ref2 = ((const string_holder&)a).get_if(true);
    EXPECT_TRUE(const_ref2);
    EXPECT_EQ(*const_ref2, "c");

    const auto null_ref = a.get_if(false);
    EXPECT_FALSE(null_ref);

    const auto const_null_ref = ((const string_holder&)a).get_if(false);
    EXPECT_FALSE(const_null_ref);
}

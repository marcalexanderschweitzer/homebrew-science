//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <gtest/gtest.h>

#include <xyfund/system.hpp>

TEST(System, HomeDir) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const auto home_dir = xyfund::get_home_dir();
    (void)home_dir;
    // TODO: how-to test this
}

TEST(System, ModuleDir) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const auto module_dir = xyfund::get_module_dir();
    (void)module_dir;
    // TODO: how-to test this
}

TEST(System, GetEnvVar) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const auto env_null = xyfund::get_environment_variable("SOME_NAME_THAT_MOST_PROBABLY_DOES_NOT_EXIST");
    EXPECT_TRUE(!env_null);

#ifdef _WIN32
    const auto env_prog_files = xyfund::get_environment_variable("ProgramFiles");
    EXPECT_EQ(*env_prog_files, "C:\\Program Files");
#else
    const auto env_path = xyfund::get_environment_variable("PATH");
    EXPECT_TRUE(env_path);
    // TODO: how-to test this
#endif // _WIN32
}

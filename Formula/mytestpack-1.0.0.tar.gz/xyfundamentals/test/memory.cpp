//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <gtest/gtest.h>

#include <xyfund/memory.hpp>

TEST(Memory, ToSharedPtrFromTemp) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const auto sptr = xyfund::to_shared_ptr(std::make_unique<int>(5));
    EXPECT_EQ(*sptr, 5);
}

TEST(Memory, ToSharedPtrFromMove) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    auto uptr = std::make_unique<int>(5);
    EXPECT_EQ(*uptr, 5);
    const auto rptr = uptr.get(); // NOLINT(readability-qualified-auto)
    const auto sptr = xyfund::to_shared_ptr(std::move(uptr));
    EXPECT_TRUE(uptr == nullptr);
    EXPECT_TRUE(sptr.get() == rptr);
    EXPECT_EQ(*sptr, 5);
}

//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#pragma once

#include <string>

class plugin_interface
{
public:
    virtual ~plugin_interface(){};

    virtual std::string name() = 0;
};

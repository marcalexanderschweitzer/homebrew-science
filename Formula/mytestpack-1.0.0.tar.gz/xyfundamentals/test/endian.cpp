//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <gtest/gtest.h>

#include <xyfund/endian.hpp>

TEST(Endian, Check) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    EXPECT_TRUE(xyfund::endian::native == xyfund::endian::big || xyfund::endian::native == xyfund::endian::little);
    EXPECT_TRUE(xyfund::endian::native != xyfund::endian::big || (xyfund::endian::native == xyfund::endian::big && xyfund::endian::native != xyfund::endian::little));
    EXPECT_TRUE(xyfund::endian::native != xyfund::endian::little || (xyfund::endian::native == xyfund::endian::little && xyfund::endian::native != xyfund::endian::big));
}

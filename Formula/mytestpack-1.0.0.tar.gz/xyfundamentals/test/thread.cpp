//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <atomic>

#include <gtest/gtest.h>

#include <xyfund/thread.hpp>

TEST(EnumerableThreadSpecific, SingleThread) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::enumerable_thread_specific<int> thread_local_data;

    // NOTE: Own workaround implementation does not currently match the TBB implementation:
    //       Our own implementation always holds a local element, in contrast to TBB which
    //       only constructs the local entry on the first call to local().
#ifdef XYFUND_HAVE_TBB
    EXPECT_EQ(thread_local_data.size(), 0);
    EXPECT_TRUE(thread_local_data.empty());
#endif

    bool exists = false;

    auto& local_data = thread_local_data.local(exists);
#ifdef XYFUND_HAVE_TBB
    EXPECT_FALSE(exists);
#endif
    local_data = 2;

    auto& local_data2 = thread_local_data.local(exists);
    EXPECT_TRUE(exists);
    EXPECT_EQ(local_data2, 2);

    auto& local_data3 = thread_local_data.local();
    EXPECT_EQ(local_data3, 2);

    EXPECT_EQ(thread_local_data.size(), 1);
    EXPECT_FALSE(thread_local_data.empty());

    auto       begin = thread_local_data.begin();
    const auto end   = thread_local_data.end();
    ASSERT_TRUE(begin != end);
    EXPECT_EQ(*begin, 2);
    ++begin;
    ASSERT_TRUE(begin == end);

    const auto& const_thread_local_data = thread_local_data;
    auto        cbegin                  = const_thread_local_data.begin();
    const auto  cend                    = const_thread_local_data.end();
    ASSERT_TRUE(cbegin != cend);
    EXPECT_EQ(*cbegin, 2);
    ++cbegin;
    ASSERT_TRUE(cbegin == cend);
}

TEST(ParallelFor, Count) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    std::atomic<int> count = 1;
    xyfund::parallel_for(10, 100, [&count](int i) {
        count += i;
    });
    EXPECT_EQ(count.load(), 4906);
}

TEST(ConditionalParallelFor, Count) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    int seq_count = 1;
    xyfund::conditional_parallel_for(false, 10, 100, [&seq_count](int i) {
        seq_count += i;
    });
    EXPECT_EQ(seq_count, 4906);

    std::atomic<int> par_count = 1;
    xyfund::conditional_parallel_for(true, 10, 100, [&par_count](int i) {
        par_count += i;
    });
    EXPECT_EQ(par_count.load(), 4906);
}
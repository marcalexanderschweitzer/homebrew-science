//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <string>

#include <gtest/gtest.h>

#include <xyfund/flat_map.hpp>

struct custom_key
{
    int data_;
};

TEST(FlatMap_Int_String, DefaultConstruct) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::flat_map<int, std::string> map;
    EXPECT_TRUE(map.empty());
    EXPECT_EQ(map.size(), 0);
    (void)map;
}

TEST(FlatMap_Custom_String, CustomCompare) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    auto compare = [](const custom_key& lhs, const custom_key& rhs) { return lhs.data_ < rhs.data_; };

    xyfund::flat_map<custom_key, std::string, decltype(compare)> map(std::move(compare));
    EXPECT_TRUE(map.empty());
    EXPECT_EQ(map.size(), 0);
    (void)map;
}

TEST(FlatMap_Int_String, Insert) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::flat_map<int, std::string> map;

    const auto [iter, inserted] = map.insert(std::make_pair(10, std::string("A")));
    EXPECT_TRUE(inserted);
    ASSERT_NE(iter, map.end());
    EXPECT_EQ(iter->first, 10);
    EXPECT_EQ(iter->second, "A");

    EXPECT_FALSE(map.empty());
    EXPECT_EQ(map.size(), 1);
}

TEST(FlatMap_Int_String, Find) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::flat_map<int, std::string> map;
    const auto&                        cmap = map;

    EXPECT_EQ(cmap.find(10), cmap.end());

    map.insert(std::make_pair(10, std::string("A")));

    const auto iter = cmap.find(10);
    ASSERT_NE(iter, cmap.end());
    EXPECT_EQ(iter->first, 10);
    EXPECT_EQ(iter->second, "A");

    EXPECT_EQ(cmap.find(20), cmap.end());
}

TEST(FlatMap_Int_String, Access) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::flat_map<int, std::string> map;

    map[10] = "A";

    EXPECT_EQ(map[10], "A");
}

TEST(FlatMap_Int_String, At) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::flat_map<int, std::string> map;
    const auto&                        cmap = map;

    EXPECT_THROW(map.at(10), std::out_of_range); // NOLINT(cppcoreguidelines-avoid-goto)

    map[10] = "A";

    EXPECT_EQ(cmap.at(10), "A");
}
//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <gtest/gtest.h>

#ifdef XYFUND_NO_ASSERT
#    undef XYFUND_NO_ASSERT
#endif

#include <xyfund/assert.hpp>

TEST(Assert, Fail) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    ASSERT_DEATH(xyfund_assert(1 == 0), "assertion 1 == 0 failed in .*assert\\.cpp:18"); // NOLINT(cppcoreguidelines-avoid-goto, cppcoreguidelines-pro-type-vararg)
}

TEST(Assert, FailMessage) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    ASSERT_DEATH(xyfund_assert(1 == 0, "always false"), "assertion 1 == 0 failed in .*assert\\.cpp:23: always false"); // NOLINT(cppcoreguidelines-avoid-goto, cppcoreguidelines-pro-type-vararg)
}

TEST(Assert, Succeed) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund_assert(1 == 1);
}

TEST(Assert, SucceedMessage) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund_assert(1 == 1, "always true");
}

//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <gtest/gtest.h>

#include <xyfund/dl.hpp>

#include "dll_interface.hpp"

TEST(Dll, LoadDecorate) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::dl::shared_library sl("test_dll_lib", xyfund::dl::shared_library::add_decorations);
    EXPECT_TRUE(sl);
}

TEST(Dll, LoadDecorateAbsolute) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::dl::shared_library sl(xyfund::filesystem::current_path() / "test_dll_lib", xyfund::dl::shared_library::add_decorations);
    EXPECT_TRUE(sl);
}

TEST(Dll, MoveConstruct) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::dl::shared_library sl1("test_dll_lib", xyfund::dl::shared_library::add_decorations);
    EXPECT_TRUE(sl1);
    xyfund::dl::shared_library sl2(std::move(sl1));
    EXPECT_TRUE(sl2);
}

TEST(Dll, MoveCopyIntoDefault) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::dl::shared_library sl1;
    EXPECT_FALSE(sl1);
    xyfund::dl::shared_library sl2("test_dll_lib", xyfund::dl::shared_library::add_decorations);
    EXPECT_TRUE(sl2);
    sl1 = std::move(sl2);
    EXPECT_TRUE(sl1);
}

TEST(Dll, LoadExplicit) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
#if defined(_WIN32)
    xyfund::dl::shared_library sl("test_dll_lib.dll");
#elif defined(__APPLE__)
    xyfund::dl::shared_library sl("libtest_dll_lib.dylib");
#else
    xyfund::dl::shared_library sl("libtest_dll_lib.so");
#endif
    EXPECT_TRUE(sl);
}

TEST(Dll, LoadExplicitAbsolute) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
#if defined(_WIN32)
    xyfund::dl::shared_library sl(xyfund::filesystem::current_path() / "test_dll_lib.dll");
#elif defined(__APPLE__)
    xyfund::dl::shared_library sl(xyfund::filesystem::current_path() / "libtest_dll_lib.dylib");
#else
    xyfund::dl::shared_library sl(xyfund::filesystem::current_path() / "libtest_dll_lib.so");
#endif
    EXPECT_TRUE(sl);
}

TEST(Dll, LoadNotAvailable) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    ASSERT_THROW(xyfund::dl::shared_library sl("not_available"), std::system_error); //NOLINT(cppcoreguidelines-avoid-goto)
}

TEST(Dll, ImportIfSimpleFreeFunction) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::dl::shared_library sl("test_dll_lib", xyfund::dl::shared_library::add_decorations);
    ASSERT_TRUE(sl);

    const auto add = sl.get_if<int(int, int)>("add");
    EXPECT_FALSE(add == nullptr);

    // Disable linting since clang-tidy obviously has a false-positive here: if the pointer would be null the test above would have failed.
    const auto result = (*add)(1, 2); // NOLINT(clang-analyzer-core.CallAndMessage)

    EXPECT_EQ(result, 3);
}

TEST(Dll, ImportSimpleFreeFunction) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::dl::shared_library sl("test_dll_lib", xyfund::dl::shared_library::add_decorations);
    ASSERT_TRUE(sl);

    const auto& add = sl.get<int(int, int)>("add");

    const auto result = add(1, 2);

    EXPECT_EQ(result, 3);
}

TEST(Dll, ImportIfNotAvailable) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::dl::shared_library sl("test_dll_lib", xyfund::dl::shared_library::add_decorations);
    ASSERT_TRUE(sl);

    const auto not_available = sl.get_if<int(int, int)>("not_available");
    EXPECT_TRUE(not_available == nullptr);
}

TEST(Dll, ImportNotAvailable) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::dl::shared_library sl("test_dll_lib", xyfund::dl::shared_library::add_decorations);
    ASSERT_TRUE(sl);

    ASSERT_THROW(sl.get<int(int, int)>("not_available"), std::system_error); //NOLINT(cppcoreguidelines-avoid-goto)
}

TEST(Dll, PluginObject) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::dl::shared_library sl("test_dll_lib", xyfund::dl::shared_library::add_decorations);
    ASSERT_TRUE(sl);

    auto& plugin = sl.get<plugin_interface>("plugin_1");

    EXPECT_EQ(plugin.name(), "plugin_1");
}

TEST(Dll, PluginFactory) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    xyfund::dl::shared_library sl("test_dll_lib", xyfund::dl::shared_library::add_decorations);
    ASSERT_TRUE(sl);

    const auto& plugin_create = *sl.get<std::shared_ptr<plugin_interface> (*)(int)>("create_plugin_2_ptr");

    const auto plugin_a = plugin_create(5);
    ASSERT_TRUE(plugin_a != nullptr);
    EXPECT_EQ(plugin_a->name(), "plugin_2(5)");

    const auto plugin_b = plugin_create(45);
    ASSERT_TRUE(plugin_b != nullptr);
    EXPECT_EQ(plugin_b->name(), "plugin_2(45)");
}

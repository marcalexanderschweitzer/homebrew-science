//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <array>

#include <gtest/gtest.h>

#include <xyfund/meta.hpp>

template<typename T, typename U>
struct add_c
{
    using type = xyfund::mp::int_c<T::value + U::value>;
};
template<typename T, typename U>
using add_c_t = typename add_c<T, U>::type;

template<typename T, typename U>
struct mult_c
{
    using type = xyfund::mp::int_c<T::value * U::value>;
};
template<typename T, typename U>
using mult_c_t = typename mult_c<T, U>::type;

template<typename T1, typename T2, typename T3>
using mult_add_c_t = add_c_t<mult_c_t<T1, T2>, T3>; // (T1 * T2) + T3

// We use a function call here, so that in case of an error the compiler
// will show us the types of T and U in the error message
template<typename T, typename U>
void is_same()
{
    static_assert(std::is_same<T, U>::value, "Failed!");
}

TEST(Meta, ListElement) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    using list = xyfund::mp::list<int, char, long>;
    is_same<xyfund::mp::list_element_t<0, list>, int>();
    is_same<xyfund::mp::list_element_t<1, list>, char>();
    is_same<xyfund::mp::list_element_t<2, list>, long>();

    using tuple = std::tuple<int, char, long>;
    is_same<xyfund::mp::list_element_t<0, tuple>, int>();
    is_same<xyfund::mp::list_element_t<1, tuple>, char>();
    is_same<xyfund::mp::list_element_t<2, tuple>, long>();

    using int_range = xyfund::mp::integer_range<int, 2, 5>;
    is_same<xyfund::mp::list_element_t<0, int_range>, xyfund::mp::int_c<2>>();
    is_same<xyfund::mp::list_element_t<1, int_range>, xyfund::mp::int_c<3>>();
    is_same<xyfund::mp::list_element_t<2, int_range>, xyfund::mp::int_c<4>>();
}

TEST(Meta, Rename) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    is_same<
        xyfund::mp::rename_t<xyfund::mp::list<int, double, float>, std::tuple>,
        std::tuple<int, double, float>>();
}

TEST(Meta, Append) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    is_same<
        xyfund::mp::append_t<xyfund::mp::list<int, double>, xyfund::mp::list<float, bool>>,
        xyfund::mp::list<int, double, float, bool>>();
}

TEST(Meta, PushFront) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    is_same<
        xyfund::mp::push_front_t<xyfund::mp::list<int, double>, float>,
        xyfund::mp::list<float, int, double>>();
}

TEST(Meta, PushBack) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    is_same<
        xyfund::mp::push_back_t<xyfund::mp::list<int, double>, float>,
        xyfund::mp::list<int, double, float>>();
}

TEST(Meta, PopFront) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    is_same<
        xyfund::mp::pop_front_t<xyfund::mp::list<int, double, float>>,
        xyfund::mp::list<double, float>>();
}

TEST(Meta, Assign) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    is_same<
        xyfund::mp::assign_t<std::tuple<>, xyfund::mp::list<int, double, float>>,
        std::tuple<int, double, float>>();
}

#if !defined(_MSC_VER) || (_MSC_VER != 1915)
TEST(Meta, Bind) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    using xyfund::mp::int_c;

    is_same<xyfund::mp::bind<mult_add_c_t, xyfund::mp::_0, int_c<2>, int_c<3>>::type<int_c<4>>, int_c<11>>();
    is_same<xyfund::mp::bind<mult_add_c_t, int_c<2>, xyfund::mp::_0, int_c<3>>::type<int_c<4>>, int_c<11>>();
    is_same<xyfund::mp::bind<mult_add_c_t, int_c<2>, int_c<3>, xyfund::mp::_0>::type<int_c<4>>, int_c<10>>();

    is_same<xyfund::mp::bind<mult_add_c_t, xyfund::mp::_1, xyfund::mp::_0, int_c<3>>::type<int_c<4>, int_c<5>>, int_c<23>>();
    is_same<xyfund::mp::bind<mult_add_c_t, int_c<2>, xyfund::mp::_0, xyfund::mp::_1>::type<int_c<4>, int_c<5>>, int_c<13>>();
    is_same<xyfund::mp::bind<mult_add_c_t, int_c<2>, xyfund::mp::_1, xyfund::mp::_0>::type<int_c<4>, int_c<5>>, int_c<14>>();
}
#endif

TEST(Meta, Transform) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    is_same<
        xyfund::mp::transform_t<std::add_pointer_t, xyfund::mp::list<int, char, bool>>,
        xyfund::mp::list<int*, char*, bool*>>();
}

TEST(Meta, Reverse) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    is_same<
        xyfund::mp::reverse_t<xyfund::mp::list<int, char, bool>>,
        xyfund::mp::list<bool, char, int>>();

    is_same<
        xyfund::mp::reverse_t<xyfund::mp::list<int, char, bool, long, std::string, float, double, short, unsigned int, unsigned long, long long, unsigned long long>>,
        xyfund::mp::list<unsigned long long, long long, unsigned long, unsigned int, short, double, float, std::string, long, bool, char, int>>();
}

TEST(Meta, Accumulate) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    using xyfund::mp::int_c;

    is_same<xyfund::mp::accumulate_t<add_c_t, int_c<2>, xyfund::mp::list<int_c<1>, int_c<2>, int_c<3>>>, int_c<8>>();
}

TEST(Meta, CountIf) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    using xyfund::mp::size_c;

    is_same<xyfund::mp::count_if_t<xyfund::mp::list<int, short, std::string, int, long, std::vector<int>>, std::is_integral>, size_c<4>>();
    is_same<xyfund::mp::count_if_t<xyfund::mp::list<int, short, std::string, int, long, std::vector<int>>, std::is_class>, size_c<2>>();
    is_same<xyfund::mp::count_if_t<xyfund::mp::list<int, short, std::string, int, long, std::vector<int>>, std::is_reference>, size_c<0>>();
}

TEST(Meta, Product) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    is_same<
        xyfund::mp::product_t<std::pair, xyfund::mp::list<int, char>, xyfund::mp::list<float, long>>,
        xyfund::mp::list<std::pair<int, float>, std::pair<int, long>, std::pair<char, float>, std::pair<char, long>>>();
}

TEST(Meta, FindIf) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    using xyfund::mp::size_c;

    is_same<xyfund::mp::find_if_t<xyfund::mp::list<int, short, std::string, int, long, std::vector<int>>, std::is_integral>, size_c<0>>();
    is_same<xyfund::mp::find_if_t<xyfund::mp::list<int, short, std::string, int, long, std::vector<int>>, std::is_class>, size_c<2>>();
    is_same<xyfund::mp::find_if_t<xyfund::mp::list<int, short, std::string, int, long, std::vector<int>>, std::is_reference>, size_c<6>>();
}

TEST(Meta, SetContains) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    static_assert(xyfund::mp::set_contains_v<xyfund::mp::list<int, char, long, float>, int>, "xyfund::mp::set_contains_v<...>");
    static_assert(!xyfund::mp::set_contains_v<xyfund::mp::list<int, char, long, float>, double>, "!xyfund::mp::set_contains_v<...>");
}

TEST(Meta, SetPushBack) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    is_same<
        xyfund::mp::set_push_back_t<xyfund::mp::list<int, char, long>, double>,
        xyfund::mp::list<int, char, long, double>>();

    is_same<
        xyfund::mp::set_push_back_t<xyfund::mp::list<int, char, long>, int>,
        xyfund::mp::list<int, char, long>>();

    is_same<
        xyfund::mp::set_push_back_t<xyfund::mp::list<int, char, long>, long>,
        xyfund::mp::list<int, char, long>>();
}

TEST(Meta, Unique) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    is_same<
        xyfund::mp::unique_t<xyfund::mp::list<int, char, long, long, int, float>>,
        xyfund::mp::list<int, char, long, float>>();
}

TEST(Meta, ForEachTuple) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const std::tuple<int, std::string, int> list = {0, "abc", 5};

    std::stringstream ss;
    xyfund::mp::for_each(list, [&ss](const auto& entry) {
        ss << entry;
    });
    EXPECT_STREQ(ss.str().c_str(), "0abc5");
}

TEST(Meta, ForEachIntList) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    using xyfund::mp::int_c;

    constexpr xyfund::mp::list<int_c<0>, int_c<1>, int_c<2>, int_c<3>> list;

    std::stringstream ss;
    xyfund::mp::for_each(list, [&ss](const auto entry) {
        constexpr int i = decltype(entry)::value;

        ss << i;

        std::array<int, i> arr{};
        (void)arr;
    });
    EXPECT_STREQ(ss.str().c_str(), "0123");
}

TEST(Meta, ForEachIntRange) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    std::stringstream ss;
    xyfund::mp::for_each(xyfund::mp::integer_range<int, 2, 5>(), [&ss](const auto entry) {
        constexpr int i = decltype(entry)::value;

        ss << i;

        std::array<int, i> arr{};
        (void)arr;
    });
    EXPECT_STREQ(ss.str().c_str(), "234");
}

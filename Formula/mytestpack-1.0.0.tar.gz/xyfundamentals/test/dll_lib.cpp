//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <memory>

#include "dll_lib_export.hpp"

#include "dll_interface.hpp"

class plugin_impl_1 : public plugin_interface
{
public:
    std::string name() override
    {
        return "plugin_1";
    }
};

class plugin_impl_2 : public plugin_interface
{
public:
    plugin_impl_2(int i) :
        i_(i)
    {}

    std::string name() override
    {
        return "plugin_2(" + std::to_string(i_) + ")";
    }

private:
    int i_;
};

std::shared_ptr<plugin_interface> create_plugin_2(int i)
{
    return std::make_shared<plugin_impl_2>(i);
}

extern "C" {

TEST_DLL_LIB_EXPORT int add(int a, int b)
{
    return a + b;
}

// NOLINTNEXTLINE(cppcoreguidelines-avoid-non-const-global-variables)
TEST_DLL_LIB_EXPORT plugin_impl_1 plugin_1;

// NOLINTNEXTLINE(cppcoreguidelines-pro-type-reinterpret-cast, cppcoreguidelines-avoid-non-const-global-variables)
TEST_DLL_LIB_EXPORT const void* create_plugin_2_ptr = reinterpret_cast<const void*>(reinterpret_cast<intptr_t>(&create_plugin_2));

} // extern "C"

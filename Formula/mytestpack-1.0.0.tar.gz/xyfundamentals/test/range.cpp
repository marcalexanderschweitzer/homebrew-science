//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <vector>

#include <gtest/gtest.h>

#include <xyfund/range.hpp>

#include <xyfund/types.hpp>
#include <xyfund/utility.hpp>

TEST(IteratorRange, VectorRange) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    const std::vector<int> v = {1, 2, 3, 4, 5, 6};

    using vector_range_type = xyfund::iterator_range<std::vector<int>::const_iterator>;

    xyfund::index_t i = 0;
    for(const auto value : vector_range_type(v.begin(), v.end()))
    {
        EXPECT_EQ(value, v[i++]);
    }
    EXPECT_EQ(i, xyfund::ssize(v));
}

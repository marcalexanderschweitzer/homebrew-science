//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <functional>

#include <gtest/gtest.h>

#include <xyfund/traits.hpp>

TEST(Traits, Conjunction) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    static_assert(xyfund::conjunction_v<std::is_same<int, int>, std::is_same<double, double>>, "xyfund::conjunction_v<std::is_same<int, int>, std::is_same<double, double>>");
    static_assert(!xyfund::conjunction_v<std::is_same<int, int>, std::is_same<double, int>>, "!xyfund::conjunction_v<std::is_same<int, int>, std::is_same<double, int>>");
}

TEST(Traits, Disjunction) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    static_assert(xyfund::disjunction_v<std::is_same<int, int>, std::is_same<double, int>>, "xyfund::disjunction_v<std::is_same<int, int>, std::is_same<double, int>>");
    static_assert(!xyfund::disjunction_v<std::is_same<int, double>, std::is_same<double, int>>, "!xyfund::disjunction_v<std::is_same<int, double>, std::is_same<double, int>>");
}

TEST(Traits, HasType) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    static_assert(xyfund::has_type_v<int, std::tuple<double, int, std::string>>, "xyfund::has_type_v<int, std::tuple<double, int, std::string>>");
}

TEST(Traits, DependentFalse) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    static_assert(!xyfund::dependent_false_v<int>, "!xyfund::dependent_false_v<int>");
}

TEST(Traits, IsSharedPtr) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    static_assert(!xyfund::is_shared_ptr_v<int>, "xyfund::is_shared_ptr_v<...>");
    static_assert(!xyfund::is_shared_ptr_v<int*>, "xyfund::is_shared_ptr_v<...>");
    static_assert(!xyfund::is_shared_ptr_v<std::unique_ptr<int>>, "xyfund::is_shared_ptr_v<...>");
    static_assert(xyfund::is_shared_ptr_v<std::shared_ptr<int>>, "xyfund::is_shared_ptr_v<...>");
}

struct int_wrapper
{
    int_wrapper(int a) :
        a_(a)
    {}

    int a_; // NOLINT(misc-non-private-member-variables-in-classes)
};

TEST(Traits, Deref) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    int_wrapper  obj{1};
    int_wrapper* ptr = &obj;

    const auto unique = std::make_unique<int_wrapper>(1);
    const auto shared = std::make_shared<int_wrapper>(1);
    const auto ref = std::ref(obj);
    const auto cref = std::cref(obj);

    EXPECT_EQ(xyfund::deref(obj).a_, 1);
    EXPECT_EQ(xyfund::deref(ptr).a_, 1);
    EXPECT_EQ(xyfund::deref(unique).a_, 1);
    EXPECT_EQ(xyfund::deref(shared).a_, 1);
    EXPECT_EQ(xyfund::deref(ref).a_, 1);
    EXPECT_EQ(xyfund::deref(cref).a_, 1);

    static_assert(std::is_same_v<xyfund::deref_type_t<int_wrapper>, int_wrapper&>);
    static_assert(std::is_same_v<xyfund::deref_type_t<const int_wrapper>, const int_wrapper&>);
    static_assert(std::is_same_v<xyfund::deref_type_t<int_wrapper&>, int_wrapper&>);
    static_assert(std::is_same_v<xyfund::deref_type_t<const int_wrapper&>, const int_wrapper&>);
    static_assert(std::is_same_v<xyfund::deref_type_t<int_wrapper&&>, int_wrapper&>);
    static_assert(std::is_same_v<xyfund::deref_type_t<const int_wrapper&&>, const int_wrapper&>);

    static_assert(std::is_same_v<xyfund::deref_type_t<int_wrapper*>, int_wrapper&>);
    static_assert(std::is_same_v<xyfund::deref_type_t<const int_wrapper*>, const int_wrapper&>);
    static_assert(std::is_same_v<xyfund::deref_type_t<int_wrapper* const>, int_wrapper&>);
    static_assert(std::is_same_v<xyfund::deref_type_t<const int_wrapper* const>, const int_wrapper&>);

    static_assert(std::is_same_v<xyfund::deref_type_t<std::unique_ptr<int_wrapper>>, int_wrapper&>);
    static_assert(std::is_same_v<xyfund::deref_type_t<std::unique_ptr<const int_wrapper>>, const int_wrapper&>);
    static_assert(std::is_same_v<xyfund::deref_type_t<const std::unique_ptr<int_wrapper>>, int_wrapper&>);
    static_assert(std::is_same_v<xyfund::deref_type_t<const std::unique_ptr<const int_wrapper>>, const int_wrapper&>);

    static_assert(std::is_same_v<xyfund::deref_type_t<std::shared_ptr<int_wrapper>>, int_wrapper&>);
    static_assert(std::is_same_v<xyfund::deref_type_t<std::shared_ptr<const int_wrapper>>, const int_wrapper&>);
    static_assert(std::is_same_v<xyfund::deref_type_t<const std::shared_ptr<int_wrapper>>, int_wrapper&>);
    static_assert(std::is_same_v<xyfund::deref_type_t<const std::shared_ptr<const int_wrapper>>, const int_wrapper&>);

    static_assert(std::is_same_v<xyfund::deref_type_t<std::reference_wrapper<int_wrapper>>, int_wrapper&>);
    static_assert(std::is_same_v<xyfund::deref_type_t<std::reference_wrapper<const int_wrapper>>, const int_wrapper&>);
    static_assert(std::is_same_v<xyfund::deref_type_t<const std::reference_wrapper<int_wrapper>>, int_wrapper&>);
    static_assert(std::is_same_v<xyfund::deref_type_t<const std::reference_wrapper<const int_wrapper>>, const int_wrapper&>);
}

TEST(Traits, Function) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    static_assert(xyfund::function_traits<int(bool, const char&)>::arity == 2, "xyfund::function_traits<...>");

    static_assert(std::is_same<xyfund::function_traits<int(bool, const char&)>::result_type, int>::value, "xyfund::function_traits<...>");
    static_assert(!std::is_same<xyfund::function_traits<int(bool, const char&)>::result_type, bool>::value, "xyfund::function_traits<...>");

    static_assert(std::is_same<xyfund::function_traits<int(bool, const char&)>::argument_type_t<0>, bool>::value, "xyfund::function_traits<...>");
    static_assert(!std::is_same<xyfund::function_traits<int(bool, const char&)>::argument_type_t<0>, int>::value, "xyfund::function_traits<...>");
    static_assert(!std::is_same<xyfund::function_traits<int(bool, const char&)>::argument_type_t<0>, const char&>::value, "xyfund::function_traits<...>");

    static_assert(std::is_same<xyfund::function_traits<int(bool, const char&)>::argument_type_t<1>, const char&>::value, "xyfund::function_traits<...>");
    static_assert(!std::is_same<xyfund::function_traits<int(bool, const char&)>::argument_type_t<1>, char&>::value, "xyfund::function_traits<...>");
    static_assert(!std::is_same<xyfund::function_traits<int(bool, const char&)>::argument_type_t<1>, const char>::value, "xyfund::function_traits<...>");
    static_assert(!std::is_same<xyfund::function_traits<int(bool, const char&)>::argument_type_t<1>, char>::value, "xyfund::function_traits<...>");
    static_assert(!std::is_same<xyfund::function_traits<int(bool, const char&)>::argument_type_t<1>, bool>::value, "xyfund::function_traits<...>");
    static_assert(!std::is_same<xyfund::function_traits<int(bool, const char&)>::argument_type_t<1>, int>::value, "xyfund::function_traits<...>");
}

TEST(Traits, StdFunction) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    static_assert(xyfund::function_traits<std::function<int(bool, const char&)>>::arity == 2, "xyfund::function_traits<...>");

    static_assert(std::is_same<xyfund::function_traits<std::function<int(bool, const char&)>>::result_type, int>::value, "xyfund::function_traits<...>");
    static_assert(!std::is_same<xyfund::function_traits<std::function<int(bool, const char&)>>::result_type, bool>::value, "xyfund::function_traits<...>");

    static_assert(std::is_same<xyfund::function_traits<std::function<int(bool, const char&)>>::argument_type_t<0>, bool>::value, "xyfund::function_traits<...>");
    static_assert(!std::is_same<xyfund::function_traits<std::function<int(bool, const char&)>>::argument_type_t<0>, int>::value, "xyfund::function_traits<...>");
    static_assert(!std::is_same<xyfund::function_traits<std::function<int(bool, const char&)>>::argument_type_t<0>, const char&>::value, "xyfund::function_traits<...>");

    static_assert(std::is_same<xyfund::function_traits<std::function<int(bool, const char&)>>::argument_type_t<1>, const char&>::value, "xyfund::function_traits<...>");
    static_assert(!std::is_same<xyfund::function_traits<std::function<int(bool, const char&)>>::argument_type_t<1>, char&>::value, "xyfund::function_traits<...>");
    static_assert(!std::is_same<xyfund::function_traits<std::function<int(bool, const char&)>>::argument_type_t<1>, const char>::value, "xyfund::function_traits<...>");
    static_assert(!std::is_same<xyfund::function_traits<std::function<int(bool, const char&)>>::argument_type_t<1>, char>::value, "xyfund::function_traits<...>");
    static_assert(!std::is_same<xyfund::function_traits<std::function<int(bool, const char&)>>::argument_type_t<1>, bool>::value, "xyfund::function_traits<...>");
    static_assert(!std::is_same<xyfund::function_traits<std::function<int(bool, const char&)>>::argument_type_t<1>, int>::value, "xyfund::function_traits<...>");
}

TEST(Traits, Lambda) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    auto x = [](bool /*arg0*/, const char& /*arg1*/) { return 0; };
    (void)x;
    using lambda_type = decltype(x);

    static_assert(xyfund::function_traits<lambda_type>::arity == 2, "xyfund::function_traits<...>");

    static_assert(std::is_same<xyfund::function_traits<lambda_type>::result_type, int>::value, "xyfund::function_traits<...>");
    static_assert(!std::is_same<xyfund::function_traits<lambda_type>::result_type, bool>::value, "xyfund::function_traits<...>");

    static_assert(std::is_same<xyfund::function_traits<lambda_type>::argument_type_t<0>, bool>::value, "xyfund::function_traits<...>");
    static_assert(!std::is_same<xyfund::function_traits<lambda_type>::argument_type_t<0>, int>::value, "xyfund::function_traits<...>");
    static_assert(!std::is_same<xyfund::function_traits<lambda_type>::argument_type_t<0>, char>::value, "xyfund::function_traits<...>");

    static_assert(std::is_same<xyfund::function_traits<lambda_type>::argument_type_t<1>, const char&>::value, "xyfund::function_traits<...>");
    static_assert(!std::is_same<xyfund::function_traits<lambda_type>::argument_type_t<1>, char&>::value, "xyfund::function_traits<...>");
    static_assert(!std::is_same<xyfund::function_traits<lambda_type>::argument_type_t<1>, const char>::value, "xyfund::function_traits<...>");
    static_assert(!std::is_same<xyfund::function_traits<lambda_type>::argument_type_t<1>, char>::value, "xyfund::function_traits<...>");
    static_assert(!std::is_same<xyfund::function_traits<lambda_type>::argument_type_t<1>, bool>::value, "xyfund::function_traits<...>");
    static_assert(!std::is_same<xyfund::function_traits<lambda_type>::argument_type_t<1>, int>::value, "xyfund::function_traits<...>");
}

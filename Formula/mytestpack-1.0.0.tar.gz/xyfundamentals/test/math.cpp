//===========================================================================================================
//! This file is part of
//! XYFUNDAMENTALS
//!
//! Copyright (c) by Fraunhofer SCAI
//===========================================================================================================

#include <gtest/gtest.h>

#include <xyfund/math.hpp>
#include <xyfund/numbers.hpp>

TEST(Math, ConstantsCompileTime) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    static_assert(xyfund::numbers::constants<double>::e() == 2.7182818284590452353602874713526625, "e");
    static_assert(xyfund::numbers::constants<double>::log2e() == 1.4426950408889634073599246810018921, "log2e");
    static_assert(xyfund::numbers::constants<double>::log10e() == 0.4342944819032518276511289189166051, "log10e");
    static_assert(xyfund::numbers::constants<double>::pi() == 3.1415926535897932384626433832795029, "pi");
    static_assert(xyfund::numbers::constants<double>::inv_pi() == 0.3183098861837906715377675267450287, "inv_pi");
    static_assert(xyfund::numbers::constants<double>::inv_sqrtpi() == 0.5641895835477562869480794515607725, "inv_sqrtpi");
    static_assert(xyfund::numbers::constants<double>::ln2() == 0.6931471805599453094172321214581766, "ln2");
    static_assert(xyfund::numbers::constants<double>::ln10() == 2.3025850929940456840179914546843642, "ln10");
    static_assert(xyfund::numbers::constants<double>::sqrt2() == 1.4142135623730950488016887242096981, "sqrt2");
    static_assert(xyfund::numbers::constants<double>::sqrt3() == 1.7320508075688772935274463415058723, "sqrt3");
    static_assert(xyfund::numbers::constants<double>::inv_sqrt3() == 0.5773502691896257645091487805019574, "inv_sqrt3");
    static_assert(xyfund::numbers::constants<double>::egamma() == 0.5772156649015328606065120900824024, "egamma");
    static_assert(xyfund::numbers::constants<double>::phi() == 1.6180339887498948482045868343656381, "phi");
}

TEST(Math, ConstantsRunTime) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    EXPECT_EQ((xyfund::numbers::constants<double>::e()), 2.7182818284590452353602874713526625);
    EXPECT_EQ((xyfund::numbers::constants<double>::log2e()), 1.4426950408889634073599246810018921);
    EXPECT_EQ((xyfund::numbers::constants<double>::log10e()), 0.4342944819032518276511289189166051);
    EXPECT_EQ((xyfund::numbers::constants<double>::pi()), 3.1415926535897932384626433832795029);
    EXPECT_EQ((xyfund::numbers::constants<double>::inv_pi()), 0.3183098861837906715377675267450287);
    EXPECT_EQ((xyfund::numbers::constants<double>::inv_sqrtpi()), 0.5641895835477562869480794515607725);
    EXPECT_EQ((xyfund::numbers::constants<double>::ln2()), 0.6931471805599453094172321214581766);
    EXPECT_EQ((xyfund::numbers::constants<double>::ln10()), 2.3025850929940456840179914546843642);
    EXPECT_EQ((xyfund::numbers::constants<double>::sqrt2()), 1.4142135623730950488016887242096981);
    EXPECT_EQ((xyfund::numbers::constants<double>::sqrt3()), 1.7320508075688772935274463415058723);
    EXPECT_EQ((xyfund::numbers::constants<double>::inv_sqrt3()), 0.5773502691896257645091487805019574);
    EXPECT_EQ((xyfund::numbers::constants<double>::egamma()), 0.5772156649015328606065120900824024);
    EXPECT_EQ((xyfund::numbers::constants<double>::phi()), 1.6180339887498948482045868343656381);
}

TEST(Math, PowerOf10) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    EXPECT_EQ((xyfund::power_of_10<unsigned long long>(0)), 1);
    EXPECT_EQ((xyfund::power_of_10<unsigned long long>(19)), 10000000000000000000ULL);
}

TEST(Math, PowerOf2) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    EXPECT_EQ((xyfund::power_of_2<unsigned long long>(0)), 1);
    EXPECT_EQ((xyfund::power_of_2<unsigned long long>(1)), 2);
    EXPECT_EQ((xyfund::power_of_2<unsigned long long>(2)), 4);
    EXPECT_EQ((xyfund::power_of_2<unsigned long long>(3)), 8);
    EXPECT_EQ((xyfund::power_of_2<unsigned long long>(63)), 9223372036854775808ULL);
}

TEST(Math, Factorial) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    EXPECT_EQ((xyfund::factorial<char>(5)), 120);
    EXPECT_EQ((xyfund::factorial<unsigned char>(5)), 120);
    EXPECT_EQ((xyfund::factorial<short>(5)), 120);
    EXPECT_EQ((xyfund::factorial<unsigned short>(5)), 120);
    EXPECT_EQ((xyfund::factorial<int>(5)), 120);
    EXPECT_EQ((xyfund::factorial<unsigned int>(5)), 120U);
    EXPECT_EQ((xyfund::factorial<long>(5)), 120L);
    EXPECT_EQ((xyfund::factorial<unsigned long>(5)), 120UL);
    EXPECT_EQ((xyfund::factorial<long long>(5)), 120LL);
    EXPECT_EQ((xyfund::factorial<unsigned long long>(5)), 120ULL);

    EXPECT_EQ((xyfund::factorial<float>(5)), 120.F);
    EXPECT_EQ((xyfund::factorial<double>(5)), 120.);
    EXPECT_EQ((xyfund::factorial<double>(30)), 0.26525285981219105863630848e33);
    EXPECT_EQ((xyfund::factorial<long double>(5)), 120.L);
    EXPECT_EQ((xyfund::factorial<long double>(30)), 0.26525285981219105863630848e33L);

    static_assert(xyfund::factorial<int>(5) == 120, "factorial(5)");
    static_assert(xyfund::factorial<double>(30) == 0.26525285981219105863630848e33, "factorial(30)");
}

TEST(Math, Binomial) // NOLINT(cppcoreguidelines-special-member-functions, cppcoreguidelines-owning-memory, cppcoreguidelines-avoid-non-const-global-variables)
{
    EXPECT_EQ((xyfund::binomial<unsigned int>(12, 7)), 792U);
    EXPECT_EQ((xyfund::binomial<unsigned int>(25, 12)), 5200300U);
    EXPECT_EQ((xyfund::binomial<double>(25, 12)), 5200300.);
    EXPECT_EQ((xyfund::binomial<double>(300, 5)), 19582837560.);

    static_assert(xyfund::binomial<unsigned int>(12, 7) == 792U, "binomial(12, 7)");
    static_assert(xyfund::binomial<unsigned int>(25, 12) == 5200300U, "binomial(25, 12)");
    static_assert(xyfund::binomial<double>(25, 12) == 5200300., "binomial(25, 12)");
    static_assert(xyfund::binomial<double>(300, 5) == 19582837560., "binomial(300, 5)");
}

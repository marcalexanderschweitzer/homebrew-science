
#ifndef PMSC_IO_H
#define PMSC_IO_H

#include "vector.h"
#include "matrix.h"

void vec_print(Vector vector);

void csr_print(CsrMatrix matrix);


int vec_write(const char* file_path, Vector vector);

//! Read a vector from a given file.
//!
//! \param file_path Path to the file to be read.
//! \param vector    Pointer to the vector structure to be initialized with the data from the file.
//!                  The pointer passed must not be NULL.
//!                  If the function completes successfull the vector needs to freed by a call to vec_free().
//! \returns 0 on success. A non-zero value if the vector could not be read.
int vec_read(const char* file_path, Vector* vector);


int csr_write(const char* file_path, CsrMatrix matrix);

//! Read a CSR matrix from a given file.
//!
//! \param file_path Path to the file to be read.
//! \param vector    Pointer to the CSR matrix structure to be initialized with the data from the file.
//!                  The pointer passed must not be NULL.
//!                  If the function completes successfull the matrix needs to freed by a call to csr_free().
//! \returns 0 on success. A non-zero value if the matrix could not be read.
int csr_read(const char* file_path, CsrMatrix* matrix);

#endif // PMSC_IO_H

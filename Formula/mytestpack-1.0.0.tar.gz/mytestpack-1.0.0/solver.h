
#ifndef PMSC_OPERATIONS_H
#define PMSC_OPERATIONS_H

#include "vector.h"
#include "matrix.h"

void gauss_seidel_iteration(CsrMatrix A, Vector u, Vector b);

int gs_solve(CsrMatrix A, Vector u, Vector b, PmscScalar tolerance, int max_iterations);

int gs_solve_modified(CsrMatrix A, Vector u, Vector b, PmscScalar tolerance, int max_iterations, int* final_iterations);

int richardson_gs_solve(CsrMatrix A, Vector u, Vector b, PmscScalar tolerance, int max_iterations);

#endif /* PMSC_OPERATIONS_H */


#include <stddef.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <stdio.h>

#include "matrix.h"

int csr_create(int rows, int columns, int nnz, CsrMatrix* matrix)
{
    assert(rows >= 0);
    assert(columns >= 0);
    assert(nnz >= 0);

    assert(matrix != NULL);

    (*matrix) = (CsrMatrix)malloc(sizeof(**matrix));
    if((*matrix) == NULL) return PMSC_MEMORY_ERROR;

    (*matrix)->rows = rows;
    (*matrix)->columns = columns;

    (*matrix)->row_start_indices = (int*)malloc(sizeof(int)*(rows + 1));
    (*matrix)->column_indices = (int*)malloc(sizeof(int)*nnz);
    (*matrix)->values = (PmscScalar*)malloc(sizeof(PmscScalar)*nnz);

    if((*matrix)->values == NULL ||
       (*matrix)->column_indices == NULL ||
       (*matrix)->values == NULL)
    {
        csr_free(matrix);
        return PMSC_MEMORY_ERROR;
    }

    (*matrix)->row_start_indices[(*matrix)->rows] = nnz;

    return PMSC_SUCCESS;
}

void csr_free(CsrMatrix* matrix)
{
    if(matrix == NULL) return;

    free((*matrix)->row_start_indices);
    free((*matrix)->column_indices);
    free((*matrix)->values);

    free(*matrix);

    (*matrix) = NULL;
}

int csr_get_rows(CsrMatrix matrix)
{
    assert(matrix != NULL);
    return matrix->rows;
}

int csr_get_columns(CsrMatrix matrix)
{
    assert(matrix != NULL);
    return matrix->columns;
}

int csr_get_nnz(CsrMatrix matrix)
{
    assert(matrix != NULL);
    return matrix->row_start_indices[matrix->rows];
}

int csr_get_row_nnz(CsrMatrix matrix, int row_index)
{
    assert(matrix != NULL);
    assert(row_index >= 0 && row_index < csr_get_rows(matrix));
    return matrix->row_start_indices[row_index + 1] - matrix->row_start_indices[row_index];
}

int csr_get_row_nz_index(CsrMatrix matrix, int row_index, int non_zero_index)
{
    assert(matrix != NULL);
    assert(row_index >= 0 && row_index < csr_get_rows(matrix));
    assert(non_zero_index >= 0 && non_zero_index < csr_get_row_nnz(matrix, row_index));
    const int nz_i = matrix->row_start_indices[row_index] + non_zero_index;
    return matrix->column_indices[nz_i];
}

PmscScalar csr_get_row_nz_entry(CsrMatrix matrix, int row_index, int non_zero_index)
{
    assert(matrix != NULL);
    assert(row_index >= 0 && row_index < csr_get_rows(matrix));
    assert(non_zero_index >= 0 && non_zero_index < csr_get_row_nnz(matrix, row_index));
    const int nz_i = matrix->row_start_indices[row_index] + non_zero_index;
    return matrix->values[nz_i];
}

void csr_set_row_nz_entry(CsrMatrix matrix, int row_index, int non_zero_index, PmscScalar value)
{
    assert(matrix != NULL);
    assert(row_index >= 0 && row_index < csr_get_rows(matrix));
    assert(non_zero_index >= 0 && non_zero_index < csr_get_row_nnz(matrix, row_index));
    const int nz_i = matrix->row_start_indices[row_index] + non_zero_index;
    matrix->values[nz_i] = value;
}

void csr_assemble(CsrMatrix matrix, const PmscScalar* values, const int* row_indices, const int* column_indices, int nnz)
{
    assert(nnz == csr_get_nnz(matrix));
    assert(row_indices != NULL);
    assert(column_indices != NULL);

    matrix->row_start_indices[0] = 0;
    int current_row = 0;
    for(int i = 0; i < nnz; ++i)
    {
        assert(i == 0 || (row_indices[i] >= row_indices[i-1]));
        assert(row_indices[i] < matrix->rows);
        assert(column_indices[i] < matrix->columns);

        while(current_row < row_indices[i])
        {
            ++current_row;
            matrix->row_start_indices[current_row] = i;
        }
    }

    if(values != NULL)
    {
        memcpy(matrix->values, values, nnz*sizeof(PmscScalar));
    }
    memcpy(matrix->column_indices, column_indices, nnz*sizeof(int));

    // Move the diagonal element to the first non-zero entry in each row
    for(int r = 0; r < matrix->rows; ++r)
    {
        int row_nz_size = matrix->row_start_indices[r+1] - matrix->row_start_indices[r];
        for(int row_nz_i = 0; row_nz_i < row_nz_size; ++row_nz_i)
        {
            int nz_i = matrix->row_start_indices[r] + row_nz_i;
            int c = matrix->column_indices[nz_i];
            if(c == r)
            {
                if(row_nz_i != 0)
                {

                    if(values != NULL)
                    {
                        PmscScalar temp = matrix->values[nz_i];
                        matrix->values[nz_i] = matrix->values[matrix->row_start_indices[r]];
                        matrix->values[matrix->row_start_indices[r]] = temp;
                    }

                    matrix->column_indices[nz_i] = matrix->column_indices[matrix->row_start_indices[r]];
                    matrix->column_indices[matrix->row_start_indices[r]] = r;
                }
                break;
            }
        }
    }
}

void mat_vec_multiply(Vector result, CsrMatrix A, Vector v)
{
    assert(csr_get_columns(A) == vec_get_size(v));
    assert(csr_get_rows(A) == vec_get_size(result));

    const int rows = csr_get_rows(A);
    for(int r = 0; r < rows; ++r)
    {
        vec_set_entry(result, r, 0);
        const int row_nz_size = csr_get_row_nnz(A, r);
        for(int row_nz_i = 0; row_nz_i < row_nz_size; ++row_nz_i)
        {
            const int c = csr_get_row_nz_index(A, r, row_nz_i);
            vec_add_to_entry(result, r, csr_get_row_nz_entry(A, r, row_nz_i)*vec_get_entry(v, c));
        }
    }
}

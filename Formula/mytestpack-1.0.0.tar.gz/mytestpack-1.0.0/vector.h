
#ifndef PMSC_VECTOR_H
#define PMSC_VECTOR_H

#include "common.h"

typedef struct _vector
{
    int size;
    PmscScalar* values;
}* Vector;

int vec_create(int size, Vector* vector);

void vec_free(Vector* vector);

int vec_get_size(Vector vector);

PmscScalar vec_get_entry(Vector vector, int index);
void vec_set_entry(Vector vector, int index, PmscScalar Value);

void vec_add_to_entry(Vector vector, int index, PmscScalar Value);

void vec_assemble(Vector vector, const PmscScalar* values, int size);

void vec_assign(Vector v, PmscScalar value);

void vec_subtract(Vector result, Vector v1, Vector v2);

PmscScalar vec_dot(Vector v1, Vector v2);

#endif /* PMSC_VECTOR_H */

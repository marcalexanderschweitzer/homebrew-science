
#include <stddef.h>

#include "../vector.h"

#include "testing.h"

void test_vector_assemble(int* result)
{
    Vector v = NULL;
    const int create_result = vec_create(5, &v);
    if(expect_int_equal(create_result, 0, "test_vector_assemble: vec_create", result) != 0) return;

    if(expect_ptr_not_equal(v, NULL, "test_vector_assemble: v", result) != 0) { vec_free(&v); return; }
    if(expect_int_equal(vec_get_size(v), 5, "test_vector_assemble: vec_get_size", result) != 0) { vec_free(&v); return; }

    const PmscScalar values[] = {1.0, 2.0, 5.0, -2.0, 0.333};
    vec_assemble(v, values, sizeof(values)/sizeof(*values));
    if(expect_int_equal(vec_get_size(v), 5, "test_vector_assemble: vec_get_size", result) != 0) { vec_free(&v); return; }

    expect_double_equal(vec_get_entry(v, 0), values[0], "test_vector_assemble: vec_get_entry(v, 0)", result);
    expect_double_equal(vec_get_entry(v, 1), values[1], "test_vector_assemble: vec_get_entry(v, 1)", result);
    expect_double_equal(vec_get_entry(v, 2), values[2], "test_vector_assemble: vec_get_entry(v, 2)", result);
    expect_double_equal(vec_get_entry(v, 3), values[3], "test_vector_assemble: vec_get_entry(v, 3)", result);
    expect_double_equal(vec_get_entry(v, 4), values[4], "test_vector_assemble: vec_get_entry(v, 4)", result);

    vec_free(&v);
    expect_ptr_equal(v, NULL, "test_vector_assemble: vec_free", result);
}

int main()
{
    int result = 0;

    test_vector_assemble(&result);

    print_summary(result);

    return result;
}
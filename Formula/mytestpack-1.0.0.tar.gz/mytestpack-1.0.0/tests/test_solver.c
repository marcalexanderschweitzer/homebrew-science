
#include <stddef.h>

#include "../matrix.h"
#include "../vector.h"
#include "../solver.h"
#include "../io.h"

#include "testing.h"

void test_solver_gauss_seidel(int* result)
{
    int create_result;

    CsrMatrix A = NULL;
    create_result = csr_create(6, 6, 19, &A);
    if(expect_int_equal(create_result, 0, "test_solver_gauss_seidel: csr_create", result) != 0) return;

    Vector b = NULL;
    create_result = vec_create(6, &b);
    if(expect_int_equal(create_result, 0, "test_solver_gauss_seidel: vec_create", result) != 0) { csr_free(&A); return; }

    Vector u = NULL;
    create_result = vec_create(6, &u);
    if(expect_int_equal(create_result, 0, "test_solver_gauss_seidel: vec_create", result) != 0) { csr_free(&A); vec_free(&b); return; }

    const PmscScalar A_values[] = {-7.0, 4.0, 2.0, 1.0, -5.0, 4.0, 2.0, -11.0, 3.0, 6.0, -2.0, 2.0, 1.0, 2.0, 3.0, -9.0, 3.0, 7.0, -9.0};
    const int row_indices[]     = {   0,   0,   0,   1,    1,   1,   2,     2,   2,   2,    3,   3,   4,   4,   4,    4,   4,   5,    5};
    const int column_indices[]  = {   0,   1,   3,   0,    1,   3,   1,     2,   3,   4,    3,   5,   1,   2,   3,    4,   5,   2,    5};
    csr_assemble(A, A_values, row_indices, column_indices, sizeof(A_values)/sizeof(*A_values));

    const PmscScalar b_values[] = {4.0, 5.0, 6.0, 3.0, 8.0, 7.0};
    vec_assemble(b, b_values, sizeof(b_values)/sizeof(*b_values));

    const PmscScalar u_values[] = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
    vec_assemble(u, u_values, sizeof(u_values)/sizeof(*u_values));

    const int solve_result = gs_solve(A, u, b, 1e-10, 1000);
    expect_int_equal(solve_result, 0, "test_solver_gauss_seidel: gs_solve", result);

    expect_double_equal_eps(vec_get_entry(u, 0), -1.306957928714825e+01, 1e-9, "test_solver_gauss_seidel: vec_get_entry(u, 0)", result);
    expect_double_equal_eps(vec_get_entry(u, 1), -1.484951456216498e+01, 1e-9, "test_solver_gauss_seidel: vec_get_entry(u, 1)", result);
    expect_double_equal_eps(vec_get_entry(u, 2), -1.512864077572117e+01, 1e-9, "test_solver_gauss_seidel: vec_get_entry(u, 2)", result);
    expect_double_equal_eps(vec_get_entry(u, 3), -1.404449838102350e+01, 1e-9, "test_solver_gauss_seidel: vec_get_entry(u, 3)", result);
    expect_double_equal_eps(vec_get_entry(u, 4), -1.476375404441648e+01, 1e-9, "test_solver_gauss_seidel: vec_get_entry(u, 4)", result);
    expect_double_equal_eps(vec_get_entry(u, 5), -1.254449838111646e+01, 1e-9, "test_solver_gauss_seidel: vec_get_entry(u, 5)", result);

    csr_free(&A);
    vec_free(&b);
    vec_free(&u);
}

int main()
{
    int result = 0;

    test_solver_gauss_seidel(&result);

    print_summary(result);

    return result;
}


#include <stddef.h>

#include "../vector.h"
#include "../matrix.h"

#include "testing.h"

void test_multiply(int* result)
{
    const PmscScalar lhs_values[]     = {3.0, 22.0, 17.0, 7.0, 5.0, 1.0, 14.0, 8.0};
    const int lhs_row_indices[]       = {  0,    1,    1,   2,   2,   2,   4,    4};
    const int lhs_column_indices[]    = {  1,    0,    4,   0,   1,   3,   2,    4};
    const PmscScalar rhs_values[]     = {1.0,    5.0,  2.0, 7.0,  15.0};
    const PmscScalar expected_value[] = {15.0, 277.0, 39.0, 0.0, 148.0};

    int create_result;

    CsrMatrix lhs = NULL;
    create_result = csr_create(5, 5, 8, &lhs);
    if(expect_int_equal(create_result, 0, "test_multiply: csr_create", result) != 0) return;
    csr_assemble(lhs, lhs_values, lhs_row_indices, lhs_column_indices, sizeof(lhs_values)/sizeof(*lhs_values));
    
    Vector rhs = NULL;
    create_result = vec_create(5, &rhs);
    if(expect_int_equal(create_result, 0, "test_multiply: vec_create(rhs)", result) != 0) { csr_free(&lhs); return; }
    vec_assemble(rhs, rhs_values, sizeof(rhs_values)/sizeof(*rhs_values));

    Vector mult_result = NULL;
    create_result = vec_create(5, &mult_result);
    if(expect_int_equal(create_result, 0, "test_multiply: vec_create(mult_result)", result) != 0) { csr_free(&lhs); vec_free(&rhs); return; }
    mat_vec_multiply(mult_result, lhs, rhs);

    if(expect_int_equal(vec_get_size(mult_result), 5, "test_multiply: vec_get_size(mult_result)", result) == 0)
    {
        expect_double_equal(vec_get_entry(mult_result, 0), expected_value[0], "test_multiply: vec_get_entry(mult_result, 0)", result);
        expect_double_equal(vec_get_entry(mult_result, 1), expected_value[1], "test_multiply: vec_get_entry(mult_result, 1)", result);
        expect_double_equal(vec_get_entry(mult_result, 2), expected_value[2], "test_multiply: vec_get_entry(mult_result, 2)", result);
        expect_double_equal(vec_get_entry(mult_result, 3), expected_value[3], "test_multiply: vec_get_entry(mult_result, 3)", result);
        expect_double_equal(vec_get_entry(mult_result, 4), expected_value[4], "test_multiply: vec_get_entry(mult_result, 4)", result);
    }

    csr_free(&lhs);
    vec_free(&rhs);
    vec_free(&mult_result);
}

int main()
{
    int result = 0;

    test_multiply(&result);

    print_summary(result);

    return result;
}

#include <stddef.h>

#include "../matrix.h"

#include "testing.h"

void test_matrix_assemble(int* result)
{
    CsrMatrix m = NULL;
    const int create_result = csr_create(4, 3, 7, &m);
    if(expect_int_equal(create_result, 0, "test_matrix_assemble: vec_create", result) != 0) return;

    if(expect_ptr_not_equal(m, NULL, "test_matrix_assemble: m", result) != 0)  { csr_free(&m); return; }

    const PmscScalar values[]  = {1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0};
    const int row_indices[]    = {  0,   0,   1,   2,   2,   2,   3};
    const int column_indices[] = {  0,   2,   0,   0,   1,   2,   2};
    csr_assemble(m, values, row_indices, column_indices, sizeof(values)/sizeof(*values));

    // NOTE: since we do not assume getters and setters to be available yet, we can not test whether
    //       assemble was acctually successfull.

    csr_free(&m);
    expect_ptr_equal(m, NULL, "test_matrix_assemble: csr_free", result);
}

int main()
{
    int result = 0;

    test_matrix_assemble(&result);

    print_summary(result);

    return result;
}
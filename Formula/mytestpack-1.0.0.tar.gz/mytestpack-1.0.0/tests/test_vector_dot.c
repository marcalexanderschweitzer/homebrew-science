
#include <stddef.h>

#include "../vector.h"

#include "testing.h"

void test_vector_dot(int* result)
{
    const PmscScalar lhs_values[]      = {1.0, 2.0, 3.0, 4.0, 5.0};
    const PmscScalar rhs_values[]      = {6.0, 7.0, 8.0, 9.0,10.0};

    int create_result;

    Vector lhs = NULL;
    create_result = vec_create(5, &lhs);
    if(expect_int_equal(create_result, 0, "test_multiply: vec_create(lhs)", result) != 0) { vec_free(&lhs); return; }
    vec_assemble(lhs, lhs_values, sizeof(lhs_values)/sizeof(*lhs_values));

    Vector rhs = NULL;
    create_result = vec_create(5, &rhs);
    if(expect_int_equal(create_result, 0, "test_multiply: vec_create(rhs)", result) != 0) { vec_free(&lhs); return; }
    vec_assemble(rhs, rhs_values, sizeof(rhs_values)/sizeof(*rhs_values));

    const PmscScalar dot_result = vec_dot(lhs, rhs);
    const PmscScalar expected_result = 130.0;
    expect_double_equal(dot_result, expected_result, "test_dot: vec_dot(lhs, rhs)", result);

    vec_free(&lhs);
    vec_free(&rhs);
}

int main()
{
    int result = 0;

    test_vector_dot(&result);

    print_summary(result);

    return result;
}

#include <stddef.h>

#include "../matrix.h"

#include "testing.h"

void test_matrix_assemble_get_and_set(int* result)
{
    CsrMatrix m = NULL;
    const int create_result = csr_create(4, 3, 7, &m);
    if(expect_int_equal(create_result, 0, "test_matrix_assemble_get_and_set: vec_create", result) != 0) return;

    if(expect_ptr_not_equal(m, NULL, "test_matrix_assemble_get_and_set: m", result) != 0)  { csr_free(&m); return; }
    if(expect_int_equal(csr_get_rows(m), 4, "test_matrix_assemble_get_and_set: csr_get_rows", result) != 0)  { csr_free(&m); return; }
    if(expect_int_equal(csr_get_columns(m), 3, "test_matrix_assemble_get_and_set: csr_get_columns", result) != 0)  { csr_free(&m); return; }
    if(expect_int_equal(csr_get_nnz(m), 7, "test_matrix_assemble_get_and_set: csr_get_nnz", result) != 0)  { csr_free(&m); return; }


    const PmscScalar values[]  = {1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0};
    const int row_indices[]    = {  0,   0,   1,   2,   2,   2,   3};
    const int column_indices[] = {  0,   2,   0,   0,   1,   2,   2};
    csr_assemble(m, values, row_indices, column_indices, sizeof(values)/sizeof(*values));

    if(expect_int_equal(csr_get_rows(m), 4, "test_matrix_assemble_get_and_set: csr_get_rows", result) != 0)  { csr_free(&m); return; }
    if(expect_int_equal(csr_get_columns(m), 3, "test_matrix_assemble_get_and_set: csr_get_columns", result) != 0)  { csr_free(&m); return; }
    if(expect_int_equal(csr_get_nnz(m), 7, "test_matrix_assemble_get_and_set: csr_get_nnz", result) != 0)  { csr_free(&m); return; }

    expect_int_equal(csr_get_row_nnz(m, 0), 2, "test_matrix_assemble_get_and_set: csr_get_row_nnz(m, 0)", result);
    expect_int_equal(csr_get_row_nnz(m, 1), 1, "test_matrix_assemble_get_and_set: csr_get_row_nnz(m, 1)", result);
    expect_int_equal(csr_get_row_nnz(m, 2), 3, "test_matrix_assemble_get_and_set: csr_get_row_nnz(m, 2)", result);
    expect_int_equal(csr_get_row_nnz(m, 3), 1, "test_matrix_assemble_get_and_set: csr_get_row_nnz(m, 3)", result);

    const PmscScalar dense_values[4][3] = {{1.0, 0.0, 2.0},
                                           {3.0, 0.0, 0.0},
                                           {4.0, 5.0, 6.0},
                                           {0.0, 0.0, 7.0}};

    expect_double_equal(csr_get_row_nz_entry(m, 0, 0), dense_values[0][csr_get_row_nz_index(m, 0, 0)], "test_matrix_assemble_get_and_set: csr_get_row_nz_entry(m, 0, 0)", result);
    expect_double_equal(csr_get_row_nz_entry(m, 0, 1), dense_values[0][csr_get_row_nz_index(m, 0, 1)], "test_matrix_assemble_get_and_set: csr_get_row_nz_entry(m, 0, 1)", result);
    expect_double_equal(csr_get_row_nz_entry(m, 1, 0), dense_values[1][csr_get_row_nz_index(m, 1, 0)], "test_matrix_assemble_get_and_set: csr_get_row_nz_entry(m, 1, 0)", result);
    expect_double_equal(csr_get_row_nz_entry(m, 2, 0), dense_values[2][csr_get_row_nz_index(m, 2, 0)], "test_matrix_assemble_get_and_set: csr_get_row_nz_entry(m, 2, 0)", result);
    expect_double_equal(csr_get_row_nz_entry(m, 2, 1), dense_values[2][csr_get_row_nz_index(m, 2, 1)], "test_matrix_assemble_get_and_set: csr_get_row_nz_entry(m, 2, 1)", result);
    expect_double_equal(csr_get_row_nz_entry(m, 2, 2), dense_values[2][csr_get_row_nz_index(m, 2, 2)], "test_matrix_assemble_get_and_set: csr_get_row_nz_entry(m, 2, 2)", result);
    expect_double_equal(csr_get_row_nz_entry(m, 3, 0), dense_values[3][csr_get_row_nz_index(m, 3, 0)], "test_matrix_assemble_get_and_set: csr_get_row_nz_entry(m, 3, 0)", result);

    csr_set_row_nz_entry(m, 0, 0,  8.0);
    csr_set_row_nz_entry(m, 0, 1,  9.0);
    csr_set_row_nz_entry(m, 1, 0, 10.0);
    csr_set_row_nz_entry(m, 2, 0, 11.0);
    csr_set_row_nz_entry(m, 2, 1, 12.0);
    csr_set_row_nz_entry(m, 2, 2, 13.0);
    csr_set_row_nz_entry(m, 3, 0, 14.0);

    expect_double_equal(csr_get_row_nz_entry(m, 0, 0),  8.0, "test_matrix_assemble_get_and_set: csr_get_row_nz_entry(m, 0, 0)", result);
    expect_double_equal(csr_get_row_nz_entry(m, 0, 1),  9.0, "test_matrix_assemble_get_and_set: csr_get_row_nz_entry(m, 0, 1)", result);
    expect_double_equal(csr_get_row_nz_entry(m, 1, 0), 10.0, "test_matrix_assemble_get_and_set: csr_get_row_nz_entry(m, 1, 0)", result);
    expect_double_equal(csr_get_row_nz_entry(m, 2, 0), 11.0, "test_matrix_assemble_get_and_set: csr_get_row_nz_entry(m, 2, 0)", result);
    expect_double_equal(csr_get_row_nz_entry(m, 2, 1), 12.0, "test_matrix_assemble_get_and_set: csr_get_row_nz_entry(m, 2, 1)", result);
    expect_double_equal(csr_get_row_nz_entry(m, 2, 2), 13.0, "test_matrix_assemble_get_and_set: csr_get_row_nz_entry(m, 2, 2)", result);
    expect_double_equal(csr_get_row_nz_entry(m, 3, 0), 14.0, "test_matrix_assemble_get_and_set: csr_get_row_nz_entry(m, 3, 0)", result);

    csr_free(&m);
    expect_ptr_equal(m, NULL, "test_matrix_create_and_destroy: csr_free", result);
}

int main()
{
    int result = 0;

    test_matrix_assemble_get_and_set(&result);

    print_summary(result);

    return result;
}
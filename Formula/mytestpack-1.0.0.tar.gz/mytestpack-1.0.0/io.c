
#include <stddef.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <stdio.h>

#include "vector.h"
#include "matrix.h"

void vec_print(Vector vector)
{
    for(int i = 0; i < vector->size; ++i)
    {
        printf("%.15e\n", vector->values[i]);
    }
}

void csr_print(CsrMatrix matrix)
{
    printf("IA: ");
    for(int r = 0; r < matrix->rows + 1; ++r)
    {
        printf("%d ", matrix->row_start_indices[r]);
    }
    printf("\n");

    const int nnz = csr_get_nnz(matrix);

    printf("A: ");
    for(int r = 0; r < nnz; ++r)
    {
        printf("%f ", matrix->values[r]);
    }
    printf("\n");

    printf("JA: ");
    for(int r = 0; r < nnz; ++r)
    {
        printf("%d ", matrix->column_indices[r]);
    }
    printf("\n");

}


int vec_write(const char* file_path, Vector vector)
{
    assert(vector != NULL);

    FILE* file = fopen(file_path, "w");
    if(file == NULL) return -1;

    const int size = vec_get_size(vector);
    fprintf(file, "%d\n", size);

    for(int i = 0; i < size; ++i)
    {
        const PmscScalar value = vec_get_entry(vector, i);
        fprintf(file, "%.15e\n", value);
    }

    fclose(file);

    return 0;
}

int vec_read(const char* file_path, Vector* vector)
{
    assert(vector != NULL);
    if(*vector != NULL)
    {
        vec_free(vector);
    }

    FILE* file = fopen(file_path, "r");
    if(file == NULL) return -1;

    int size;
    if(fscanf(file, "%d", &size) != 1)
    {
        fclose(file);
        return -1;
    }

    if(size < 0)
    {
        fclose(file);
        return -1;
    }

    PmscScalar* values = malloc(sizeof(PmscScalar)*size);

    if(values == NULL)
    {
        fclose(file);
        free(values);
        return -1;
    }

    for(int i = 0; i < size; ++i)
    {
        if(fscanf(file, "%le", values + i) != 1)
        {
            fclose(file);
            free(values);
            return -1;
        }
    }
    fclose(file);

    if(vec_create(size, vector) != 0)
    {
        free(values);
        return -1;
    }

    vec_assemble(*vector, values, size);

    free(values);

    return 0;
}


int csr_write(const char* file_path, CsrMatrix matrix)
{
    assert(matrix != NULL);

    FILE* file = fopen(file_path, "w");
    if(file == NULL) return -1;

    const int rows = csr_get_rows(matrix);
    const int columns = csr_get_columns(matrix);
    fprintf(file, "%d %d %d\n", rows, columns, csr_get_nnz(matrix));

    for(int r = 0; r < rows; ++r)
    {
        const int row_nz_size = csr_get_row_nnz(matrix, r);
        for(int row_nz_i = 0; row_nz_i < row_nz_size; ++row_nz_i)
        {
            const int c = csr_get_row_nz_index(matrix, r, row_nz_i);
            const PmscScalar value = csr_get_row_nz_entry(matrix, r, row_nz_i);
            fprintf(file, "%d %d %.15e\n", r, c, value);
        }
    }

    fclose(file);

    return 0;
}

int csr_read(const char* file_path, CsrMatrix* matrix)
{
    assert(matrix != NULL);
    if(*matrix != NULL)
    {
        csr_free(matrix);
    }

    FILE* file = fopen(file_path, "r");
    if(file == NULL) return -1;

    int rows;
    int columns;
    int nnz;
    if(fscanf(file, "%d %d %d", &rows, &columns, &nnz) != 3)
    {
        fclose(file);
        return -1;
    }

    if(rows < 0 || columns < 0 || nnz < 0)
    {
        fclose(file);
        return -1;
    }

    int* column_indices = malloc(sizeof(int)*nnz);
    int* row_indices = malloc(sizeof(int)*nnz);
    PmscScalar* values = malloc(sizeof(PmscScalar)*nnz);

    if(column_indices == NULL || row_indices == NULL || values == NULL)
    {
        fclose(file);
        free(column_indices);
        free(row_indices);
        free(values);
        return -1;
    }

    for(int i = 0; i < nnz; ++i)
    {
        if(fscanf(file, "%d %d %le", row_indices + i, column_indices + i, values + i) != 3)
        {
            fclose(file);
            free(column_indices);
            free(row_indices);
            free(values);
            return -1;
        }
    }

    fclose(file);

    if(csr_create(rows, columns, nnz, matrix) != 0)
    {
        free(column_indices);
        free(row_indices);
        free(values);
        return -1;
    }

    csr_assemble(*matrix, values, row_indices, column_indices, nnz);

    free(column_indices);
    free(row_indices);
    free(values);

    return 0;
}

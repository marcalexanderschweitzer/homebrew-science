
#include <stddef.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <stdio.h>

#include "vector.h"

int vec_create(int size, Vector* vector)
{
    assert(size >= 0);

    assert(vector != NULL);

    (*vector) = (Vector)calloc(1, sizeof(**vector));
    if((*vector) == NULL) return PMSC_MEMORY_ERROR;

    (*vector)->size = size;

    (*vector)->values = (PmscScalar*)malloc(sizeof(PmscScalar)*size);

    if((*vector)->values == NULL)
    {
        vec_free(vector);
        return PMSC_MEMORY_ERROR;
    }

    return PMSC_SUCCESS;
}

void vec_free(Vector* vector)
{
    if(vector == NULL) return;

    free((*vector)->values);

    free(*vector);

    (*vector) = NULL;
}

int vec_get_size(Vector vector)
{
    assert(vector != NULL);
    return vector->size;
}

PmscScalar vec_get_entry(Vector vector, int index)
{
    assert(vector != NULL);
    assert(index >= 0 && index < vec_get_size(vector));
    return vector->values[index];
}

void vec_set_entry(Vector vector, int index, PmscScalar value)
{
    assert(vector != NULL);
    assert(index >= 0 && index < vec_get_size(vector));
    vector->values[index] = value;
}

void vec_add_to_entry(Vector vector, int index, PmscScalar value)
{
    assert(vector != NULL);
    assert(index >= 0 && index < vec_get_size(vector));
    vector->values[index] += value;
}

void vec_assemble(Vector vector, const PmscScalar* values, int size)
{
    assert(size == vector->size);

    memcpy(vector->values, values, size*sizeof(PmscScalar));
}

void vec_assign(Vector v, PmscScalar value)
{
    const int size = vec_get_size(v);
    for(int i = 0; i < size; ++i)
    {
        vec_set_entry(v, i, value);
    }
}

void vec_subtract(Vector result, Vector v1, Vector v2)
{
    assert(vec_get_size(v1) == vec_get_size(v2));
    assert(vec_get_size(v1) == vec_get_size(result));

    const int size = vec_get_size(result);
    for(int i = 0; i < size; ++i)
    {
        vec_set_entry(result, i, vec_get_entry(v1, i) - vec_get_entry(v2, i));
    }
}

PmscScalar vec_dot(Vector v1, Vector v2)
{
    assert(vec_get_size(v1) == vec_get_size(v2));

    PmscScalar result = 0;
    const int size = vec_get_size(v1);
    for(int i = 0; i < size; ++i)
    {
        result += vec_get_entry(v1, i) * vec_get_entry(v2, i);
    }
    return result;
}



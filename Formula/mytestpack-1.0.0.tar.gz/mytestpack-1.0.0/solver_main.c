
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "solver.h"
#include "io.h"

int main()
{
    const char* A_file_path = "../data/test_matrix.txt";
    const char* b_file_path = "../data/test_rhs.txt";

    CsrMatrix A = NULL;
    Vector b = NULL;
    Vector u = NULL;

    if(csr_read(A_file_path, &A) != 0)
    {
        fprintf(stderr, "Could not read matrix file\n");
        csr_free(&A); vec_free(&b); vec_free(&u);
        return -1;
    }

    if(vec_read(b_file_path, &b) != 0)
    {
        fprintf(stderr, "Could not read matrix file\n");
        csr_free(&A); vec_free(&b); vec_free(&u);
        return -1;
    }

    if(csr_get_rows(A) != csr_get_columns(A))
    {
        fprintf(stderr, "Input matrix needs to be a square matrix but it is %dx%d\n", csr_get_rows(A), csr_get_columns(A));
        csr_free(&A); vec_free(&b); vec_free(&u);
        return -1;
    }

    if(csr_get_rows(A) != vec_get_size(b))
    {
        fprintf(stderr, "Input matrix and input right-hand-side vector have invalid sizes. Matrix has %d rows and vector is of length %d\n", csr_get_rows(A), vec_get_size(b));
        csr_free(&A); vec_free(&b); vec_free(&u);
        return -1;
    }

    if(vec_create(vec_get_size(b), &u) != 0)
    {
        fprintf(stderr, "Failed to create result vector\n");
        csr_free(&A); vec_free(&b); vec_free(&u);
        return -1;
    }

    vec_assign(u, 0);

    const int max_iterations = 10000000;
    const PmscScalar tolerance = 1e-10;

    int final_iterations;

    if(gs_solve_modified(A, u, b, tolerance, max_iterations, &final_iterations) != 0)
    {
        fprintf(stderr, "Failed solving equation system after %d iterations\n", final_iterations);
        csr_free(&A); vec_free(&b); vec_free(&u);
        return -1;
    }

    printf("Finished solving after %d iterations\n", final_iterations);

    csr_free(&A);
    vec_free(&b);
    vec_free(&u);
    return 0;
}